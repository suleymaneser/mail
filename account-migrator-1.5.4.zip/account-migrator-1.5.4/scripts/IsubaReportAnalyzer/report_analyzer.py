import os
import re
import time
import sys


class IsubaReportAnalyzer:
    def __init__(self, root_path, debug=False):
        self.root_path = root_path
        self.debug = debug
        self.file_list = ['londonDIJ.cbl', 'londonNAR.cbl']

    def analyze(self):
        for path, sub_directories, files in os.walk(self.root_path):
            for file in files:
                if file in self.file_list:
                    self._process_isuba_file(file, path)

    def _process_isuba_file(self, file_name, path):
        IsubaFileProcessor(file_name, path, self.debug).process()


class IsubaFileProcessor:
    def __init__(self, file_name, root_path, debug=False):
        self.file_name = file_name
        self.root_path = root_path
        self.full_path = os.path.join(root_path, file_name)
        self.debug = debug
        self.compile_tree = {}
        self.already_processed_section = set()
        self.processed_table_names = set()
        self.used_linkage_copybooks = set()

    def process(self):
        self._print_file_header()
        self._prepare_compile_tree(self.file_name)
        main_process_section = self._find_program_body_section_from_text("Main-Process",
                                                                         file_content=self.compile_tree[self.file_name])
        self._search_sections_in_file(self.file_name, level=0, section_text=main_process_section)
        self._print_table_list()
        self._print_linkage_copybook_list()

    def _print_file_header(self):
        Log.write("=" * 80)
        Log.write("PROCESSING FILE " + self.file_name + " IN PATH " + self.root_path)
        Log.write("=" * 80)

    def _print_table_list(self):
        Log.write_empty_line()
        Log.write('=' * 8 + ' DB Table list ' + '=' * 9)
        Log.write_empty_line()
        for table_name in sorted(self.processed_table_names):
            if len(table_name) == 4:
                Log.write("PROCESSED 4 CHAR TABLE:" + table_name)
        for table_name in self.processed_table_names:
            if len(table_name) != 4:
                Log.write("PROCESSED n CHAR TABLE:" + table_name)
        Log.write_empty_line()
        Log.write('=' * 7 + ' End of Table list ' + '=' * 8)
        Log.write_empty_line()

    def _print_linkage_copybook_list(self):
        Log.write_empty_line()
        Log.write('=' * 5 + ' Linkage Copybook list ' + '=' * 5)
        Log.write_empty_line()
        for copybook in sorted(self.used_linkage_copybooks):
            Log.write("USED LINKAGE COPYBOOK:" + copybook)
        Log.write_empty_line()
        Log.write('=' * 3 + ' End of Linkage Copybook list ' + '=' * 4)
        Log.write_empty_line()

    def _prepare_compile_tree(self, file_name, level=1):
        if level == 1:
            Log.write("--------------- Start of copybook tree section --------------\n", level)
        if file_name in self.compile_tree.keys() or \
           os.path.splitext(file_name.upper())[1] not in [".CBL", ".CPY", ".CPB"]:
            return
        full_path = os.path.join(self.root_path, file_name)
        if not os.path.exists(full_path):
            Log.write("!!! FILE " + file_name + " DOES NOT EXIST !!!", level)
            return
        file_content = IsubaFileProcessor._read_file_contents(full_path)
        self.compile_tree[file_name] = file_content.upper()
        for copybook in self._find_copybook_names_in_text(file_content):
            Log.write("Processing copybook: " + copybook + " on level " + str(level), level)
            self._prepare_compile_tree(copybook, level=level+1)
        if level == 1:
            Log.write("---------------- End of copybook tree section ---------------\n", level)

    def _search_sections_in_file(self, file_name, level, section_text):
        for section_name in self._find_called_sections_from_text(section_text, level=level):
            Log.write("Called section_name found: " + section_name, level)
            if self._section_exists_in_text(section_name, section_text):
                Log.write("Section is in same file", level)
                self._process_section(section_name, file_name=file_name, level=level+1)
            else:
                self._search_section_in_copybooks(section_name, level)

    @staticmethod
    def _section_exists_in_text(section_name, text):
        return bool(re.search(section_name.upper() + '.{1,5}SECTION', text, flags=re.IGNORECASE))

    def _search_section_in_copybooks(self, section_name, level=0):
        found = False
        for copybook_name, copybook_content in self.compile_tree.items():
            if self.debug:
                Log.write("Reading copybook " + copybook_name + " and searching <" + section_name + ' SECTION>', level)
            if self._section_exists_in_text(section_name, copybook_content):
                Log.write("Section found in copybook file " + copybook_name, level=level+1)
                found = True
                self._process_section(section_name, file_name=copybook_name, level=level+1)
                break
            else:
                if self.debug:
                    Log.write("Section " + section_name + " not found in copybook file " + copybook_name)
        if not found:
            raise Exception("Section " + section_name + " could not be found in any copybook.")

    def _process_section(self, section_name, file_name, level):
        if section_name in self.already_processed_section:
            Log.write("section:" + section_name + " in file: " + file_name +
                      " was already processed, skipping", level)
            return
        else:
            if not self._section_exists_in_text(section_name, self.compile_tree[file_name]):
                raise Exception("Section not found, must not be possible.")
            self.already_processed_section.add(section_name)

        Log.write("Processing section:" + section_name + " in file " + file_name + " level " + str(level), level)

        section_text = self._find_section_text_in_file(file_name, section_name)
        if self.debug:
            print(str(section_text))

        # Analyze call program usage
        if bool(re.search('CALL.*using((.*?\n)+?.*?)CANCEL', section_text, flags=re.IGNORECASE)):
            search_results = re.findall('CALL.*using((.*?\n)+?.*?)CANCEL', section_text, flags=re.IGNORECASE)
            for search_result in search_results:
                linkage_copybooks = re.findall('((.|\n)*?(\S*)(.|\n)*?)', search_result[0], flags=re.IGNORECASE)
                for linkage_copybook in linkage_copybooks:
                    self.used_linkage_copybooks.add(linkage_copybook[0])

        # Analyze SQL usage
        for keyword in ['FROM', 'JOIN', 'INTO', 'UPDATE']:
            self._find_sql_table_in_text_by_function(level, section_text, keyword)

        self._search_sections_in_file(file_name, level=level, section_text=section_text)

    def _find_sql_table_in_text_by_function(self, level, section_text, keyword):
        join_tables = re.findall(keyword + "(\s*)?(\w*)?", section_text, flags=re.IGNORECASE)
        for table in join_tables:
            self.processed_table_names.add(table[1])
            if self.debug:
                Log.write("Found " + keyword + " table: " + table[1], level)

    @staticmethod
    def _find_program_body_section_from_text(section_name, file_content):
        return re.findall('(' + section_name + '.{1,5}SECTION\.((.*)\n)+?.*\.)', file_content, flags=re.IGNORECASE)[0][0]

    @staticmethod
    def _find_copybook_names_in_text(file_content):
        return re.findall('COPY "(.*)"', file_content, flags=re.IGNORECASE)

    @staticmethod
    def _find_called_sections_from_text(section_text, level=0):
        called_sections = set(re.findall('perform. *?([.\S]+)', section_text, flags=re.IGNORECASE))
        sections = called_sections\
            .difference({'PROGRAM-TERMINATE', 'VARYING', 'WRITE-FILE', 'DATE-RANGE', 'PR-DAYBYDAY', 'UNTIL'})
        if len(sections) > 0:
            Log.write("Called sections: " + str(sections), level=level)
        return sections

    def _find_section_text_in_file(self, file_name, section_name):
        return re.findall("(.*?" + section_name + '.{1,5}SECTION((.*)\n)+?.*(exit section|exit program))',
                          self.compile_tree[file_name],
                          flags=re.IGNORECASE)[0][0]

    @staticmethod
    def _read_file_contents(full_path):
        file = open(str(full_path), mode="r")
        file_content = file.read()
        file.close()
        return file_content


class Log(object):
    @staticmethod
    def __formatted_date_time():
        return time.strftime("%Y-%m-%d %H:%M:%S  ")

    @staticmethod
    def write(message, level=0):
        print(Log.__formatted_date_time() + " " + ("--- "*level) + str(message))
        sys.stdout.flush()

    @staticmethod
    def write_empty_line(level=0):
        Log.write("", level)

IsubaReportAnalyzer("d:\\Gelisk_Repos\\gelisk\\isuba\\src", debug=False).analyze()
