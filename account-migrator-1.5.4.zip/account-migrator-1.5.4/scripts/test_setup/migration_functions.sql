--
ALTER PROCEDURE [tSQLt].[Private_RunTest]
   @TestName NVARCHAR(MAX),
   @SetUp NVARCHAR(MAX) = NULL
AS
BEGIN
    DECLARE @Msg NVARCHAR(MAX); SET @Msg = '';
    DECLARE @Msg2 NVARCHAR(MAX); SET @Msg2 = '';
    DECLARE @Cmd NVARCHAR(MAX); SET @Cmd = '';
    DECLARE @TestClassName NVARCHAR(MAX); SET @TestClassName = '';
    DECLARE @TestProcName NVARCHAR(MAX); SET @TestProcName = '';
    DECLARE @Result NVARCHAR(MAX); SET @Result = 'Success';
    DECLARE @TranName CHAR(32); EXEC tSQLt.GetNewTranName @TranName OUT;
    DECLARE @TestResultId INT;
    DECLARE @PreExecTrancount INT;

    DECLARE @VerboseMsg NVARCHAR(MAX);
    DECLARE @Verbose BIT;
    SET @Verbose = ISNULL((SELECT CAST(Value AS BIT) FROM tSQLt.Private_GetConfiguration('Verbose')),0);
    
	PRINT '<TSQLT_TEST>'
	PRINT '<TestFullName>'+@TestName+'</TestFullName>'
	PRINT '<TestStartTime>' + CONVERT(VARCHAR(10),GETDATE(),101) + ' ' + CONVERT(VARCHAR(8),GETDATE(),108) + '</TestStartTime>'
	
    TRUNCATE TABLE tSQLt.CaptureOutputLog;
    CREATE TABLE #ExpectException(ExpectException INT,ExpectedMessage NVARCHAR(MAX), ExpectedSeverity INT, ExpectedState INT, ExpectedMessagePattern NVARCHAR(MAX), ExpectedErrorNumber INT, FailMessage NVARCHAR(MAX));

    IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE name = N'SetFakeViewOnTrigger')
    BEGIN
      RAISERROR('Test system is in an invalid state. SetFakeViewOff must be called if SetFakeViewOn was called. Call SetFakeViewOff after creating all test case procedures.', 16, 10) WITH NOWAIT;
      RETURN -1;
    END;

    SELECT @Cmd = 'EXEC ' + @TestName;
    
    SELECT @TestClassName = OBJECT_SCHEMA_NAME(OBJECT_ID(@TestName)), --tSQLt.Private_GetCleanSchemaName('', @TestName),
           @TestProcName = tSQLt.Private_GetCleanObjectName(@TestName);
           
    INSERT INTO tSQLt.TestResult(Class, TestCase, TranName, Result) 
        SELECT @TestClassName, @TestProcName, @TranName, 'A severe error happened during test execution. Test did not finish.'
        OPTION(MAXDOP 1);
    SELECT @TestResultId = SCOPE_IDENTITY();

    IF(@Verbose = 1)
    BEGIN
      SET @VerboseMsg = 'tSQLt.Run '''+@TestName+'''; --Starting';
      EXEC tSQLt.Private_Print @Message =@VerboseMsg, @Severity = 0;
    END;

    BEGIN TRAN;
    SAVE TRAN @TranName;

    SET @PreExecTrancount = @@TRANCOUNT;
    
    TRUNCATE TABLE tSQLt.TestMessage;

    DECLARE @TmpMsg NVARCHAR(MAX);
    DECLARE @TestEndTime DATETIME; SET @TestEndTime = NULL;
    BEGIN TRY
        IF (@SetUp IS NOT NULL) EXEC @SetUp;
        EXEC (@Cmd);
        SET @TestEndTime = GETDATE();
        IF(EXISTS(SELECT 1 FROM #ExpectException WHERE ExpectException = 1))
        BEGIN
          SET @TmpMsg = COALESCE((SELECT FailMessage FROM #ExpectException)+' ','')+'Expected an error to be raised.';
          EXEC tSQLt.Fail @TmpMsg;
        END
    END TRY
    BEGIN CATCH
        SET @TestEndTime = ISNULL(@TestEndTime,GETDATE());
        IF ERROR_MESSAGE() LIKE '%tSQLt.Failure%'
        BEGIN
            SELECT @Msg = Msg FROM tSQLt.TestMessage;
            SET @Result = 'Failure';
        END
        ELSE
        BEGIN
          DECLARE @ErrorInfo NVARCHAR(MAX);
          SELECT @ErrorInfo = 
            COALESCE(ERROR_MESSAGE(), '<ERROR_MESSAGE() is NULL>') + 
            '[' +COALESCE(LTRIM(STR(ERROR_SEVERITY())), '<ERROR_SEVERITY() is NULL>') + ','+COALESCE(LTRIM(STR(ERROR_STATE())), '<ERROR_STATE() is NULL>') + ']' +
            '{' + COALESCE(ERROR_PROCEDURE(), '<ERROR_PROCEDURE() is NULL>') + ',' + COALESCE(CAST(ERROR_LINE() AS NVARCHAR), '<ERROR_LINE() is NULL>') + '}';

          IF(EXISTS(SELECT 1 FROM #ExpectException))
          BEGIN
            DECLARE @ExpectException INT;
            DECLARE @ExpectedMessage NVARCHAR(MAX);
            DECLARE @ExpectedMessagePattern NVARCHAR(MAX);
            DECLARE @ExpectedSeverity INT;
            DECLARE @ExpectedState INT;
            DECLARE @ExpectedErrorNumber INT;
            DECLARE @FailMessage NVARCHAR(MAX);
            SELECT @ExpectException = ExpectException,
                   @ExpectedMessage = ExpectedMessage, 
                   @ExpectedSeverity = ExpectedSeverity,
                   @ExpectedState = ExpectedState,
                   @ExpectedMessagePattern = ExpectedMessagePattern,
                   @ExpectedErrorNumber = ExpectedErrorNumber,
                   @FailMessage = FailMessage
              FROM #ExpectException;

            IF(@ExpectException = 1)
            BEGIN
              SET @Result = 'Success';
              SET @TmpMsg = COALESCE(@FailMessage+' ','')+'Exception did not match expectation!';
              IF(ERROR_MESSAGE() <> @ExpectedMessage)
              BEGIN
                SET @TmpMsg = @TmpMsg +CHAR(13)+CHAR(10)+
                           'Expected Message: <'+@ExpectedMessage+'>'+CHAR(13)+CHAR(10)+
                           'Actual Message  : <'+ERROR_MESSAGE()+'>';
                SET @Result = 'Failure';
              END
              IF(ERROR_MESSAGE() NOT LIKE @ExpectedMessagePattern)
              BEGIN
                SET @TmpMsg = @TmpMsg +CHAR(13)+CHAR(10)+
                           'Expected Message to be like <'+@ExpectedMessagePattern+'>'+CHAR(13)+CHAR(10)+
                           'Actual Message            : <'+ERROR_MESSAGE()+'>';
                SET @Result = 'Failure';
              END
              IF(ERROR_NUMBER() <> @ExpectedErrorNumber)
              BEGIN
                SET @TmpMsg = @TmpMsg +CHAR(13)+CHAR(10)+
                           'Expected Error Number: '+CAST(@ExpectedErrorNumber AS NVARCHAR(MAX))+CHAR(13)+CHAR(10)+
                           'Actual Error Number  : '+CAST(ERROR_NUMBER() AS NVARCHAR(MAX));
                SET @Result = 'Failure';
              END
              IF(ERROR_SEVERITY() <> @ExpectedSeverity)
              BEGIN
                SET @TmpMsg = @TmpMsg +CHAR(13)+CHAR(10)+
                           'Expected Severity: '+CAST(@ExpectedSeverity AS NVARCHAR(MAX))+CHAR(13)+CHAR(10)+
                           'Actual Severity  : '+CAST(ERROR_SEVERITY() AS NVARCHAR(MAX));
                SET @Result = 'Failure';
              END
              IF(ERROR_STATE() <> @ExpectedState)
              BEGIN
                SET @TmpMsg = @TmpMsg +CHAR(13)+CHAR(10)+
                           'Expected State: '+CAST(@ExpectedState AS NVARCHAR(MAX))+CHAR(13)+CHAR(10)+
                           'Actual State  : '+CAST(ERROR_STATE() AS NVARCHAR(MAX));
                SET @Result = 'Failure';
              END
              IF(@Result = 'Failure')
              BEGIN
                SET @Msg = @TmpMsg;
              END
            END 
            ELSE
            BEGIN
                SET @Result = 'Failure';
                SET @Msg = 
                  COALESCE(@FailMessage+' ','')+
                  'Expected no error to be raised. Instead this error was encountered:'+
                  CHAR(13)+CHAR(10)+
                  @ErrorInfo;
            END
          END
          ELSE
          BEGIN
            SET @Result = 'Error';
            SET @Msg = @ErrorInfo;
          END  
        END;
    END CATCH

    BEGIN TRY
        ROLLBACK TRAN @TranName;
    END TRY
    BEGIN CATCH
        DECLARE @PostExecTrancount INT;
        SET @PostExecTrancount = @PreExecTrancount - @@TRANCOUNT;
        IF (@@TRANCOUNT > 0) ROLLBACK;
        BEGIN TRAN;
        IF(   @Result <> 'Success'
           OR @PostExecTrancount <> 0
          )
        BEGIN
          SELECT @Msg = COALESCE(@Msg, '<NULL>') + ' (There was also a ROLLBACK ERROR --> ' + COALESCE(ERROR_MESSAGE(), '<ERROR_MESSAGE() is NULL>') + '{' + COALESCE(ERROR_PROCEDURE(), '<ERROR_PROCEDURE() is NULL>') + ',' + COALESCE(CAST(ERROR_LINE() AS NVARCHAR), '<ERROR_LINE() is NULL>') + '})';
          SET @Result = 'Error';
        END
    END CATCH    

    If(@Result <> 'Success') 
    BEGIN
      SET @Msg2 = @TestName + ' failed: (' + @Result + ') ' + @Msg;
      EXEC tSQLt.Private_Print @Message = @Msg2, @Severity = 0;
    END

    IF EXISTS(SELECT 1 FROM tSQLt.TestResult WHERE Id = @TestResultId)
    BEGIN
        UPDATE tSQLt.TestResult SET
            Result = @Result,
            Msg = @Msg,
            TestEndTime = @TestEndTime
         WHERE Id = @TestResultId;
    END
    ELSE
    BEGIN
        INSERT tSQLt.TestResult(Class, TestCase, TranName, Result, Msg)
        SELECT @TestClassName, 
               @TestProcName,  
               '?', 
               'Error', 
               'TestResult entry is missing; Original outcome: ' + @Result + ', ' + @Msg;
    END    

    COMMIT;

    IF(@Verbose = 1)
    BEGIN
    SET @VerboseMsg = 'tSQLt.Run '''+@TestName+'''; --Finished';
      EXEC tSQLt.Private_Print @Message =@VerboseMsg, @Severity = 0;
    END;
    DECLARE @duration INT
    SELECT @duration=DATEDIFF(ms, TestStartTime, TestEndTime) FROM [tSQLt].[TestResult] where Name like '%'+@TestProcName+'%'  
	PRINT '<TestClass>'+@TestClassName+'</TestClass>'
	PRINT '<TestName>'+@TestProcName+'</TestName>'
	PRINT '<TestResult>'+@Result+'</TestResult>'
	PRINT '<TestMsg>'+@Msg+'</TestMsg>'
	PRINT '<TestMsg2>'+@Msg2+'</TestMsg2>'
	PRINT '<TestDuration>'+CAST(@duration As VARCHAR(100))+'</TestDuration>'
	PRINT '<TestEndTime>' + CONVERT(VARCHAR(10),GETDATE(),101) + ' ' + CONVERT(VARCHAR(8),GETDATE(),108) + '</TestEndTime>'
	PRINT '</TSQLT_TEST>'
END
GO
--
IF OBJECT_ID (N'dbo.ConvertIntDateToDateTime', N'FN') IS NOT NULL
    DROP FUNCTION ConvertIntDateToDateTime;
GO
CREATE FUNCTION dbo.ConvertIntDateToDateTime (@input INT)
RETURNS DATETIME
AS BEGIN
    DECLARE @Work DATETIME   
	IF (@input=0 OR @input=99999999)   
	  --SET @Work = CAST('1900-01-01' AS DATETIME)
	  SET @work = NULL
	ELSE 
      SET @Work = CAST(SUBSTRING(CAST(@input as varchar(10)),1,4)+'-'
			+SUBSTRING(CAST(@input as varchar(10)),5,2)+'-'
			+SUBSTRING(CAST(@input as varchar(10)),7,2) AS DATETIME)
    RETURN @work
END
GO

IF OBJECT_ID (N'dbo.ConvertIntDateToDateTime2', N'FN') IS NOT NULL
    DROP FUNCTION ConvertIntDateToDateTime2;
GO
CREATE FUNCTION dbo.ConvertIntDateToDateTime2 (@input INT)
RETURNS DATETIME
AS BEGIN
    DECLARE @Work DATETIME2   
	IF (@input=0 OR @input=99999999)   
	  --SET @Work = CAST('1900-01-01' AS DATETIME)
	  SET @work = NULL
	ELSE 
      SET @Work = CAST(SUBSTRING(CAST(@input as varchar(10)),1,4)+'-'
			+SUBSTRING(CAST(@input as varchar(10)),5,2)+'-'
			+SUBSTRING(CAST(@input as varchar(10)),7,2) AS DATETIME2)
    RETURN @work
END
GO

IF OBJECT_ID (N'dbo.ConvertDateTimeToDateTimeOffset7', N'FN') IS NOT NULL
    DROP FUNCTION ConvertDateTimeToDateTimeOffset7;
GO
CREATE FUNCTION dbo.ConvertDateTimeToDateTimeOffset7 (@input DATETIME)
RETURNS DATETIME
AS BEGIN
    DECLARE @Work DATETIMEOFFSET(7)   
    SET @Work = CAST(@input AS DATETIMEOFFSET(7))
    RETURN @work
END
GO

IF OBJECT_ID (N'dbo.FormAccountNumber', N'FN') IS NOT NULL
    DROP FUNCTION FormAccountNumber;
GO
CREATE FUNCTION dbo.FormAccountNumber (@brn INT,@acc INT,@sfx INT)
RETURNS VARCHAR(100)
AS BEGIN
    DECLARE @Work VARCHAR(100)
    SET @Work = RIGHT('0000' + CAST(@brn AS VARCHAR(4)), 4) + '-'
    		+ RIGHT('000000' + CAST(@acc AS VARCHAR(6)), 6) + '-'
			+ RIGHT('000' + CAST(@sfx AS VARCHAR(3)), 3)
/*SET @Work = RIGHT(REPLICATE('0', 5-DATALENGTH(CAST(@brn AS VARCHAR(5))))+CAST(@brn AS VARCHAR(5)),4)+'-'
			+RIGHT(REPLICATE('0', 7-DATALENGTH(CAST(@acc AS VARCHAR(7))))+CAST(@acc AS VARCHAR(7)),6)+'-'
			+RIGHT(REPLICATE('0', 4-DATALENGTH(CAST(@sfx AS VARCHAR(4))))+CAST(@sfx AS VARCHAR(4)),3)*/
    RETURN @work
END
GO

IF OBJECT_ID (N'dbo.FormAlternativeAccountNumber', N'FN') IS NOT NULL
    DROP FUNCTION FormAlternativeAccountNumber;
GO
CREATE FUNCTION dbo.FormAlternativeAccountNumber(@customerType VARCHAR(100),@brn INT,@acc INT,@sfx INT)
RETURNS VARCHAR(100)
AS BEGIN
    DECLARE @Work VARCHAR(100)
    SET @Work = RIGHT('0000' + CAST(@brn AS VARCHAR(4)), 4) + '-'
    		+ RIGHT('000000' + CAST(@acc AS VARCHAR(6)), 6) + '-'
			+ CASE @customerType WHEN 'individual' THEN SUBSTRING(RIGHT('000' + CAST(@sfx AS VARCHAR(3)), 3),1,2) WHEN 'organisation' THEN SUBSTRING(RIGHT('000' + CAST(@sfx AS VARCHAR(3)), 3),2,2) END 
    RETURN @work
END
GO


IF OBJECT_ID (N'dbo.FormPostBusinessKey', N'FN') IS NOT NULL
    DROP FUNCTION FormPostBusinessKey;
GO
CREATE FUNCTION dbo.FormPostBusinessKey (@brn INT,@user VARCHAR(5),@psd INT,@seq INT,@seq2 INT)
RETURNS VARCHAR(100)
AS BEGIN
    DECLARE @Work VARCHAR(100)
    SET @Work = RIGHT('0000' + CAST(@brn AS VARCHAR(4)), 4) + @user 
    		+ RIGHT('00000000' + CAST(@psd AS VARCHAR(8)), 8) 
			+ RIGHT('00000' + CAST(@seq AS VARCHAR(5)), 5) 
			+ RIGHT('00000' + CAST(@seq2 AS VARCHAR(5)), 5)
    RETURN @work
END
GO

IF OBJECT_ID (N'dbo.FormDealAccountNumber', N'FN') IS NOT NULL
    DROP FUNCTION FormDealAccountNumber;
GO
CREATE FUNCTION dbo.FormDealAccountNumber (@brn INT,@typ CHAR(3),@ref CHAR(13))
RETURNS VARCHAR(100)
AS BEGIN
    DECLARE @Work VARCHAR(100)
    SET @Work = RIGHT('0000' + CAST(@brn AS VARCHAR(4)), 4) + '-' + @typ + '-' + @ref
    RETURN @work
END
GO

-- {create type before creating function ...
--  delete function before deleting type  ...
IF OBJECT_ID (N'dbo.MapStringToInt', N'FN') IS NOT NULL
    DROP FUNCTION MapStringToInt;
GO
IF OBJECT_ID (N'dbo.MapIntToInt', N'FN') IS NOT NULL
    DROP FUNCTION MapIntToInt;
GO
IF OBJECT_ID (N'dbo.mapYNto10', N'FN') IS NOT NULL
    DROP FUNCTION mapYNto10;
GO
IF OBJECT_ID (N'dbo.mapYNto13', N'FN') IS NOT NULL
    DROP FUNCTION mapYNto13;
GO
IF OBJECT_ID (N'dbo.mapSpacetoDebitCredit', N'FN') IS NOT NULL
    DROP FUNCTION mapSpacetoDebitCredit;
GO
IF OBJECT_ID (N'dbo.map99999999toNull', N'FN') IS NOT NULL
    DROP FUNCTION map99999999toNull;
GO
IF OBJECT_ID (N'dbo.mapCharorOtherto10', N'FN') IS NOT NULL
    DROP FUNCTION mapCharorOtherto10;
GO
IF OBJECT_ID (N'dbo.mapDorOtherto10', N'FN') IS NOT NULL
    DROP FUNCTION mapDorOtherto10;
GO

IF OBJECT_ID (N'dbo.map1orOtherto01', N'FN') IS NOT NULL
    DROP FUNCTION map1orOtherto01;
GO
IF OBJECT_ID (N'dbo.mapBlockage', N'FN') IS NOT NULL
    DROP FUNCTION mapBlockage;
GO
IF OBJECT_ID (N'dbo.mapStatementFormat', N'FN') IS NOT NULL
    DROP FUNCTION mapStatementFormat;
GO
IF OBJECT_ID (N'dbo.map_d1sdr', N'FN') IS NOT NULL
    DROP FUNCTION map_d1sdr;
GO
IF OBJECT_ID (N'dbo.map_statement_period', N'FN') IS NOT NULL
    DROP FUNCTION map_statement_period;
GO
IF OBJECT_ID (N'dbo.map_values', N'FN') IS NOT NULL
    DROP FUNCTION map_values;
GO
--
IF TYPE_ID(N'dbo.mapStringtoIntList') IS NOT NULL
	DROP TYPE dbo.mapStringtoIntList
GO
CREATE TYPE dbo.mapStringtoIntList
AS TABLE
(
  strValue varchar(100), intValue INT
);
GO
IF TYPE_ID(N'dbo.mapInttoIntList') IS NOT NULL
	DROP TYPE dbo.mapInttoIntList
GO
CREATE TYPE dbo.mapInttoIntList
AS TABLE
(
  intSourceValue INT, intTargetValue INT
);
GO
IF TYPE_ID(N'dbo.mapList') IS NOT NULL
	DROP TYPE dbo.mapList
GO
CREATE TYPE dbo.mapList
AS TABLE
(
  inputValue SQL_VARIANT, outputValue SQL_VARIANT
);
GO
--
CREATE FUNCTION dbo.MapStringToInt (@mapValues dbo.mapStringtoIntList READONLY, @strInput varchar(100))
RETURNS INT
AS BEGIN
    DECLARE @Work VARCHAR(100)
    DECLARE @DefaultWork VARCHAR(100)
    IF EXISTS(SELECT intValue FROM @mapValues WHERE strValue = '$Default')
    BEGIN
    	SELECT @DefaultWork = intValue FROM @mapValues WHERE strValue = '$Default'
    	SELECT @Work = ISNULL(intValue,@DefaultWork) FROM @mapValues WHERE strValue = @strInput
    END
    ELSE
    	SELECT @Work = intValue FROM @mapValues WHERE strValue = @strInput
    RETURN @work
END
GO
CREATE FUNCTION dbo.MapIntToInt (@mapValues dbo.mapInttoIntList READONLY, @intInput INT, @defaultIntValue INT)
RETURNS INT
AS BEGIN
    DECLARE @Work INT
    SELECT @Work = ISNULL(intTargetValue,@defaultIntValue) FROM @mapValues WHERE intSourceValue = @intInput
    RETURN @work
END
GO
CREATE FUNCTION dbo.mapYNto10 (@sourceField VARCHAR(100))
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapStringtoIntList
	INSERT INTO @mapValues VALUES ('$Default',0)
	INSERT INTO @mapValues VALUES ('Y',1)
	INSERT INTO @mapValues VALUES ('N',0)
    RETURN dbo.MapStringToInt(@mapValues, @sourceField)
END
GO
CREATE FUNCTION dbo.mapYNto13 (@sourceField VARCHAR(100))
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapStringtoIntList
	INSERT INTO @mapValues VALUES ('Y',1)
	INSERT INTO @mapValues VALUES ('N',3)
    RETURN dbo.MapStringToInt(@mapValues, @sourceField)
END
GO
CREATE FUNCTION dbo.mapSpacetoDebitCredit (@sourceField VARCHAR(100))
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapStringtoIntList
	INSERT INTO @mapValues VALUES ('$Default',0)
	INSERT INTO @mapValues VALUES ('',1)
    RETURN dbo.MapStringToInt(@mapValues, @sourceField)
END
GO
CREATE FUNCTION dbo.map99999999toNull (@sourceField INT)
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapInttoIntList
	INSERT INTO @mapValues VALUES (99999999,19000101) --NULL olursa alan de�erlerinin e�itli�i kontrol edilirken <> olan conditionda hata al�n�yor. bu nedenle valid bir tarih kondu.
	IF (@sourceField <> 99999999) INSERT INTO @mapValues VALUES (@sourceField,@sourceField) --gelen de�er 99999999 olmad���nda da de�er NULL oluyor. Giren de�erin de�i�memesi sa�land�.
    RETURN dbo.MapIntToInt(@mapValues, @sourceField,19000101)
END
GO
CREATE FUNCTION dbo.mapBlockage(@sourceField INT)
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapInttoIntList
	INSERT INTO @mapValues VALUES (1,0)
	INSERT INTO @mapValues VALUES (2,1)
	INSERT INTO @mapValues VALUES (3,2)
	INSERT INTO @mapValues VALUES (4,3)
	INSERT INTO @mapValues VALUES (5,6)
	INSERT INTO @mapValues VALUES (6,4)
	INSERT INTO @mapValues VALUES (7,5)
	INSERT INTO @mapValues VALUES (8,7)
    RETURN dbo.MapIntToInt(@mapValues, @sourceField, NULL)
END
GO
CREATE FUNCTION dbo.mapStatementFormat(@sourceField VARCHAR(1))
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapStringtoIntList
	INSERT INTO @mapValues VALUES ('$Default',NULL)
	INSERT INTO @mapValues VALUES ('E',2)
	INSERT INTO @mapValues VALUES ('F',2)
	INSERT INTO @mapValues VALUES ('M',2)
	INSERT INTO @mapValues VALUES ('S',3)
	INSERT INTO @mapValues VALUES ('T',4)
    RETURN dbo.MapStringToInt(@mapValues, @sourceField)
END
GO
CREATE FUNCTION dbo.mapCharorOtherto10 (@sourceField VARCHAR(100),@strValue VARCHAR(100))
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapStringtoIntList
	INSERT INTO @mapValues VALUES ('$Default',0)
	INSERT INTO @mapValues VALUES (@strValue,1)
    RETURN dbo.MapStringToInt(@mapValues, @sourceField)
END
GO
CREATE FUNCTION dbo.map1orOtherto01(@sourceField INT)
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapInttoIntList
	INSERT INTO @mapValues VALUES (1,0)
    RETURN dbo.MapIntToInt(@mapValues, @sourceField, 1)
END
GO
CREATE FUNCTION dbo.map_d1sdr(@sourceField INT)
RETURNS INT
AS BEGIN
	DECLARE @mapValues dbo.mapStringtoIntList
	INSERT INTO @mapValues VALUES ('$Default',0)
	INSERT INTO @mapValues VALUES ('M',1)
	INSERT INTO @mapValues VALUES ('R',2)
    RETURN dbo.MapStringToInt(@mapValues, @sourceField)
END
GO
CREATE FUNCTION dbo.map_statement_period(@sourceField sql_variant)
RETURNS sql_variant
AS BEGIN
	DECLARE @s sql_variant, @i sql_variant
	SET @s = dbo.map_values(@sourceField,'Y','A','Y','B','Y','C','Y','D','Y','E','Y','F','Y','G','Y','H','Y','I','Y','J','Y','K','Y','L','Y','M','H','N','H','O','H','P','H','Q','H','R','H','S','Q','T','Q','U','Q','V','V','Z','Z','W','W',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
	SET @i = dbo.map_values(@s,0,'Z',1,'W',2,'Q',3,'H',4,'Y',5,'V',8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
    RETURN @i
END
GO
CREATE FUNCTION dbo.map_values(@input SQL_VARIANT,
									@default_value SQL_VARIANT,
									@key0 SQL_VARIANT, @value0 SQL_VARIANT,
									@key1 SQL_VARIANT, @value1 SQL_VARIANT,
									@key2 SQL_VARIANT, @value2 SQL_VARIANT,
									@key3 SQL_VARIANT, @value3 SQL_VARIANT,
									@key4 SQL_VARIANT, @value4 SQL_VARIANT,
									@key5 SQL_VARIANT, @value5 SQL_VARIANT,
									@key6 SQL_VARIANT, @value6 SQL_VARIANT,
									@key7 SQL_VARIANT, @value7 SQL_VARIANT,
									@key8 SQL_VARIANT, @value8 SQL_VARIANT,
									@key9 SQL_VARIANT, @value9 SQL_VARIANT,
									@key10 SQL_VARIANT, @value10 SQL_VARIANT,
									@key11 SQL_VARIANT, @value11 SQL_VARIANT,
									@key12 SQL_VARIANT, @value12 SQL_VARIANT,
									@key13 SQL_VARIANT, @value13 SQL_VARIANT,
									@key14 SQL_VARIANT, @value14 SQL_VARIANT,
									@key15 SQL_VARIANT, @value15 SQL_VARIANT,
									@key16 SQL_VARIANT, @value16 SQL_VARIANT,
									@key17 SQL_VARIANT, @value17 SQL_VARIANT,
									@key18 SQL_VARIANT, @value18 SQL_VARIANT,
									@key19 SQL_VARIANT, @value19 SQL_VARIANT,
									@key20 SQL_VARIANT, @value20 SQL_VARIANT,
									@key21 SQL_VARIANT, @value21 SQL_VARIANT,
									@key22 SQL_VARIANT, @value22 SQL_VARIANT,
									@key23 SQL_VARIANT, @value23 SQL_VARIANT,
									@key24 SQL_VARIANT, @value24 SQL_VARIANT,
									@key25 SQL_VARIANT, @value25 SQL_VARIANT,
									@key26 SQL_VARIANT, @value26 SQL_VARIANT,
									@key27 SQL_VARIANT, @value27 SQL_VARIANT,
									@key28 SQL_VARIANT, @value28 SQL_VARIANT,
									@key29 SQL_VARIANT, @value29 SQL_VARIANT)
RETURNS SQL_VARIANT
AS BEGIN
	DECLARE @mapValues dbo.mapList
	DECLARE @output SQL_VARIANT
	
	INSERT INTO @mapValues VALUES (@key0,@value0)
	INSERT INTO @mapValues VALUES (@key1,@value1)
	INSERT INTO @mapValues VALUES (@key2,@value2)
	INSERT INTO @mapValues VALUES (@key3,@value3)
	INSERT INTO @mapValues VALUES (@key4,@value4)
	INSERT INTO @mapValues VALUES (@key5,@value5)
	INSERT INTO @mapValues VALUES (@key6,@value6)
	INSERT INTO @mapValues VALUES (@key7,@value7)
	INSERT INTO @mapValues VALUES (@key8,@value8)
	INSERT INTO @mapValues VALUES (@key9,@value9)
	INSERT INTO @mapValues VALUES (@key10,@value10)
	INSERT INTO @mapValues VALUES (@key11,@value11)
	INSERT INTO @mapValues VALUES (@key12,@value12)
	INSERT INTO @mapValues VALUES (@key13,@value13)
	INSERT INTO @mapValues VALUES (@key14,@value14)
	INSERT INTO @mapValues VALUES (@key15,@value15)
	INSERT INTO @mapValues VALUES (@key16,@value16)
	INSERT INTO @mapValues VALUES (@key17,@value17)
	INSERT INTO @mapValues VALUES (@key18,@value18)
	INSERT INTO @mapValues VALUES (@key19,@value19)
	INSERT INTO @mapValues VALUES (@key20,@value20)
	INSERT INTO @mapValues VALUES (@key21,@value21)
	INSERT INTO @mapValues VALUES (@key22,@value22)
	INSERT INTO @mapValues VALUES (@key23,@value23)
	INSERT INTO @mapValues VALUES (@key24,@value24)
	INSERT INTO @mapValues VALUES (@key25,@value25)
	INSERT INTO @mapValues VALUES (@key26,@value26)
	INSERT INTO @mapValues VALUES (@key27,@value27)
	INSERT INTO @mapValues VALUES (@key28,@value28)
	INSERT INTO @mapValues VALUES (@key29,@value29)	

    SELECT @output = ISNULL(outputValue,@default_value) FROM @mapValues WHERE inputValue = @input
    RETURN @output
END
GO
-- }
IF OBJECT_ID (N'dbo.CheckWFieldZeroOrNot', N'P') IS NOT NULL
    DROP PROCEDURE dbo.CheckWFieldZeroOrNot;
GO
CREATE PROCEDURE CheckWFieldZeroOrNot 
	@TargetTableSchema VARCHAR(MAX),
	@TargetTable VARCHAR(MAX),
	@TargetField VARCHAR(MAX),
	@actual INT OUTPUT
AS 
	DECLARE @ExecQuery VARCHAR(MAX), @Schema VARCHAR(100)
	SET @Schema = @TargetTableSchema + CASE @TargetTableSchema WHEN '' THEN '' ELSE '.' END
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT;
	CREATE TABLE #TEMPTRESULT (QueryResult INT);
    SET @ExecQuery ='DECLARE @actual INT '
				+';SET @actual=(SELECT COUNT(*) FROM {RALLY_TABLE} WHERE {RALLY_FIELD_AS_TARGET} <> 0) ' 
				+';INSERT INTO #TEMPTRESULT VALUES (@actual)'  
				+';PRINT ''Count of records {RALLY_FIELD_AS_TARGET} values are not zero ... '' + ISNULL(CAST(@actual AS VARCHAR(100)),0);'
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TABLE}',@Schema+@TargetTable)
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_FIELD_AS_TARGET}',@TargetField)
	EXEC (@ExecQuery)
	SELECT @actual=MAX(QueryResult) FROM #TEMPTRESULT
GO

IF OBJECT_ID (N'dbo.CheckWFieldNullOrNot', N'P') IS NOT NULL
    DROP PROCEDURE dbo.CheckWFieldNullOrNot;
GO
CREATE PROCEDURE CheckWFieldNullOrNot 
	@TargetTableSchema VARCHAR(MAX),
	@TargetTable VARCHAR(MAX),
	@TargetField VARCHAR(MAX),
	@actual INT OUTPUT
AS 
	DECLARE @ExecQuery VARCHAR(MAX), @Schema VARCHAR(100)
	SET @Schema = @TargetTableSchema + CASE @TargetTableSchema WHEN '' THEN '' ELSE '.' END
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT;
	CREATE TABLE #TEMPTRESULT (QueryResult INT);
    SET @ExecQuery ='DECLARE @actual INT'
				+';SET @actual=(SELECT COUNT(*) FROM {RALLY_TABLE} WHERE {RALLY_FIELD_AS_TARGET} IS NOT NULL) ' 
				+';INSERT INTO #TEMPTRESULT VALUES (@actual)'  
				+';PRINT ''Count of records {RALLY_FIELD_AS_TARGET} values are not zero ... '' + ISNULL(CAST(@actual AS VARCHAR(100)),0);'
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TABLE}',@Schema+@TargetTable)
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_FIELD_AS_TARGET}',@TargetField)
	EXEC (@ExecQuery)
	SELECT @actual=MAX(QueryResult) FROM #TEMPTRESULT
GO

IF OBJECT_ID (N'dbo.CheckWFieldEqualToValue', N'P') IS NOT NULL
    DROP PROCEDURE dbo.CheckWFieldEqualToValue;
GO
CREATE PROCEDURE CheckWFieldEqualToValue 
	@TargetTableSchema VARCHAR(MAX),
	@TargetTable VARCHAR(MAX),
	@TargetField VARCHAR(MAX),
	@Value SQL_VARIANT,
	@actual INT OUTPUT
AS 
	DECLARE @ExecQuery VARCHAR(MAX), @Schema VARCHAR(100)
	SET @Schema = @TargetTableSchema + CASE @TargetTableSchema WHEN '' THEN '' ELSE '.' END
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT;
	CREATE TABLE #TEMPTRESULT (QueryResult INT);
    SET @ExecQuery ='DECLARE @actual INT'
				+';SET @actual=(SELECT COUNT(*) FROM {RALLY_TABLE} WHERE {RALLY_FIELD_AS_TARGET} <>' + CAST(@Value AS VARCHAR(MAX)) + ' ) ' 
				+';INSERT INTO #TEMPTRESULT VALUES (@actual)'  
				+';PRINT ''Count of records {RALLY_FIELD_AS_TARGET} values are not zero ... '' + ISNULL(CAST(@actual AS VARCHAR(100)),0);'
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TABLE}',@Schema+@TargetTable)
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_FIELD_AS_TARGET}',@TargetField)
	EXEC (@ExecQuery)
	SELECT @actual=MAX(QueryResult) FROM #TEMPTRESULT
GO

IF OBJECT_ID (N'dbo.CheckWFieldsAreEqualOrNotV1', N'P') IS NOT NULL
    DROP PROCEDURE dbo.CheckWFieldsAreEqualOrNotV1;
GO
CREATE PROCEDURE CheckWFieldsAreEqualOrNotV1 
@TestName VARCHAR(500),
@TargetTable VARCHAR(500),  --   @TargetTable
@TargetField VARCHAR(500),  --   @TargetField
@SourceTable VARCHAR(500),  --   @SourceTable
@SourceField VARCHAR(500),  --   @SourceField
@RallyJoinTable VARCHAR(500),  --   @VerifyCondition2
@RallyJoinField VARCHAR(500),  --   @VerifyCondition3
@TargetJoinField VARCHAR(500),  --   @VerifyCondition4
@TargetJoinCondition VARCHAR(500),  --   @VerifyCondition5
@TargetInnerJoinCondition VARCHAR(500),
@IsubaJoinTable VARCHAR(500),  --   @VerifyCondition6
@IsubaJoinField VARCHAR(500),  --   @VerifyCondition7
@SourceJoinField VARCHAR(500),  --   @VerifyCondition8
@SourceJoinCondition VARCHAR(500),  --   @VerifyCondition9
@SourceInnerJoinCondition VARCHAR(500),
@actual INT OUTPUT,
@TargetCount INT OUTPUT,
@SourceCount INT OUTPUT
AS 	
	--PRINT 'TEST STARTED : ' + @TestName
	/*
	PRINT 'Input Parameters : ' + @TestName
	PRINT '@TestName  :  '; PRINT @TestName
	PRINT '@TargetTable  :  '; PRINT @TargetTable
	PRINT '@TargetField  :  '; PRINT @TargetField
	PRINT '@SourceTable  :  '; PRINT @SourceTable
	PRINT '@SourceField  :  '; PRINT @SourceField
	PRINT '@RallyJoinTable  :  '; PRINT @RallyJoinTable
	PRINT '@RallyJoinField  :  '; PRINT @RallyJoinField
	PRINT '@TargetJoinField  :  '; PRINT @TargetJoinField
	PRINT '@TargetJoinCondition  :  '; PRINT @TargetJoinCondition
	PRINT '@TargetInnerJoinCondition  :  '; PRINT @TargetInnerJoinCondition
	PRINT '@IsubaJoinTable  :  '; PRINT @IsubaJoinTable
	PRINT '@IsubaJoinField  :  '; PRINT @IsubaJoinField
	PRINT '@SourceJoinField  :  '; PRINT @SourceJoinField
	PRINT '@SourceJoinCondition  :  '; PRINT @SourceJoinCondition
	PRINT '@SourceInnerJoinCondition  :  '; PRINT @SourceInnerJoinCondition	
	 */
	DECLARE @ExecQuery VARCHAR(MAX), @Index INT, @start INT, @PlaceHolder_RALLY_TARGET_TABLE VARCHAR(100), @PlaceHolder_ISUBA_SOURCE_TABLE VARCHAR(100), @PrintPlaceHolder VARCHAR(MAX), @TextHolder VARCHAR(500), @ConditionHolder VARCHAR(500)
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT
	CREATE TABLE #TEMPTRESULT (QueryResult INT, TargetCount INT, SourceCount INT);
	SET @PlaceHolder_RALLY_TARGET_TABLE = '{RALLY_TARGET_TABLE}.'
	SET @PlaceHolder_ISUBA_SOURCE_TABLE = '{ISUBA_SOURCE_TABLE}.'
	SET @ExecQuery ='IF (OBJECT_ID(''tempdb..#TEMPTRESULT'') IS NULL) ' + CHAR(13)+CHAR(10)
		+'  CREATE TABLE #TEMPTRESULT (QueryResult INT, TargetCount INT, SourceCount INT);' + CHAR(13)+CHAR(10)
		+'DECLARE @actual INT, @checkTarget INT, @checkSource INT, @s INT ' + CHAR(13)+CHAR(10)
    	+';PRINT '+''''+'Test {RALLY_TARGET_FIELD_PRINT} does not match {ISUBA_SOURCE_FIELD_PRINT}'+''''+ CHAR(13)+CHAR(10)
		+';IF OBJECT_ID(''tempdb..#TempRally'') IS NOT NULL DROP TABLE #TempRally '+ CHAR(13)+CHAR(10)
		+';IF OBJECT_ID(''tempdb..#TempIsuba'') IS NOT NULL DROP TABLE #TempIsuba '+ CHAR(13)+CHAR(10)
		+';SELECT * INTO #TempRally FROM ( '+ CHAR(13)+CHAR(10)
		+'   SELECT {RALLY_JOIN_TABLE}{RALLY_JOIN_FIELD} AS Join_Field_Ra, {RALLY_TARGET_FIELD} AS Check_Field_Ra FROM {RALLY_TARGET_TABLE} {TARGET_INNER_JOIN} {RALLY_INNER_JOIN_ON} {RALLY_JOIN_CONDITION} ' 	
		+' ) TempRa '+ CHAR(13)+CHAR(10)
		+';SELECT * INTO #TempIsuba FROM ( '+ CHAR(13)+CHAR(10)
		+'   SELECT {ISUBA_JOIN_TABLE}{ISUBA_JOIN_FIELD} AS Join_Field_Is, {ISUBA_SOURCE_FIELD} AS Check_Field_Is FROM {ISUBA_SOURCE_TABLE} {SOURCE_INNER_JOIN} {ISUBA_INNER_JOIN_ON} {ISUBA_JOIN_CONDITION} ' 	
		+' ) TempIs '+ CHAR(13)+CHAR(10)		
		+';SELECT @checkTarget=COUNT(*) FROM #TempRally ' + CHAR(13)+CHAR(10)
		+';PRINT ''Count of records {RALLY_TARGET_FIELD_PRINT} join ... '' + ISNULL(CAST(@checkTarget AS VARCHAR(100)),0) '+ CHAR(13)+CHAR(10)	
		+';SELECT @checkSource=COUNT(*) FROM #TempIsuba ' + CHAR(13)+CHAR(10)
		+';PRINT ''Count of records {ISUBA_SOURCE_FIELD_PRINT} join ... '' + ISNULL(CAST(@checkSource AS VARCHAR(100)),0) '+ CHAR(13)+CHAR(10)
		+';{EMPTY_SET_PLACEHOLDER} '+ CHAR(13)+CHAR(10)
		+';IF ((@checkTarget>0) AND (@checkSource=0) AND @s=1) OR ((@checkTarget=0) AND (@checkSource>0)) '+ CHAR(13)+CHAR(10)
		+'   BEGIN '+ CHAR(13)+CHAR(10)
		+'     ;SET @actual = 999999 '+ CHAR(13)+CHAR(10)
		+'     ;PRINT '' <Empty Set> ''' + CHAR(13)+CHAR(10)
		+'   END '+ CHAR(13)+CHAR(10)
   		+'   ELSE '+ CHAR(13)+CHAR(10)
	   	+'   BEGIN '+ CHAR(13)+CHAR(10)		
		+'     ;SET @actual=(SELECT COUNT(*) FROM #TempRally INNER JOIN #TempIsuba ON Join_Field_Ra = Join_Field_Is WHERE {TEST CONDITION} ) '+ CHAR(13)+CHAR(10)
		+'     --;PRINT ''...Sample List...'';'+ CHAR(13)+CHAR(10)
		+'     --;SELECT TOP 5 * FROM #TempRally INNER JOIN #TempIsuba ON Join_Field_Ra = Join_Field_Is WHERE {TEST CONDITION}  '+ CHAR(13)+CHAR(10)
		+'     ;INSERT INTO #TEMPTRESULT VALUES (@actual,@checkTarget,@checkTarget) '+ CHAR(13)+CHAR(10)
		+'     ;PRINT ''.................'';'+ CHAR(13)+CHAR(10)		
		+'     ;PRINT ''Count of records {RALLY_TARGET_FIELD_PRINT} does not match {ISUBA_SOURCE_FIELD_PRINT} ... '' + ISNULL(CAST(@actual AS VARCHAR(100)),0);'+ CHAR(13)+CHAR(10)
	   	+'   END '+ CHAR(13)+CHAR(10)		
	   	
	--PRINT ' '
	--PRINT 'RAW QUERY...'
	--PRINT @ExecQuery
	
	--!!!BURADA SIRALAMA �NEML� DE���T�RMEY�N!!! 
	--SET @TargetField = CASE WHEN SUBSTRING(@TargetField,1,4)='dbo.' THEN @TargetField ELSE REPLACE(REPLACE(@TargetField,'(',''),')','') END
	--SET @SourceField = CASE WHEN SUBSTRING(@SourceField,1,4)='dbo.' THEN @SourceField ELSE REPLACE(REPLACE(@SourceField,'(',''),')','') END

	--PRINT '@SourceField>'+@SourceField+'<'
	SET @Index = CHARINDEX('%',@SourceField)
	IF (@Index>0) BEGIN
		SET @start = @Index + 1 
		SET @Index = CHARINDEX('%',@SourceField, @start)
		SET @TextHolder = LTRIM(RTRIM(SUBSTRING(@SourceField,@start,@Index-@start)))
		--PRINT 'Part 1>'+@TextHolder+'<'
		
		SET @start = @Index + 1 
		SET @Index = CHARINDEX('%',@SourceField, @start)
		PRINT 'Part 2>'+LTRIM(RTRIM(SUBSTRING(@SourceField,@start,@Index-@start)))+'<'
		SET @ConditionHolder = LTRIM(RTRIM(SUBSTRING(@SourceField,@Index+1,LEN(@SourceField)-@start)))		
		SET @SourceField =  LTRIM(RTRIM(SUBSTRING(@SourceField,@start,@Index-@start)))
		--PRINT 'Part 3>'+@ConditionHolder+'<'
		--PRINT '@SourceField>'+@SourceField+'<'
		SET @ExecQuery = REPLACE(@ExecQuery,@TextHolder,'')
	END
	ELSE
		SET @ConditionHolder = ''
	
	SET @Index = CHARINDEX('>',@TargetField)
	IF (@Index>0) BEGIN
		SET @TargetField = SUBSTRING(@TargetField,@Index+1,LEN(@TargetField)-@Index)
		SET @PlaceHolder_RALLY_TARGET_TABLE = ''
	END
	SET @Index = CHARINDEX('>',@SourceField)
	IF (@Index>0) BEGIN
		SET @SourceField = SUBSTRING(@SourceField,@Index+1,LEN(@SourceField)-@Index)
		SET @PlaceHolder_ISUBA_SOURCE_TABLE = ''
	END

	SET @Index = CHARINDEX('#',@SourceField)
	SET @ExecQuery = REPLACE(@ExecQuery,'{TEST CONDITION}', CASE WHEN @ConditionHolder <> '' THEN @ConditionHolder WHEN @Index > 0 THEN  ' Check_Field_Ra ' + REPLACE(@SourceField,'#','') ELSE ' Check_Field_Ra <> Check_Field_Is '  END)
	SET @ExecQuery = REPLACE(@ExecQuery,'{EMPTY_SET_PLACEHOLDER}', CASE WHEN @Index > 0 THEN 'SET @s = 0 ' ELSE 'SET @s = 1 ' END)
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_FIELD}',CASE WHEN SUBSTRING(@TargetField,1,3)='dbo' THEN @TargetField ELSE @PlaceHolder_RALLY_TARGET_TABLE+@TargetField END) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_FIELD}',CASE WHEN SUBSTRING(@SourceField,1,3)='dbo' THEN @SourceField WHEN @Index > 0 THEN '""' ELSE @PlaceHolder_ISUBA_SOURCE_TABLE+@SourceField END)
	
	--SET @ExecQuery = REPLACE(@ExecQuery,'<Value>','<value>')	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_TABLE}.&','')
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_TABLE}.&','')
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_TABLE}.&','')
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_TABLE}.&','')
	--SET @ExecQuery = REPLACE(@ExecQuery,'<value>','')
	
	SET @Index = CHARINDEX('{RALLY}.',@SourceTable)
	IF (@Index>0) BEGIN
		SET @SourceTable = REPLACE(@SourceTable,'{RALLY}.','')
	END
	ELSE BEGIN
		SET @SourceTable = '{ISUBADB}.' + @SourceTable
	END	
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_TABLE}',@TargetTable)
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_TABLE}',@SourceTable)
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_TABLE}',CASE WHEN @RallyJoinTable='' THEN '' ELSE @RallyJoinTable+'.' END) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_FIELD}',@RallyJoinField) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_INNER_JOIN_ON}',CASE WHEN @TargetJoinField='' THEN '' ELSE ' INNER JOIN '+@RallyJoinTable+' ON '+@TargetTable+'.'+@TargetJoinField+'='+@RallyJoinTable+'.id' END)
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_CONDITION}',CASE WHEN @TargetJoinCondition='' THEN '' ELSE ' WHERE '+@TargetJoinCondition END)
	SET @ExecQuery = REPLACE(@ExecQuery,'{TARGET_INNER_JOIN}',@TargetInnerJoinCondition)
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_TABLE}',CASE WHEN @IsubaJoinTable='' THEN '' ELSE @IsubaJoinTable+'.' END) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_FIELD}',@IsubaJoinField) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_INNER_JOIN_ON}',CASE WHEN @SourceJoinField='' THEN '' ELSE ' INNER JOIN '+@SourceJoinField+' ON '+@SourceTable+'.'+@SourceJoinField+'='+@IsubaJoinTable+'.'+@IsubaJoinField END)
	SET @ExecQuery = REPLACE(@ExecQuery,'{SOURCE_INNER_JOIN}',@SourceInnerJoinCondition)
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_CONDITION}',CASE WHEN @SourceJoinCondition='' THEN '' ELSE ' WHERE '+@SourceJoinCondition END)
	
	SET @TargetField = REPLACE(@TargetField,'"','')
	SET @PrintPlaceHolder = @TargetTable+'.'+CASE WHEN SUBSTRING(@TargetField,1,4)='dbo.' THEN RIGHT(@TargetField,LEN(@TargetField)-CHARINDEX('(', @TargetField)+1) ELSE @TargetField END
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_FIELD_PRINT}',@PrintPlaceHolder)
	SET @SourceField = REPLACE(@SourceField,'"','')
	SET @PrintPlaceHolder = @SourceTable+'.'+CASE WHEN SUBSTRING(@SourceField,1,4)='dbo.' THEN RIGHT(@SourceField,LEN(@SourceField)-CHARINDEX('(', @SourceField)+1)  ELSE @SourceField END
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_FIELD_PRINT}',@PrintPlaceHolder)
	SET @ExecQuery = REPLACE(@ExecQuery,'"','''')
	--SET @ExecQuery = REPLACE(@ExecQuery,'<chr>','''')
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBADB}.','{ISUBA}.')
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA}.','ydsm0648.ydsm.')

	--PRINT ' '
	PRINT 'EXECUTED QUERY...'
	PRINT @ExecQuery
	PRINT '-----------------'
	EXEC (@ExecQuery)
	SELECT @actual=MAX(QueryResult) FROM #TEMPTRESULT
	SELECT @TargetCount=MAX(TargetCount) FROM #TEMPTRESULT
	SELECT @SourceCount=MAX(SourceCount) FROM #TEMPTRESULT
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT;
	PRINT 'TEST RESULTS : ' + @TestName
GO

IF OBJECT_ID (N'dbo.CheckWFieldsAreEqualOrNot', N'P') IS NOT NULL
    DROP PROCEDURE dbo.CheckWFieldsAreEqualOrNot;
GO
CREATE PROCEDURE CheckWFieldsAreEqualOrNot
@TestName VARCHAR(100),
@TargetTableSchema VARCHAR(MAX),  --   @TargetTableSchema
@TargetTable VARCHAR(MAX),  --   @TargetTable
@TargetField VARCHAR(MAX),  --   @TargetField
@SourceTable VARCHAR(MAX),  --   @SourceTable
@SourceField VARCHAR(MAX),  --   @SourceField
@RallyJoinTable VARCHAR(MAX),  --   @VerifyCondition2
@RallyJoinField VARCHAR(MAX),  --   @VerifyCondition3
@TargetJoinField VARCHAR(MAX),  --   @VerifyCondition4
@TargetJoin VARCHAR(MAX),  --   @VerifyCondition5
@TargetInnerJoinCondition VARCHAR(MAX),
@IsubaJoinTable VARCHAR(MAX),  --   @VerifyCondition6
@IsubaJoinField VARCHAR(MAX),  --   @VerifyCondition7
@SourceJoinField VARCHAR(MAX),  --   @VerifyCondition8
@SourceJoin VARCHAR(MAX),  --   @VerifyCondition9
@SourceInnerJoinCondition VARCHAR(MAX),
@actual INT OUTPUT,
@TargetCount INT OUTPUT,
@SourceCount INT OUTPUT
AS 	
	--PRINT 'TEST STARTED : ' + @TestName
	/*
	PRINT 'Input Parameters : ' + @TestName
	PRINT '@TestName  :  '; PRINT @TestName
	PRINT '@TargetTableSchema  :  '; PRINT @TargetTableSchema
	PRINT '@TargetTable  :  '; PRINT @TargetTable
	PRINT '@TargetField  :  '; PRINT @TargetField
	PRINT '@SourceTable  :  '; PRINT @SourceTable
	PRINT '@SourceField  :  '; PRINT @SourceField
	PRINT '@RallyJoinTable  :  '; PRINT @RallyJoinTable
	PRINT '@RallyJoinField  :  '; PRINT @RallyJoinField
	PRINT '@TargetJoinField  :  '; PRINT @TargetJoinField
	PRINT '@TargetJoin  :  '; PRINT @TargetJoin
	PRINT '@TargetInnerJoinCondition  :  '; PRINT @TargetInnerJoinCondition
	PRINT '@IsubaJoinTable  :  '; PRINT @IsubaJoinTable
	PRINT '@IsubaJoinField  :  '; PRINT @IsubaJoinField
	PRINT '@SourceJoinField  :  '; PRINT @SourceJoinField
	PRINT '@SourceJoin  :  '; PRINT @SourceJoin
	PRINT '@SourceInnerJoinCondition  :  '; PRINT @SourceInnerJoinCondition	
	 */
	DECLARE @ExecQuery VARCHAR(MAX), @ExecQueryO VARCHAR(MAX), @Index INT, @start INT, @PlaceHolder_RALLY_TARGET_TABLE VARCHAR(100), @PlaceHolder_ISUBA_SOURCE_TABLE VARCHAR(100), @PrintPlaceHolder VARCHAR(MAX), @TextHolder VARCHAR(MAX), @ConditionHolder VARCHAR(MAX)
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT
	CREATE TABLE #TEMPTRESULT (QueryResult INT, TargetCount INT, SourceCount INT);
	--CHECK FIELDS EQUAL
	--PRINT '*** CHECK FIELDS EQUAL ***'
	SET @ExecQuery ='IF (OBJECT_ID(''tempdb..#TEMPTRESULT'') IS NULL) ' + CHAR(13)+CHAR(10)
		+'  CREATE TABLE #TEMPTRESULT (QueryResult INT, TargetCount INT, SourceCount INT);' + CHAR(13)+CHAR(10)
		+'DECLARE @actual INT, @checkTarget INT, @checkSource INT, @s INT,@duration INT, @st DATETIME, @et DATETIME ' + CHAR(13)+CHAR(10)
    	+';PRINT '+''''+'Test {RALLY_TARGET_FIELD_PRINT} does not match {ISUBA_SOURCE_FIELD_PRINT}'+''''+ CHAR(13)+CHAR(10)
		+';IF OBJECT_ID(''tempdb..#TempRally'') IS NOT NULL DROP TABLE #TempRally '+ CHAR(13)+CHAR(10)
		+';IF OBJECT_ID(''tempdb..#TempIsuba'') IS NOT NULL DROP TABLE #TempIsuba '+ CHAR(13)+CHAR(10)
		+';SET @st=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CreateTempRallyStartTime>'' + CONVERT(VARCHAR(10),@st,101) + '' '' + CONVERT(VARCHAR(8),@st,108) + ''</CreateTempRallyStartTime>'''+ CHAR(13)+CHAR(10)
		+';SELECT * INTO #TempRally FROM ( '+ CHAR(13)+CHAR(10)
		+'   SELECT {RALLY_JOIN_TABLE}{RALLY_JOIN_FIELD} AS Join_Field_Ra, {RALLY_TARGET_FIELD} AS Check_Field_Ra FROM {RALLY_TARGET_TABLE} {TARGET_INNER_JOIN} {RALLY_INNER_JOIN_ON} {RALLY_JOIN_CONDITION} ' 	
		+' ) TempRa '+ CHAR(13)+CHAR(10)
		+';SET @et=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CreateTempRallyEndTime>'' + CONVERT(VARCHAR(10),@et,101) + '' '' + CONVERT(VARCHAR(8),@et,108) + ''</CreateTempRallyEndTime>'''+ CHAR(13)+CHAR(10)
		+';SET @duration=DATEDIFF(ms, @st, @et)'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CreateTempRallyDuration>'' +CAST(@duration As VARCHAR(100))+ ''</CreateTempRallyDuration>'''+ CHAR(13)+CHAR(10)
		+';SET @st=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CreateTempIsubaStartTime>'' + CONVERT(VARCHAR(10),@st,101) + '' '' + CONVERT(VARCHAR(8),@st,108) + ''</CreateTempIsubaStartTime>'''+ CHAR(13)+CHAR(10)
		+';SELECT * INTO #TempIsuba FROM ( '+ CHAR(13)+CHAR(10)
		+'   SELECT {ISUBA_JOIN_TABLE}{ISUBA_JOIN_FIELD} AS Join_Field_Is, {ISUBA_SOURCE_FIELD} AS Check_Field_Is FROM {ISUBA_SOURCE_TABLE} {SOURCE_INNER_JOIN} {ISUBA_INNER_JOIN_ON} {ISUBA_JOIN_CONDITION} ' 	
		+' ) TempIs '+ CHAR(13)+CHAR(10)		
		+';SET @et=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CreateTempIsubaEndTime>'' + CONVERT(VARCHAR(10),@et,101) + '' '' + CONVERT(VARCHAR(8),@et,108) + ''</CreateTempIsubaEndTime>'''+ CHAR(13)+CHAR(10)
		+';SET @duration=DATEDIFF(ms, @st, @et)'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CreateTempIsubaDuration>'' +CAST(@duration As VARCHAR(100))+ ''</CreateTempIsubaDuration>'''+ CHAR(13)+CHAR(10)
		+';SET @st=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CountTempRallyStartTime>'' + CONVERT(VARCHAR(10),@st,101) + '' '' + CONVERT(VARCHAR(8),@st,108) + ''</CountTempRallyStartTime>'''+ CHAR(13)+CHAR(10)
		+';SELECT @checkTarget=COUNT(*) FROM #TempRally ' + CHAR(13)+CHAR(10)
		+';SET @et=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CountTempRallyEndTime>'' + CONVERT(VARCHAR(10),@et,101) + '' '' + CONVERT(VARCHAR(8),@et,108) + ''</CountTempRallyEndTime>'''+ CHAR(13)+CHAR(10)
		+';SET @duration=DATEDIFF(ms, @st, @et)'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CountTempRallyDuration>'' +CAST(@duration As VARCHAR(100))+ ''</CountTempRallyDuration>'''+ CHAR(13)+CHAR(10)	
		+';SET @st=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CountTempIsubaStartTime>'' + CONVERT(VARCHAR(10),@st,101) + '' '' + CONVERT(VARCHAR(8),@st,108) + ''</CountTempIsubaStartTime>'''+ CHAR(13)+CHAR(10)
		+';SELECT @checkSource=COUNT(*) FROM #TempIsuba ' + CHAR(13)+CHAR(10)
		+';SET @et=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CountTempIsubaEndTime>'' + CONVERT(VARCHAR(10),@et,101) + '' '' + CONVERT(VARCHAR(8),@et,108) + ''</CountTempIsubaEndTime>'''+ CHAR(13)+CHAR(10)
		+';SET @duration=DATEDIFF(ms, @st, @et)'+ CHAR(13)+CHAR(10)
		+';PRINT ''<CountTempIsubaDuration>'' +CAST(@duration As VARCHAR(100))+ ''</CountTempIsubaDuration>'''+ CHAR(13)+CHAR(10)
		+';SET @st=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<IndexStartTime>'' + CONVERT(VARCHAR(10),@st,101) + '' '' + CONVERT(VARCHAR(8),@st,108) + ''</IndexStartTime>'''+ CHAR(13)+CHAR(10)
		+';CREATE NONCLUSTERED INDEX Is1 ON #TempIsuba (Join_Field_Is) INCLUDE (Check_Field_Is) '+ CHAR(13)+CHAR(10)
		+';CREATE NONCLUSTERED INDEX Ra1 ON #TempRally (Join_Field_Ra) INCLUDE (Check_Field_Ra) '+ CHAR(13)+CHAR(10)
		+';SET @et=GETDATE()'+ CHAR(13)+CHAR(10)
		+';PRINT ''<IndexEndTime>'' + CONVERT(VARCHAR(10),@et,101) + '' '' + CONVERT(VARCHAR(8),@et,108) + ''</IndexEndTime>'''+ CHAR(13)+CHAR(10)
		+';SET @duration=DATEDIFF(ms, @st, @et)'+ CHAR(13)+CHAR(10)
		+';PRINT ''<IndexDuration>'' +CAST(@duration As VARCHAR(100))+ ''</IndexDuration>'''+ CHAR(13)+CHAR(10)
		+';PRINT ''(Source) Count of records {ISUBA_SOURCE_FIELD_PRINT} join ... '' + ISNULL(CAST(@checkSource AS VARCHAR(100)),0) '+ CHAR(13)+CHAR(10)
		+';PRINT ''(Target) Count of records {RALLY_TARGET_FIELD_PRINT} join ... '' + ISNULL(CAST(@checkTarget AS VARCHAR(100)),0) '+ CHAR(13)+CHAR(10)
		+';{EMPTY_SET_PLACEHOLDER} '+ CHAR(13)+CHAR(10)
		+';IF ((@checkTarget>0) AND (@checkSource=0) AND @s=1) OR ((@checkTarget=0) AND (@checkSource>0)) '+ CHAR(13)+CHAR(10)
		+'   BEGIN '+ CHAR(13)+CHAR(10)
		+'     ;SET @actual = 999999 '+ CHAR(13)+CHAR(10)
		+'     ;PRINT '' <Empty Set> ''' + CHAR(13)+CHAR(10)
		+'   END '+ CHAR(13)+CHAR(10)
   		+'   ELSE '+ CHAR(13)+CHAR(10)
	   	+'   BEGIN '+ CHAR(13)+CHAR(10)	
	   	+'     ;SET @st=GETDATE()'+ CHAR(13)+CHAR(10)
		+'     ;PRINT ''<ActualStartTime>'' + CONVERT(VARCHAR(10),@st,101) + '' '' + CONVERT(VARCHAR(8),@st,108) + ''</ActualStartTime>'''+ CHAR(13)+CHAR(10)
		+'     ;SET @actual=(SELECT COUNT(*) FROM #TempRally INNER JOIN #TempIsuba ON Join_Field_Ra = Join_Field_Is WHERE {TEST CONDITION} ) '+ CHAR(13)+CHAR(10)
		+'     ;SET @et=GETDATE()'+ CHAR(13)+CHAR(10)
		+'     ;PRINT ''<ActualEndTime>'' + CONVERT(VARCHAR(10),@et,101) + '' '' + CONVERT(VARCHAR(8),@et,108) + ''</ActualEndTime>'''+ CHAR(13)+CHAR(10)
		+'     ;SET @duration=DATEDIFF(ms, @st, @et)'+ CHAR(13)+CHAR(10)
		+'     ;PRINT ''<ActualDuration>'' +CAST(@duration As VARCHAR(100))+ ''</ActualDuration>'''+ CHAR(13)+CHAR(10)
		+'     ;PRINT ''actual'';PRINT @actual'+ CHAR(13)+CHAR(10)
		+'     /*;IF (@actual>0) '+ CHAR(13)+CHAR(10)
		+'     BEGIN '+ CHAR(13)+CHAR(10)
		+'       ;SET @st=GETDATE()'+ CHAR(13)+CHAR(10)
		+'       ;PRINT ''<SampleListStartTime>'' + CONVERT(VARCHAR(10),@st,101) + '' '' + CONVERT(VARCHAR(8),@st,108) + ''</SampleListStartTime>'''+ CHAR(13)+CHAR(10)
		+'       ;PRINT ''...Sample List...'';'+ CHAR(13)+CHAR(10)
		+'       ;SELECT TOP 5 * FROM #TempRally INNER JOIN #TempIsuba ON Join_Field_Ra = Join_Field_Is WHERE {TEST CONDITION}  '+ CHAR(13)+CHAR(10)
		+'       ;SET @et=GETDATE()'+ CHAR(13)+CHAR(10)
		+'       ;PRINT ''<SampleListEndTime>'' + CONVERT(VARCHAR(10),@et,101) + '' '' + CONVERT(VARCHAR(8),@et,108) + ''</SampleListEndTime>'''+ CHAR(13)+CHAR(10)
		+'       ;SET @duration=DATEDIFF(ms, @st, @et)'+ CHAR(13)+CHAR(10)
		+'       ;PRINT ''<SampleListDuration>'' +CAST(@duration As VARCHAR(100))+ ''</SampleListDuration>'''+ CHAR(13)+CHAR(10)
		+'     END*/'+ CHAR(13)+CHAR(10)
		+'     ;INSERT INTO #TEMPTRESULT VALUES (@actual,@checkTarget,@checkTarget) '+ CHAR(13)+CHAR(10)
		+'     ;PRINT ''.................'';'+ CHAR(13)+CHAR(10)		
		+'     ;PRINT ''Count of records {RALLY_TARGET_FIELD_PRINT} does not match {ISUBA_SOURCE_FIELD_PRINT} ... '' + ISNULL(CAST(@actual AS VARCHAR(100)),0);'+ CHAR(13)+CHAR(10)
	   	+'   END '+ CHAR(13)+CHAR(10)	
	   	
	--PRINT 'TEMPLATE QUERY...'
	--PRINT @ExecQuery
	--PRINT '-----------------'
	EXEC dbo.BuildQuery @ExecQuery ,
					@TargetTableSchema ,
					@TargetTable ,
					@TargetField ,
					@SourceTable ,
					@SourceField ,
					@RallyJoinTable ,
					@RallyJoinField ,
					@TargetJoinField ,
					@TargetJoin ,
					@TargetInnerJoinCondition ,
					@IsubaJoinTable ,
					@IsubaJoinField ,
					@SourceJoinField ,
					@SourceJoin ,
					@SourceInnerJoinCondition ,
					@ExecQueryO OUTPUT
	SET @ExecQuery=@ExecQueryO
	--PRINT 'QUERY SENT...'
	--PRINT @ExecQuery
	--PRINT 'QUERY BACK...'
	--PRINT @ExecQueryO
	--PRINT '-----------------'				
	--PRINT 'EXECUTED QUERY...'
	--PRINT @ExecQuery
	--PRINT '-----------------'
	EXEC (@ExecQuery)
	SELECT @actual=MAX(QueryResult) FROM #TEMPTRESULT
	SELECT @TargetCount=MAX(TargetCount) FROM #TEMPTRESULT
	SELECT @SourceCount=MAX(SourceCount) FROM #TEMPTRESULT
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT;
	--PRINT 'TEST RESULTS : ' + @TestName
GO

IF OBJECT_ID (N'dbo.CheckAggregation', N'P') IS NOT NULL
    DROP PROCEDURE dbo.CheckAggregation;
GO
CREATE PROCEDURE CheckAggregation 
@TestName VARCHAR(100),
@TargetTableSchema VARCHAR(MAX),  --   @TargetTableSchema
@TargetTable VARCHAR(MAX),  --   @TargetTable
@TargetField VARCHAR(MAX),  --   @TargetField
@SourceTable VARCHAR(MAX),  --   @SourceTable
@SourceField VARCHAR(MAX),  --   @SourceField
@RallyJoinTable VARCHAR(MAX),  --   @VerifyCondition2
@RallyJoinField VARCHAR(MAX),  --   @VerifyCondition3
@TargetJoinField VARCHAR(MAX),  --   @VerifyCondition4
@TargetJoin VARCHAR(MAX),  --   @VerifyCondition5
@TargetInnerJoinCondition VARCHAR(MAX),
@IsubaJoinTable VARCHAR(MAX),  --   @VerifyCondition6
@IsubaJoinField VARCHAR(MAX),  --   @VerifyCondition7
@SourceJoinField VARCHAR(MAX),  --   @VerifyCondition8
@SourceJoin VARCHAR(MAX),  --   @VerifyCondition9
@SourceInnerJoinCondition VARCHAR(MAX),
@actual SQL_VARIANT OUTPUT,
@expected SQL_VARIANT OUTPUT
AS 	
	--PRINT 'TEST STARTED : ' + @TestName
	/*
	PRINT 'Input Parameters : ' + @TestName
	PRINT '@TestName  :  '; PRINT @TestName
	PRINT '@TargetTableSchema  :  '; PRINT @TargetTableSchema
	PRINT '@TargetTable  :  '; PRINT @TargetTable
	PRINT '@TargetField  :  '; PRINT @TargetField
	PRINT '@SourceTable  :  '; PRINT @SourceTable
	PRINT '@SourceField  :  '; PRINT @SourceField
	PRINT '@RallyJoinTable  :  '; PRINT @RallyJoinTable
	PRINT '@RallyJoinField  :  '; PRINT @RallyJoinField
	PRINT '@TargetJoinField  :  '; PRINT @TargetJoinField
	PRINT '@TargetJoin  :  '; PRINT @TargetJoin
	PRINT '@TargetInnerJoinCondition  :  '; PRINT @TargetInnerJoinCondition
	PRINT '@IsubaJoinTable  :  '; PRINT @IsubaJoinTable
	PRINT '@IsubaJoinField  :  '; PRINT @IsubaJoinField
	PRINT '@SourceJoinField  :  '; PRINT @SourceJoinField
	PRINT '@SourceJoin  :  '; PRINT @SourceJoin
	PRINT '@SourceInnerJoinCondition  :  '; PRINT @SourceInnerJoinCondition	
	 */
	DECLARE @ExecQuery NVARCHAR(MAX), @ExecQueryO NVARCHAR(MAX), @Index INT, @start INT, @PlaceHolder_RALLY_TARGET_TABLE VARCHAR(100), @PlaceHolder_ISUBA_SOURCE_TABLE VARCHAR(100), @PrintPlaceHolder VARCHAR(MAX), @TextHolder VARCHAR(MAX), @ConditionHolder VARCHAR(MAX)
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT
	CREATE TABLE #TEMPTRESULT (QueryResult INT, TargetCount INT, SourceCount INT);
	--AGGREGATION
	--PRINT '*** AGGREGATION ***'
	SET @ExecQuery ='IF (OBJECT_ID(''tempdb..#TEMPTRESULT'') IS NULL) ' + CHAR(13)+CHAR(10)
		+'  CREATE TABLE #TEMPTRESULT (actual SQL_VARIANT, expected SQL_VARIANT)' + CHAR(13)+CHAR(10)
		+';DECLARE @actual SQL_VARIANT, @expected SQL_VARIANT ' + CHAR(13)+CHAR(10)
    	+';PRINT '+''''+'Test {RALLY_TARGET_FIELD_PRINT} does not match {ISUBA_SOURCE_FIELD_PRINT}'+''''+ CHAR(13)+CHAR(10)		
		+';SELECT @actual={RALLY_TARGET_FIELD} FROM {RALLY_TARGET_TABLE} {TARGET_INNER_JOIN} {RALLY_INNER_JOIN_ON} {RALLY_JOIN_CONDITION} ' 	+ CHAR(13)+CHAR(10)
		+';SELECT @expected={ISUBA_SOURCE_FIELD} FROM {ISUBA_SOURCE_TABLE} {SOURCE_INNER_JOIN} {ISUBA_INNER_JOIN_ON} {ISUBA_JOIN_CONDITION} ' 	+ CHAR(13)+CHAR(10)
		+';PRINT '+''''+@TestName+''''
		+';PRINT ''{RALLY_TARGET_FIELD_PRINT} ... '' + ISNULL(CAST(@actual AS VARCHAR(100)),0);'+ CHAR(13)+CHAR(10)
		+';PRINT ''{RALLY_TARGET_FIELD_PRINT} ... '' + ISNULL(CAST(@expected AS VARCHAR(100)),0);'+ CHAR(13)+CHAR(10)
	   	
	--PRINT 'TEMPLATE QUERY...'
	--PRINT @ExecQuery
	--PRINT '-----------------'
	EXEC dbo.BuildQuery @ExecQuery ,
					@TargetTableSchema ,
					@TargetTable ,
					@TargetField ,
					@SourceTable ,
					@SourceField ,
					@RallyJoinTable ,
					@RallyJoinField ,
					@TargetJoinField ,
					@TargetJoin ,
					@TargetInnerJoinCondition ,
					@IsubaJoinTable ,
					@IsubaJoinField ,
					@SourceJoinField ,
					@SourceJoin ,
					@SourceInnerJoinCondition ,
					@ExecQueryO OUTPUT
	SET @ExecQuery=@ExecQueryO
	--PRINT 'QUERY SENT...'
	--PRINT @ExecQuery
	--PRINT 'QUERY BACK...'
	--PRINT @ExecQueryO
	--PRINT '-----------------'				
	--PRINT 'EXECUTED QUERY...'
	--PRINT @ExecQuery
	--PRINT '-----------------'
	EXEC (@ExecQuery)
	SELECT @actual=MAX(QueryResult) FROM #TEMPTRESULT
	IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT;
	--PRINT 'TEST RESULTS : ' + @TestName
GO

IF OBJECT_ID (N'dbo.BuildQuery', N'P') IS NOT NULL
    DROP PROCEDURE dbo.BuildQuery;
GO
CREATE PROCEDURE [dbo].[BuildQuery] 
@TemplateQuery VARCHAR(MAX),
@TargetTableSchema VARCHAR(MAX),  --   @TargetTableSchema
@TargetTable VARCHAR(MAX),  --   @TargetTable
@TargetField VARCHAR(MAX),  --   @TargetField
@SourceTable VARCHAR(MAX),  --   @SourceTable
@SourceField VARCHAR(MAX),  --   @SourceField
@RallyJoinTable VARCHAR(MAX),  --   @VerifyCondition2
@RallyJoinField VARCHAR(MAX),  --   @VerifyCondition3
@TargetJoinField VARCHAR(MAX),  --   @VerifyCondition4
@TargetJoin VARCHAR(MAX),  --   @VerifyCondition5
@TargetInnerJoinCondition VARCHAR(MAX),
@IsubaJoinTable VARCHAR(MAX),  --   @VerifyCondition6
@IsubaJoinField VARCHAR(MAX),  --   @VerifyCondition7
@SourceJoinField VARCHAR(MAX),  --   @VerifyCondition8
@SourceJoin VARCHAR(MAX),  --   @VerifyCondition9
@SourceInnerJoinCondition VARCHAR(MAX),
@ExecQuery VARCHAR(MAX) OUTPUT
AS 	
	--PRINT 'TEST STARTED : ' + @TestName
	
	--PRINT 'Input Parameters : ' 
	--PRINT '@TestName  :  '+  @TestName
	/*PRINT '@@TemplateQuery  :  '; PRINT @TemplateQuery
	 * PRINT '@TargetTableSchema  :  '; PRINT @TargetTableSchema
	PRINT '@TargetTable  :  '+ @TargetTable
	PRINT '@TargetField  :  '+ @TargetField
	PRINT '@SourceTable  :  '+ @SourceTable
	PRINT '@SourceField  :  '+ @SourceField
	PRINT '@RallyJoinTable  :  '+ @RallyJoinTable
	PRINT '@RallyJoinField  :  '+ @RallyJoinField
	PRINT '@TargetJoinField  :  '+ @TargetJoinField
	PRINT '@TargetJoin  :  '+ @TargetJoin
	PRINT '@TargetInnerJoinCondition  :  '+ @TargetInnerJoinCondition
	PRINT '@IsubaJoinTable  :  '+ @IsubaJoinTable
	PRINT '@IsubaJoinField  :  '+ @IsubaJoinField
	PRINT '@SourceJoinField  :  '+ @SourceJoinField
	PRINT '@SourceJoin  :  '+ @SourceJoin
	PRINT '@SourceInnerJoinCondition  :  '+ @SourceInnerJoinCondition	*/
	
	DECLARE @Index INT, @start INT, @PlaceHolder_RALLY_TARGET_TABLE VARCHAR(100), @PlaceHolder_ISUBA_SOURCE_TABLE VARCHAR(100), @PrintPlaceHolder VARCHAR(MAX), @TextHolder VARCHAR(MAX), @ConditionHolder VARCHAR(MAX)
	DECLARE @FK_JF VARCHAR(100),@PK_JF VARCHAR(100), @s INT,@duration INT, @st DATETIME, @et DATETIME, @Schema VARCHAR(100)
	
	SET @Schema = @TargetTableSchema + CASE @TargetTableSchema WHEN '' THEN '' ELSE '.' END
	
	;SET @st=GETDATE()
	;PRINT '<BuildQueryStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</BuildQueryStartTime>'
	
	SET @PlaceHolder_RALLY_TARGET_TABLE = '{RALLY_TARGET_TABLE}.'
	SET @PlaceHolder_ISUBA_SOURCE_TABLE = '{ISUBA_SOURCE_TABLE}.'

	--Get join fields
	SET @FK_JF = ''
	SET @PK_JF = ''
	IF (@RallyJoinTable<>'')
	BEGIN
		SELECT
		    @FK_JF = ISNULL(CU.COLUMN_NAME,''),
		    @PK_JF = ISNULL(PT.COLUMN_NAME,'')
		    --FK_Table = FK.TABLE_NAME,
		    --FK_Column = CU.COLUMN_NAME,
		    --PK_Table = PK.TABLE_NAME,
		    --PK_Column = PT.COLUMN_NAME,
		    --Constraint_Name = C.CONSTRAINT_NAME
		FROM
		    INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS C
		INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS FK
		    ON C.CONSTRAINT_NAME = FK.CONSTRAINT_NAME
		INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS PK
		    ON C.UNIQUE_CONSTRAINT_NAME = PK.CONSTRAINT_NAME
		INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE CU
		    ON C.CONSTRAINT_NAME = CU.CONSTRAINT_NAME
		INNER JOIN (
		            SELECT
		                i1.TABLE_NAME,
		                i2.COLUMN_NAME
		            FROM
		                INFORMATION_SCHEMA.TABLE_CONSTRAINTS i1
		            INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE i2
		                ON i1.CONSTRAINT_NAME = i2.CONSTRAINT_NAME
		            WHERE
		                i1.CONSTRAINT_TYPE = 'PRIMARY KEY'
		           ) PT
		    ON PT.TABLE_NAME = PK.TABLE_NAME
		WHERE FK.TABLE_NAME = @TargetTable AND PK.TABLE_NAME = @RallyJoinTable 
		
		PRINT 'first'
		PRINT @FK_JF +' '+@PK_JF
		IF (ISNULL(@FK_JF,'')<>'' AND ISNULL(@PK_JF,'')<>'')
		BEGIN
			IF (@TargetJoinField<>'')
				PRINT 'WARNING !!! Defined TargetJoinField value will be replaced <current value>'+@TargetJoinField+'<new value>'+@PK_JF
			SET @TargetJoinField = @PK_JF
		END
		ELSE
		BEGIN
			SELECT
			    @PK_JF = ISNULL(CU.COLUMN_NAME,''),
			    @FK_JF = ISNULL(PT.COLUMN_NAME,'')
			FROM
			    INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS C
			INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS FK
			    ON C.CONSTRAINT_NAME = FK.CONSTRAINT_NAME
			INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS PK
			    ON C.UNIQUE_CONSTRAINT_NAME = PK.CONSTRAINT_NAME
			INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE CU
			    ON C.CONSTRAINT_NAME = CU.CONSTRAINT_NAME
			INNER JOIN (
			            SELECT
			                i1.TABLE_NAME,
			                i2.COLUMN_NAME
			            FROM
			                INFORMATION_SCHEMA.TABLE_CONSTRAINTS i1
			            INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE i2
			                ON i1.CONSTRAINT_NAME = i2.CONSTRAINT_NAME
			            WHERE
			                i1.CONSTRAINT_TYPE = 'PRIMARY KEY'
			           ) PT
			    ON PT.TABLE_NAME = PK.TABLE_NAME
			WHERE FK.TABLE_NAME = @RallyJoinTable AND PK.TABLE_NAME =  @TargetTable
			PRINT 'second'
			PRINT @FK_JF +' '+@PK_JF
			IF (ISNULL(@FK_JF,'')<>'' AND ISNULL(@PK_JF,'')<>'')
			BEGIN
				IF (@TargetJoinField<>'')
					PRINT 'WARNING !!! Defined TargetJoinField value will be replaced <current value>'+@TargetJoinField+'<new value>'+@PK_JF
				SET @TargetJoinField = @PK_JF
			END
			ELSE
				PRINT 'WARNING !!! Could not find foreign key for tables : <TargetTable>'+@TargetTable+'<RallyJoinTable>'+@RallyJoinTable
		END 
	END
	
	--PRINT '***Build Query ***'
	--PRINT 'RAW QUERY...'
	--PRINT @ExecQuery
	
	--!!!BURADA SIRALAMA �NEML� DE���T�RMEY�N!!! 
	SET @ExecQuery=@TemplateQuery
	
	SET @Index = CHARINDEX('%',@SourceField)
	IF (@Index>0) BEGIN
		SET @start = @Index + 1 
		SET @Index = CHARINDEX('%',@SourceField, @start)
		SET @TextHolder = LTRIM(RTRIM(SUBSTRING(@SourceField,@start,@Index-@start)))
		--PRINT 'Part 1>'+@TextHolder+'<'
		
		SET @start = @Index + 1 
		SET @Index = CHARINDEX('%',@SourceField, @start)
		PRINT 'Part 2>'+LTRIM(RTRIM(SUBSTRING(@SourceField,@start,@Index-@start)))+'<'
		SET @ConditionHolder = LTRIM(RTRIM(SUBSTRING(@SourceField,@Index+1,LEN(@SourceField)-@start)))		
		SET @SourceField =  LTRIM(RTRIM(SUBSTRING(@SourceField,@start,@Index-@start)))
		--PRINT 'Part 3>'+@ConditionHolder+'<'
		--PRINT '@SourceField>'+@SourceField+'<'
		SET @ExecQuery = REPLACE(@ExecQuery,@TextHolder,'')
		SET @ExecQuery = REPLACE(@ExecQuery,'CREATE NONCLUSTERED INDEX Is1 ON #TempIsuba (Join_Field_Is) INCLUDE (Check_Field_Is)','CREATE NONCLUSTERED INDEX Is1 ON #TempIsuba (Join_Field_Is) INCLUDE ('+@SourceField+')')
	END
	ELSE
		SET @ConditionHolder = ''
	
	SET @Index = CHARINDEX('>>',@TargetField)
	IF (@Index>0) BEGIN
		SET @Index = @Index + 1
		SET @TargetField = SUBSTRING(@TargetField,@Index+1,LEN(@TargetField)-@Index)
		SET @PlaceHolder_RALLY_TARGET_TABLE = ''
	END
	SET @Index = CHARINDEX('>>',@SourceField)
	IF (@Index>0) BEGIN
		SET @Index = @Index + 1
		SET @SourceField = SUBSTRING(@SourceField,@Index+1,LEN(@SourceField)-@Index)
		SET @PlaceHolder_ISUBA_SOURCE_TABLE = ''
	END

	SET @ExecQuery = REPLACE(@ExecQuery,'{TEST CONDITION}', CASE WHEN @ConditionHolder <> '' THEN @ConditionHolder WHEN CHARINDEX('#ISNULL',@SourceField) > 0 THEN  ' Check_Field_Ra IS NOT NULL ' ELSE ' Check_Field_Ra <> Check_Field_Is '  END)
	--TO DO Hangi durumlarda testdeki kay�t say�lar� devre d��� kal�r??? 
	SET @ExecQuery = REPLACE(@ExecQuery,'{EMPTY_SET_PLACEHOLDER}', CASE WHEN CHARINDEX('#ISNULL',@SourceField) > 0 THEN 'SET @s = 0 ' ELSE 'SET @s = 1 ' END)
	DECLARE @m VARCHAR(100)
	SELECT @m='Target field type : ' + DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=@TargetTable AND COLUMN_NAME=@TargetField 
	PRINT @m
	IF EXISTS(SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=@TargetTable AND COLUMN_NAME=@TargetField AND DATA_TYPE='datetimeoffset')
		SET @TargetField = 'CAST('+@TargetTable+'.'+@TargetField+' AS DATETIME)'
	SET @Index = CASE 
					WHEN SUBSTRING(@TargetField,1,3)='dbo' 	 THEN 1
					WHEN SUBSTRING(@TargetField,1,5)='CAST(' THEN 1
					ELSE 0
				END 
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_FIELD}',CASE WHEN @Index = 1 THEN @TargetField ELSE @PlaceHolder_RALLY_TARGET_TABLE+@TargetField END)
	SET @Index = CASE 
					WHEN SUBSTRING(@SourceField,1,3)='dbo'		THEN 1
					WHEN @ConditionHolder<>''					THEN 1
					WHEN CHARINDEX('#ISNULL',@SourceField)>0	THEN 2
					ELSE 0
				END
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_FIELD}',CASE WHEN @Index = 1 THEN @SourceField WHEN @Index = 2 THEN '""' ELSE @PlaceHolder_ISUBA_SOURCE_TABLE+@SourceField END)

	--SET @ExecQuery = REPLACE(@ExecQuery,'<Value>','<value>')	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_TABLE}.&','')
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_TABLE}.&','')
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_TABLE}.&','')
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_TABLE}.&','')
	--SET @ExecQuery = REPLACE(@ExecQuery,'<value>','')
	
	SET @Index = CHARINDEX('{MULTI}',@RallyJoinTable)
	IF (@Index>0) 
	BEGIN
		SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_TABLE}','')
		SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_FIELD}','')
		SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_TABLE}','')
		SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_FIELD}','')
		SET @ExecQuery = REPLACE(@ExecQuery,'AS Join_Field_Ra',@RallyJoinField)
		SET @ExecQuery = REPLACE(@ExecQuery,'AS Join_Field_Is',@IsubaJoinField)	
		SET @ExecQuery = REPLACE(@ExecQuery,'Join_Field_Ra = Join_Field_Is',@IsubaJoinTable)
		SET @ExecQuery = REPLACE(@ExecQuery,'CREATE NONCLUSTERED INDEX Is1 ON #TempIsuba (Join_Field_Is) INCLUDE (Check_Field_Is)','CREATE NONCLUSTERED INDEX Is1 ON #TempIsuba ('+CASE WHEN @SourceJoinField='' THEN @IsubaJoinField ELSE @SourceJoinField END+') INCLUDE (Check_Field_Is)')
		SET @ExecQuery = REPLACE(@ExecQuery,'CREATE NONCLUSTERED INDEX Ra1 ON #TempRally (Join_Field_Ra) INCLUDE (Check_Field_Ra)','CREATE NONCLUSTERED INDEX Ra1 ON #TempRally ('+CASE WHEN @TargetJoinField='' THEN @RallyJoinField ELSE @TargetJoinField END+') INCLUDE (Check_Field_Ra)')
		SET @RallyJoinTable=''
		SET @SourceJoinField=''
		SET @TargetJoinField=''
	END
	
	SET @Index = CHARINDEX('{RALLY}.',@SourceTable)
	IF (@Index>0) BEGIN
		SET @SourceTable = REPLACE(@SourceTable,'{RALLY}.','')
	END
	ELSE BEGIN
		SET @SourceTable = '{ISUBADB}.' + @SourceTable
	END

	SET @Index = CHARINDEX('##',@TargetTable)
	IF (@Index>0) BEGIN
		SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_TABLE}.','')
		SET @ExecQuery = REPLACE(@ExecQuery,'AS Join_Field_Ra,','')
		SET @ExecQuery = REPLACE(@ExecQuery,'AS Check_Field_Ra','AS Join_Field_Ra')
		SET @TargetTable = REPLACE(@TargetTable,'##','')
	END	
	SET @Index = CHARINDEX('##',@SourceTable)
	IF (@Index>0) BEGIN
		SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_TABLE}.','')
		SET @ExecQuery = REPLACE(@ExecQuery,'AS Join_Field_Is,','')
		SET @ExecQuery = REPLACE(@ExecQuery,'AS Check_Field_Is','AS Join_Field_Is')
		SET @SourceTable = REPLACE(@SourceTable,'##','')
	END	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_TABLE}',@Schema+@TargetTable)
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_TABLE}',@SourceTable)
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_TABLE}',CASE WHEN @RallyJoinTable='' THEN '' ELSE @RallyJoinTable+'.' END) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_FIELD}',@RallyJoinField) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{TARGET_INNER_JOIN}',CASE WHEN @TargetJoinField='' THEN '' ELSE ' INNER JOIN '+@RallyJoinTable+' ON '+@Schema+@TargetTable+'.'+@FK_JF+'='+@RallyJoinTable+'.'+@PK_JF END)
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_INNER_JOIN_ON}',@TargetJoin)
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_JOIN_CONDITION}',CASE WHEN @TargetInnerJoinCondition='' THEN '' ELSE ' WHERE '+@TargetInnerJoinCondition END) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_TABLE}',CASE WHEN @IsubaJoinTable='' THEN '' ELSE @IsubaJoinTable+'.' END) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_FIELD}',@IsubaJoinField) 
	SET @ExecQuery = REPLACE(@ExecQuery,'{SOURCE_INNER_JOIN}',CASE WHEN @SourceJoinField='' THEN '' ELSE ' INNER JOIN '+@SourceJoinField+' ON '+@SourceTable+'.'+@SourceJoinField+'='+@IsubaJoinTable+'.'+@IsubaJoinField END)
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_INNER_JOIN_ON}',@SourceJoin)
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_JOIN_CONDITION}',CASE WHEN @SourceInnerJoinCondition='' THEN '' ELSE ' WHERE '+@SourceInnerJoinCondition END)

	SET @TargetField = REPLACE(@TargetField,'"','')
	SET @PrintPlaceHolder = REPLACE(@TargetTable+'.'+CASE WHEN SUBSTRING(@TargetField,1,4)='dbo.' THEN RIGHT(@TargetField,LEN(@TargetField)-CHARINDEX('(', @TargetField)+1) ELSE @TargetField END,@TargetTable+'.&','')
	SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TARGET_FIELD_PRINT}',@PrintPlaceHolder)
	SET @SourceField = REPLACE(@SourceField,'"','')
	SET @PrintPlaceHolder = REPLACE(@SourceTable+'.'+CASE WHEN SUBSTRING(@SourceField,1,4)='dbo.' THEN RIGHT(@SourceField,LEN(@SourceField)-CHARINDEX('(', @SourceField)+1)  ELSE @SourceField END,@SourceTable+'.&','')
	IF CHARINDEX('CASE',@PrintPlaceHolder) > 0
	BEGIN
		SET @PrintPlaceHolder = REPLACE(@PrintPlaceHolder,'CASE WHEN ','')
		SET @PrintPlaceHolder = REPLACE(@PrintPlaceHolder,'THEN','>')
		SET @PrintPlaceHolder = REPLACE(@PrintPlaceHolder,' ELSE ','')
		SET @PrintPlaceHolder = REPLACE(@PrintPlaceHolder,' END','')
	END
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_SOURCE_FIELD_PRINT}',@PrintPlaceHolder)	
	
	SET @ExecQuery = REPLACE(@ExecQuery,'"','''')
	--SET @ExecQuery = REPLACE(@ExecQuery,'--;SELECT TOP 5 * FROM #TempRally',';SELECT TOP 5 * FROM #TempRally')
	
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBADB}.','{ISUBA}.')
	SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA}.','{ISUBA}.')

	PRINT 'QUERY TO EXECUTE ...'
	PRINT @ExecQuery
	PRINT '-----------------'
	;SET @et=GETDATE()
	;PRINT '<BuildQueryEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</BuildQueryEndTime>'
	;SET @duration=DATEDIFF(ms, @st, @et)
	;PRINT '<BuildQueryDuration>' +CAST(@duration As VARCHAR(100))+ '</BuildQueryDuration>'
GO