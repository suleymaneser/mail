EXEC tSQLt.NewTestClass 'AutoTestsAccountMigration';
GO

EXEC tSQLt.NewTestClass 'AccountBalance';
GO

EXEC tSQLt.NewTestClass 'AccountContract';
GO

EXEC tSQLt.NewTestClass 'AccountDefinition';
GO

EXEC tSQLt.NewTestClass 'AccountInterest';
GO

EXEC tSQLt.NewTestClass 'AccountInterestDefinition';
GO

EXEC tSQLt.NewTestClass 'AccountOwner';
GO

EXEC tSQLt.NewTestClass 'CustomerAccountDefinition';
GO