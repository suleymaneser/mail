select acct.a1brn, acct.a1acc, acct.a1sfx, acct.a1ccy, letter_of_guarantee.product_type, 
account_contract.reference, letter_of_guarantee.current_amount, 802000, letter_of_guarantee.debit_tdhp, letter_of_guarantee.credit_tdhp,
u1code, letter_of_guarantee.issue_date, letter_of_guarantee.expiry_date, letter_of_guarantee.claim_validity_date,
account_contract.*, acct.* from noncashloan.letter_of_guarantee
join accountcore.account on account.number=letter_of_guarantee.number
join accountcore.customer_account on customer_account.id=account.id
join accountcore.account_contract on account_contract.id=customer_account.contract
join accountcore.account_owner on account_owner.account=customer_account.id --and account_owner.is_primary=1
join accountcore.product on product.product_type = letter_of_guarantee.product_type
join accountcore.account_type on product.account_type=account_type.id
join ydsm.acct on acct.a1brn=account.owning_unit_code and acct.a1acc=account_owner.owner_number 
and acct.a1atyp=account_type.code and acct.a1ccy=account.currency and a1cls='N'
join ydsm.ccys on ccys.u1ccy=account.currency
where owning_unit_code=653 and letter_of_guarantee.status='ACTIVE' and account.is_closed=0