﻿--/services/accountcore/api/accountbalancecheck/checkinconsistentaccountbalanceamountbyowningunitcodeandcurrency
SELECT a.owning_unit_code, sum(b.balance_amount), a.currency
FROM accountcore.account a JOIN accountcore.account_balance b on a.balance = b.id 
GROUP BY a.currency, a.owning_unit_code HAVING(SUM(b.balance_amount) <> 0)

--/services/currentaccount/api/tellercashoperation/checkSystemAmount
SELECT currency, branch_code, SUM(system_amount) AS SUMM FROM accountcore.till till GROUP BY currency, branch_code
HAVING SUM(system_amount) != (SELECT ABS(SUM(blnc.balance_amount)) FROM accountcore.account acc 
JOIN accountcore.account_balance blnc ON acc.balance = blnc.id
WHERE acc.account_type = (SELECT id FROM accountcore.account_type WHERE code='YA') 
AND till.branch_code = acc.owning_unit_code AND till.currency = blnc.balance_currency) 

--/services/currentaccount/api/tellercashoperation/tillCheck
SELECT * FROM accountcore.till till WHERE till.user_code != '@@MC' AND system_amount != case_amount

--/services/currentaccount/api/tellercashoperation/systemTellerCashCheck
SELECT * FROM accountcore.till till WHERE till.user_code != '@@MC' AND system_amount != 0 --AND till.branch_code = '0652'

--/services/accountcore/api/accountbalancecheck/checkaccountrecordswithoutaccountbalancerecord
SELECT a.id, a.balance, a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency
FROM accountcore.account a LEFT JOIN accountcore.account_balance b ON a.balance = b.id WHERE b.id is null

--/services/accountcore/api/accountbalancecheck/checkaccountbalancenothavingaccount
--RIGHT JOIN yazılmış commonsta ama native query değil right join çalışmıyor olabilir
SELECT a.id, a.balance, a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency
FROM accountcore.account a right JOIN accountcore.account_balance b ON a.balance = b.id WHERE a.id is null

--/services/accountcore/api/accountbalancecheck/checkaccountbalancelinkedwithincorrectaccount
SELECT a.id, a.balance, a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency
FROM accountcore.account a JOIN accountcore.account_balance b ON a.balance = b.id WHERE b.account_id <> a.id

--/services/accountcore/api/accountbalancecheck/checkaccountcurrencymismatchingaccountbalancecurrencies
SELECT a.id, a.balance, a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency 
FROM accountcore.account a JOIN accountcore.account_balance b ON a.balance = b.id WHERE a.currency <> b.balance_currency or a.currency <> b.blocked_balance_currency 
or a.currency <> b.overdraft_limit_currency

--/services/accountcore/api/accountbalancecheck/checkaccountbalancenotmatchanyaccount
SELECT a.id , a.balance,  a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency 
FROM accountcore.account a RIGHT JOIN accountcore.account_balance b ON b.account_id = a.id WHERE a.id is null

--/services/accountcore/api/accountbalancecheck/checkaccountbalancerecordswithinvalidaccountrecord
SELECT a.id , a.balance,  a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency
FROM accountcore.account a RIGHT JOIN accountcore.account_balance b ON a.balance = b.id WHERE a.balance is null

--/services/accountcore/api/accountbalancecheck/checkaccountbalancerecordswithoutaccountrecord
select * from accountcore.account_balance a where a.account_id is null or a.account_id = 0


--/services/accountcore/api/accountchecks/checkaccountbalanceinconsistencywithmonetarytransaction
SELECT a.number as number, ab.balance_amount as accountBalance, sum_of_account as sumOfTransaction
FROM accountcore.account a
JOIN accountcore.account_balance ab on a.balance = ab.id
LEFT JOIN (select account, SUM(transaction_amount) as sum_of_account FROM accountcore.monetary_transaction_item GROUP BY account)
temp_monetary_transaction_item ON a.id = temp_monetary_transaction_item.account
WHERE ab.balance_amount <> (ISNULL(temp_monetary_transaction_item.sum_of_account, 0) + ISNULL(ab.migrated_balance_amount, 0))

--/services/accountcore/api/accountchecks/checkaccountbalancewithoutmonetarytransaction
SELECT * FROM accountcore.account a JOIN accountcore.account_balance ab ON a.balance=ab.id 
LEFT JOIN accountcore.monetary_transaction_item mti on mti.account=a.id 
WHERE ab.balance_amount - ISNULL(ab.migrated_balance_amount,0) <> 0 AND mti.account IS NULL

--/services/accountcore/api/accountchecks/checkaccountcontractswithoutcustomeraccount
SELECT * FROM accountcore.account_contract ac 
LEFT JOIN accountcore.customer_account ca on ac.id=ca.contract 
WHERE ca.contract IS NULL

--/services/accountcore/api/accountchecks/checkaccountownerswithoutcustomeraccount
SELECT ao.owner_number as ownerNumber FROM accountcore.account_owner as ao 
WHERE ao.account IS NULL
UNION
SELECT ao.owner_number as ownerNumber FROM accountcore.account_owner as ao
LEFT JOIN accountcore.customer_account as ca ON ao.account=ca.id WHERE ca.id IS NULL

--/services/accountcore/api/accountchecks/checkaccountswithoutaccounttype
SELECT * from accountcore.account a 
LEFT JOIN accountcore.account_type act on a.account_type=act.id 
WHERE act.id is null

--/services/accountcore/api/accountchecks/checkaccountswithoutcustomeraccount
SELECT * FROM accountcore.account a 
JOIN accountcore.account_type act ON a.account_type = act.id 
LEFT JOIN accountcore.customer_account ca on a.id = ca.id 
WHERE ca.id IS NULL AND act.is_internal = 0

--/services/accountcore/api/accountchecks/checkaccountswithoutinternalaccount
SELECT * FROM accountcore.account a 
JOIN accountcore.account_type act ON a.account_type = act.id 
LEFT JOIN accountcore.internal_account ia on a.id = ia.id 
WHERE ia.id IS NULL AND act.is_internal = 1

--/services/accountcore/api/accountchecks/checkcustomeraccountswithoutaccountowner
SELECT ao.owner_number as ownerNumber FROM accountcore.customer_account ca 
LEFT JOIN accountcore.account_owner ao on ao.account=ca.id WHERE ao.account IS NULL

--/services/accountcore/api/accountchecks/checkcustomeraccountswithoutaccount
SELECT * FROM accountcore.customer_account ca LEFT JOIN accountcore.account a on a.id = ca.id WHERE a.id IS NULL

--/services/accountcore/api/accountchecks/checkcustomeraccountswithoutaccountcontract
SELECT * FROM accountcore.customer_account ca LEFT JOIN accountcore.account_contract ac on ac.id=ca.contract
WHERE ac.id IS NULL

--/services/accountcore/api/accountchecks/checkinternalaccountswithoutaccount
SELECT * FROM accountcore.internal_account ia 
LEFT JOIN accountcore.account a on a.id = ia.id WHERE a.id IS NULL

--/services/accountcore/api/monetarytransactioncheck/checktransactiondoesnothavezerosum
SELECT SUM(transaction_amount) FROM accountcore.monetary_transaction_item mti 
GROUP BY transaction_id HAVING SUM(transaction_amount) <> 0

--/services/accountcore/api/monetarytransactioncheck/checkunequaltransactionitemandaccountvaluedatedbalancehistory
SELECT temp_monetary_transaction_item.account as accountId, 
temp_monetary_transaction_item.value_date as transactionValueDate, 
a.value_dated_balance_amount as balanceHistoryAmount, 
daily_sum as sumOfMonetaryTransactionItemAmount FROM accountcore.account_value_dated_balance_history a 
JOIN (SELECT account, value_date, sum(sum_of_transaction_amount) 
OVER (partition by account order by account, value_date) as daily_sum 
FROM (SELECT account, value_date, sum(transaction_amount) as sum_of_transaction_amount 
FROM accountcore.monetary_transaction_item group by account, value_date) temp)
temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account 
and a.date=temp_monetary_transaction_item.value_date WHERE daily_sum<>value_dated_balance_amount

--/services/accountcore/api/monetarytransactioncheck/checkcreditsideslessthanzero
select * from accountcore.monetary_transaction_item m where m.side = 'CREDIT' and m.transaction_amount <= 0

--/services/accountcore/api/monetarytransactioncheck/checkdebitsidesgreaterthanzero
select * from accountcore.monetary_transaction_item m where m.side = 'DEBIT' and m.transaction_amount >= 0

--/services/accountcore/api/monetarytransactioncheck/checkinvalidsides
SELECT mti.id as itemId, mti.side as transactionSide 
FROM accountcore.monetary_transaction_item mti WHERE side NOT IN ('DEBIT', 'CREDIT')

--/services/accountcore/api/monetarytransactioncheck/checkmonetarywithoutvaluedatedhistory
select ac.number as number, temp_monetary_transaction_item.value_date as date, 
temp_monetary_transaction_item.sum_of_transaction_amount as amount 
from accountcore.account_value_dated_balance_history a 
right join (select account, value_date, sum(transaction_amount) as sum_of_transaction_amount 
from accountcore.monetary_transaction_item group by account, value_date) temp_monetary_transaction_item 
on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date 
left join accountcore.account ac on ac.id = temp_monetary_transaction_item.account 
where a.date is null

--/services/accountcore/api/monetarytransactioncheck/checkvaluedatedhistorywithoutmonetary
select ac.number as number, a.date as date, a.value_dated_balance_amount as amount from 
accountcore.account_value_dated_balance_history a left join ( 
select account, value_date, sum(transaction_amount) as sum_of_transaction_amount 
from accountcore.monetary_transaction_item group by account, value_date) temp_monetary_transaction_item 
on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date 
left join accountcore.account ac on ac.id = a.account 
where temp_monetary_transaction_item.account is null

--/services/accountcore/api/accountchecks/checkaccountcurrencydoesnotmatchaccountblockagecurrency
select a.id, a.number, a.currency,b.id, b.blockage_currency 
from accountcore.account a JOIN accountcore.account_blockage b ON a.id = b.account 
where a.currency <> b.blockage_currency and b.blockage_currency IS NOT NULL

--/services/accountcore/api/accountchecks/checkaccountcurrencydoesnotmatchpaymentplancurrencies
select a.id, a.number, a.currency, pp.id, pp.amount_currency, pp.paid_amount_currency from 
accountcore.account a INNER JOIN accountcore.account_payment_plan_definition ppd ON a.id = ppd.account 
INNER JOIN accountcore.account_payment_plan pp ON pp.payment_plan_definition = ppd.id WHERE
(a.currency <> pp.paid_amount_currency and pp.paid_amount_currency IS NOT NULL) 
or (a.currency <> pp.amount_currency and pp.amount_currency IS NOT NULL)

--/services/accountcore/api/accountchecks/checkaccountcurrencydoesnotmatchaccountpaymentplanexecutioncurrency
select a.id, a.number, a.currency, ppe.id, ppe.amount_currency 
from accountcore.account a LEFT JOIN accountcore.account_payment_plan_definition ppd 
ON a.id = ppd.account LEFT JOIN accountcore.account_payment_plan pp ON pp.payment_Plan_Definition = ppd.id 
RIGHT JOIN accountcore.Account_Payment_Plan_Execution ppe ON ppe.payment_Plan = pp.id WHERE a.currency <> ppe.amount_currency 

--/services/accountcore/api/accountchecks/checkaccountcurrencydoesnotmatchaccountvaluedatedbalancehistorycurrencies
select a.id, a.number, a.currency, b.id, b.total_Projected_currency, b.value_Dated_Balance_currency 
from accountcore.account a JOIN accountcore.Account_Value_Dated_Balance_History b ON a.id = b.account 
where a.currency <> b.value_Dated_Balance_currency or a.currency <> b.total_Projected_currency

--/services/accountcore/api/accountinterestcheck/checkaccountinterestbycurrency
SELECT a.id, a.number, a.currency, ai.adjustment_Interest_currency, ai.baseline_Value_currency, ai.treshold_Value_currency, ai.commission_currency 
FROM accountcore.account a INNER JOIN accountcore.account_interest ai on a.id = ai.account 
where (a.currency <> ai.adjustment_Interest_currency) 
or (a.currency <> ai.baseline_Value_currency and ai.baseline_Value_currency IS NOT NULL) 
or (a.currency <> ai.treshold_Value_currency) 
or (a.currency <> ai.commission_currency and ai.commission_currency IS NOT NULL)

--/services/accountcore/api/accountinterestcheck/checkaccountinterestcalculationbycurrency
SELECT a.id, a.number, a.currency, aic.last_Cycle_To_Next_Business_Interest_currency, 
aic.last_Cycle_To_Next_Cycle_Interest_currency, aic.last_Cycle_To_Next_Cycle_Tax_currency, 
aic.last_Cycle_To_Next_Cycle_Tax2_currency, aic.last_Cycle_To_Next_Cycle_Interest_Round_Diff_currency, 
aic.one_Day_Interest_currency, aic.not_Posted_Previous_Years_Interest_currency, 
aic.total_Interest_Posted_currency
FROM accountcore.account a INNER JOIN accountcore.account_interest ai on a.id = ai.account 
INNER JOIN accountcore.account_interest_calculation aic on ai.id = aic.account_Interest 
where (a.currency <> aic.last_Cycle_To_Next_Business_Interest_currency) 
or (a.currency <> aic.last_Cycle_To_Next_Cycle_Interest_currency) 
or (a.currency <> aic.last_Cycle_To_Next_Cycle_Interest_Round_Diff_currency) 
or (a.currency <> aic.last_Cycle_To_Next_Cycle_Tax_currency and aic.last_Cycle_To_Next_Cycle_Tax_currency IS NOT NULL) 
or (a.currency <> aic.last_Cycle_To_Next_Cycle_Tax2_currency and aic.last_Cycle_To_Next_Cycle_Tax2_currency IS NOT NULL) 
or (a.currency <> aic.not_Posted_Previous_Years_Interest_currency) 
or (a.currency <> aic.one_Day_Interest_currency) 
or (a.currency <> aic.total_Interest_Posted_currency)

--/services/accountcore/api/accountinterestcheck/checkaccountinterestratehistorybycurrency
SELECT a.id, a.number, a.currency, airh.overdraft_limit_currency, airh.treshold_Value_currency, airh.baseline_Value_currency 
FROM accountcore.account a INNER JOIN accountcore.account_interest ai on a.id = ai.account 
INNER JOIN accountcore.account_interest_rate_history airh on airh.account_Interest = ai.id 
where (a.currency <> airh.baseline_Value_currency and airh.baseline_Value_currency IS NOT NULL) 
or (a.currency <> airh.overdraft_limit_currency and airh.overdraft_limit_currency IS NOT NULL) 
or (a.currency <> airh.treshold_Value_currency and airh.treshold_Value_currency IS NOT NULL)

--/services/accountcore/api/monetarytransactioncheck/checkaccountswherecurrencymismatchmonetarytransactionitemcurrency
SELECT a.id, a.number, a.currency, i.transaction_currency, i.id
FROM accountcore.monetary_transaction_item i JOIN accountcore.account a ON i.account = a.id 
WHERE i.transaction_currency <> a.currency and i.transaction_currency IS NOT NULL

--/services/accountcore/api/todaymovementscheck/checkaccountpaymentplandefinitionwithinvalidinteresetsettlementaccount
SELECT * FROM accountcore.account_payment_plan_definition appd 
LEFT JOIN accountcore.account a on a.number = appd.interest_settlement_account 
WHERE a.number IS NULL AND appd.interest_settlement_account IS NOT NULL

--/services/accountcore/api/todaymovementscheck/checkaccountpaymentplandefinitionwithinvalidprincipalsettlementaccount
SELECT * FROM accountcore.account_payment_plan_definition appd 
LEFT JOIN accountcore.account a on a.number = appd.principal_settlement_account 
WHERE a.number IS NULL AND appd.principal_settlement_account IS NOT NULL

--/services/accountcore/api/todaymovementscheck/checkaccountpaymentplandefinitionwithinvalidprincipalpaysettlementaccount
SELECT * FROM accountcore.account_payment_plan_definition appd 
LEFT JOIN accountcore.account a on a.number = appd.principal_pay_settlement_account 
WHERE a.number IS NULL AND appd.principal_pay_settlement_account IS NOT NULL 

--/services/accountcore/api/todaymovementscheck/checkaccountpaymentplanwithinvalidsettlementaccount
SELECT * FROM accountcore.account_payment_plan app LEFT JOIN accountcore.account a on a.number = app.settlement_account 
WHERE a.number IS NULL AND app.settlement_account IS NOT NULL

--/services/accountcore/api/accountbalancecheck/checkinconsistentaccountbalanceamountbycurrency
SELECT SUM(o.balance_amount), o.balance_currency
FROM accountcore.account_balance o GROUP BY o.balance_currency HAVING(SUM(o.balance_amount) <> 0)

--/services/accountcore/api/monetarytransactioncheck/checkMonetaryTransactionWithoutMonetaryTransactionItem
select mt.id from accountcore.monetary_transaction mt 
left join accountcore.monetary_transaction_item mti on mti.transaction_id=mt.id 
where mti.transaction_id is null

--/services/accountcore/api/accountchecks/checkcurrencymismatchbetweenaccountandinterestsettlementaccountinaccountpaymentplan
select * from accountcore.Account_Payment_Plan app
join accountcore.account_payment_plan_definition appd ON app.payment_Plan_Definition = appd.id
join accountcore.Account a on appd.interest_Settlement_Account = a.number
where a.currency<>app.amount_currency or (a.currency<>app.paid_Amount_currency and app.paid_Amount_currency is not null)

--/services/accountcore/api/checkcurrencymismatchbetweenaccountandprincipalpaysettlementaccountinaccountpaymentplan
select * from accountcore.Account_Payment_Plan app
join accountcore.account_payment_plan_definition appd ON app.payment_Plan_Definition = appd.id
join accountcore.Account a on appd.principal_Pay_Settlement_Account = a.number
where a.currency<>app.amount_currency or (a.currency<>app.paid_Amount_currency and app.paid_Amount_currency is not null)

--/services/accountcore/api/accountchecks/checkcurrencymismatchbetweenaccountandprincipalsettlementaccountinaccountpaymentplan
select * from accountcore.Account_Payment_Plan app
join accountcore.account_payment_plan_definition appd ON app.payment_Plan_Definition = appd.id
join accountcore.Account a on appd.principal_Settlement_Account = a.number
where a.currency<>app.amount_currency or (a.currency<>app.paid_Amount_currency and app.paid_Amount_currency is not null)

--/services/accountcore/api/accountchecks/checkcurrencymismatchbetweenaccountandsettlementaccountinaccountpaymentplan
SELECT * FROM accountcore.Account_Payment_Plan app
JOIN accountcore.Account a on app.settlement_Account=a.number
WHERE a.currency<>app.amount_currency or (a.currency<>app.paid_Amount_currency AND app.paid_Amount_currency IS NOT NULL)

--/services/accountcore/api/accountinterestcheck/checkaccountinterestbynextcycledate
--SELECT * FROM accountcore.account_interest i WHERE i.next_cycle_date>GETDATE()

--/services/accountcore/api/monetarytransactioncheck/checkinconsistentmonetarytransactionwithinlastyear
SELECT mti.transaction_id, mti.unit_code, mti.transaction_currency, SUM(mti.transaction_amount) AS sum_all FROM
accountcore.monetary_transaction_item mti JOIN accountcore.monetary_transaction mt ON mti.transaction_id=mt.id
WHERE mt.posting_date >= (SELECT DATEADD(YEAR,-1,GETDATE()))
GROUP BY mti.transaction_id, mti.unit_code, mti.transaction_currency HAVING SUM(mti.transaction_amount) <> 0

--/services/accountcore/api/accountbalancecheck/checkaccountblockedbalancedoesnotmatchblockagedetails
SELECT b.account AS account, total_blockage_amount AS totalBlockageAmount, blocked_balance_amount AS blockedBalanceAmount
FROM accountcore.account_balance a
LEFT JOIN (
SELECT account, SUM(blockage_amount) AS total_blockage_amount
FROM accountcore.account_blockage WHERE status=0 GROUP BY account
) b ON a.account_id=b.account
WHERE blocked_balance_amount<>ISNULL(total_blockage_amount, 0)

--/services/accountcore/api/accountbalancecheck/checkaccountblockedbalanceisnotnegative
SELECT * FROM accountcore.Account_Balance ab WHERE ab.blocked_balance_amount  <0

--/services/accountcore/api/accountbalancecheck/checkoverdraftlimitisnotnegative
SELECT * FROM accountcore.Account_Balance ab WHERE ab.overdraft_Limit_amount <0

--/services/accountcore/api/accountchecks/checkblockageamountisnotnegative
SELECT * FROM accountcore.Account_Balance ab WHERE ab.blocked_balance_amount<0

--/services/accountcore/api/allaccountledgerdifferencescheck/lastWeek
SELECT * FROM accountcore.all_account_ledger_differences aald WHERE date BETWEEN DATEADD(WEEK, -1, GETDATE()) AND GETDATE()

--/services/accountcore/api/allaccountledgerdifferencescheck/today
SELECT * FROM accountcore.all_account_ledger_differences aald WHERE date = GETDATE()

--/services/accountcore/api/allaccountledgerdifferencescheck/calculateDifferences
SELECT * FROM
    (SELECT currency_code AS currency, dimension_index1 AS owniningUnitCode, dimension_index2 AS accountingCode, SUM(balance) AS [difference] FROM [accountcore].[accountcore].[all_ledger_account_summary] WHERE book_definition='IQBDDK' GROUP BY currency_code, dimension_index1, dimension_index2
     UNION ALL
     SELECT currency_code AS currency, dimension_index1 AS owniningUnitCode, dimension_index2 AS accountingCode, SUM(balance) AS [difference] FROM [accountcore].[accountcore].[all_ledger_account_summary] WHERE book_definition='TRBDDK' GROUP BY currency_code, dimension_index1, dimension_index2
     UNION ALL
     SELECT currency, owning_unit_code AS owniningUnitCode, accounting_code_local AS accountingCode, SUM(balance) AS [difference] FROM [accountcore].[accountcore].[all_account_summary] GROUP BY currency, owning_unit_code, accounting_code_local
     UNION ALL
     SELECT currency, owning_unit_code as owniningUnitCode, accounting_code_central AS accountingCode, SUM(balance) AS [difference] FROM [accountcore].[accountcore].[all_account_summary] GROUP BY currency, owning_unit_code, accounting_code_central) AS result
WHERE result.difference <> 0 GROUP BY result.currency, result.accountingCode, result.owniningUnitCode, result.difference

--/services/accountcore/api/accountchecks/checkInterBranchCurrentAccountBalance
-- IQBDDK
SELECT dimension_index1, SUM(balance_in_ledger_currency) as [SUM]
FROM [accountcore].[accountcore].[all_ledger_account_summary]
where dimension_index2 IN ('6600000', '6600001') and book_definition = 'IQBDDK'
group by dimension_index1
having (SUM(balance_in_ledger_currency) > 0.10 or SUM(balance_in_ledger_currency) < -0.10)

-- TRBDDK
SELECT dimension_index1, SUM(balance_in_ledger_currency) as [SUM]
FROM [accountcore].[accountcore].[all_ledger_account_summary]
where dimension_index2 IN ('290', '291') and book_definition = 'TRBDDK'
group by dimension_index1 having SUM(balance_in_ledger_currency) > 0.10 or SUM(balance_in_ledger_currency) < -0.10

--/services/accountcore/api/accountchecks/checkactualposition
-- IQBDDK
SELECT dimension_index1, SUM(balance_in_ledger_currency) as [SUM]
FROM [accountcore].[accountcore].[all_ledger_account_summary]
where dimension_index2 IN ('7110000', '7110001') and book_definition = 'IQBDDK'
group by dimension_index1
having (SUM(balance_in_ledger_currency) > 0.10 or SUM(balance_in_ledger_currency) < -0.10)

-- TRBDDK
SELECT dimension_index1, SUM(balance_in_ledger_currency) as [SUM]
FROM [accountcore].[accountcore].[all_ledger_account_summary]
where dimension_index2 IN ('294', '295') and book_definition = 'TRBDDK'
group by dimension_index1 having SUM(balance_in_ledger_currency) > 0.10 or SUM(balance_in_ledger_currency) < -0.10

--/services/accountcore/api/accountchecks/checkactualswposition
-- IQBDDK
SELECT dimension_index1, SUM(balance_in_ledger_currency) as [SUM]
FROM [accountcore].[accountcore].[all_ledger_account_summary]
where dimension_index2 IN ('7120000', '7120001') and book_definition = 'IQBDDK'
group by dimension_index1
having (SUM(balance_in_ledger_currency) > 0.10 or SUM(balance_in_ledger_currency) < -0.10)

-- TRBDDK
SELECT dimension_index1, SUM(balance_in_ledger_currency) as [SUM]
FROM [accountcore].[accountcore].[all_ledger_account_summary]
where dimension_index2 IN ('294', '295') and book_definition = 'TRBDDK'
group by dimension_index1 having SUM(balance_in_ledger_currency) > 0.10 or SUM(balance_in_ledger_currency) < -0.10

--/services/accountcore/api/accountbalancecheck/checkAndGetDifferencesWithAccountBalanceTableForBlockageAmount
SELECT bk.account, SUM(bk.blockage_amount), bl.blocked_balance_amount
FROM accountcore.account_balance bl
LEFT JOIN accountcore.account_blockage bk ON bk.account = bl.account_id
GROUP BY bk.account, bl.blocked_balance_amount, bk.status
HAVING bl.blocked_balance_amount != SUM(coalesce(bk.blockage_amount,0)) and bk.status = 0
*/
-- /services/accountcore/api/accountchecks/checkclosedandbalancenotequalszero
SELECT * FROM accountcore.account a
JOIN accountcore.account_balance b on a.balance = b.id
where a.is_closed=1 and b.balance_amount <> 0
--/services/accountcore/api/accountchecks/checkinvalidledgerbalancesumperbranchandcurrency
-- TRBDDK
/*
SELECT dimension_index1, currency_code, SUM(balance_in_ledger_currency)
FROM accountcore.all_ledger_account_summary
where book_definition='TRBDDK'
GROUP BY dimension_index1, currency_code
HAVING SUM(balance_in_ledger_currency) <> 0

-- IQBDDK
SELECT dimension_index1, currency_code, SUM(balance_in_ledger_currency)
FROM accountcore.all_ledger_account_summary
WHERE book_definition='IQBDDK'
GROUP BY dimension_index1, currency_code
HAVING SUM(balance_in_ledger_currency) <> 0
*/
--/services/accountcore/api/accountchecks/checkemptyaccountingcodeperaccount
SELECT account.number FROM accountcore.account
JOIN accountcore.account_type ON account.account_type=account_type.id
LEFT JOIN accountcore.account_accounting_code ON account_accounting_code.account_id=account.id
WHERE is_internal=0 AND account_accounting_code.accounting_code IS NULL
/*
-- /services/accountcore/api/monetarytransactioncheck/checkmonetarytransactiondefinitionitemcountperpair
select e.definition.id as definitionId, e.pair, COUNT(e) from MonetaryTransactionDefinitionItem e
GROUP BY e.definition.id, e.pair HAVING(COUNT(e) <> 2)
*/


--eklenmesi gereken sorgular
select * from accountcore.customer_account ca where ca.contract is null

--account without current_account
select count(*) from accountcore.account a
join accountcore.account_type act on a.account_type=act.id
left join currentaccount.current_account ca on ca.number=a.number
where code in ('CA', 'CB') and ca.number is null


--current_account without account
select count(*) from accountcore.account a
right join currentaccount.current_account ca on ca.number=a.number
where a.number is null

	--account without nostro_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join currentaccount.nostro_account ca on ca.number=a.number
	where code in ('CN', 'CV') and ca.number is null
	union
	--nostrot_account without account
	select count(*) from accountcore.account a
	right join currentaccount.nostro_account ca on ca.number=a.number
	where a.number is null

--/services/accountcore/api/accountbalancecheck/checkaccountbalancenothavingaccount
--RIGHT JOIN yazılmış commonsta ama native query değil right join çalışmıyor olabilir
SELECT a.id, a.balance, a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency
FROM accountcore.account a JOIN accountcore.account_balance b ON a.balance = b.id WHERE a.id = null


SELECT ab.account_id, count(*) FROM accountcore.account_balance ab
GROUP BY ab.account_id
HAVING count(*) > 1


SELECT ca.contract, count(*) FROM accountcore.customer_account ca 
GROUP BY ca.contract
HAVING count(*) > 1



