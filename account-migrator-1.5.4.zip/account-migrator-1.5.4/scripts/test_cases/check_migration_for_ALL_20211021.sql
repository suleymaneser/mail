
-- START check if count of balance record that does not match any account record is zero
PRINT '----------------------------'
DECLARE @countOfOrphanAccountBalanceRecord bigint;
SET @countOfOrphanAccountBalanceRecord=(
	select count(*) from accountcore.account
	right join accountcore.account_balance
	on accountcore.account_balance.account_id = accountcore.account.id
	where accountcore.account.id is null
)
PRINT 'Count of orphan account_balance records is ' + ISNULL(CAST(@countOfOrphanAccountBalanceRecord AS VARCHAR(100)),0)
IF @countOfOrphanAccountBalanceRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of orphan account_balance records should be zero but actual value is ' + ISNULL(CAST(@countOfOrphanAccountBalanceRecord AS VARCHAR(100)),0)
END
-- END check if sum of all balances is zero

-- START check if count of balance record that is not linked with any account record is zero
PRINT '----------------------------'
DECLARE @countOfUnlinkedAccountBalanceRecord bigint;
SET @countOfUnlinkedAccountBalanceRecord=(
	select count(*) from accountcore.account_balance
	where accountcore.account_balance.account_id=0
)
PRINT 'Count of unlinked account_balance records is ' + ISNULL(CAST(@countOfUnlinkedAccountBalanceRecord AS VARCHAR(100)),0)
IF @countOfUnlinkedAccountBalanceRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of unlinked account_balance records should be zero but actual value is ' + ISNULL(CAST(@countOfUnlinkedAccountBalanceRecord AS VARCHAR(100)),0)
END
-- END check if sum of all balances is zero

-- START check count of account owner record that does not match any customer account record is zero
PRINT '----------------------------'
DECLARE @countOfOrphanAccountOwnerRecord bigint;
SET @countOfOrphanAccountOwnerRecord=(
	select count(*) from (
		select ao.* from accountcore.account_owner ao where account is null
		union
		select ao.* from accountcore.account_owner ao
		left join accountcore.customer_account ca on ao.account=ca.id
		where ca.id is null
	) temp_table
)
PRINT 'Count of orphan account_Owner records is ' + ISNULL(CAST(@countOfOrphanAccountOwnerRecord AS VARCHAR(100)),0)
IF @countOfOrphanAccountOwnerRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of orphan account_Owner records should be zero but actual value is ' + ISNULL(CAST(@countOfOrphanAccountOwnerRecord AS VARCHAR(100)),0)
END
-- END check count of account owner record that does not match any customer account record is zero

-- START check count of account contract record that does not match any customer account record is zero
PRINT '----------------------------'
DECLARE @countOfOrphanAccountContractRecord bigint;
SET @countOfOrphanAccountContractRecord=(
	select count(*) from accountcore.account_Contract ac
	left join accountcore.customer_account ca on ca.contract=ac.id
	where ca.contract is null
)
PRINT 'Count of orphan account_Contract records is ' + ISNULL(CAST(@countOfOrphanAccountContractRecord AS VARCHAR(100)),0)
IF @countOfOrphanAccountContractRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of orphan account_Contract records should be zero but actual value is ' + ISNULL(CAST(@countOfOrphanAccountContractRecord AS VARCHAR(100)),0)
END
-- END check count of account Contract record that does not match any customer account record is zero

-- START general invalid record is zero
PRINT '----------------------------'
DECLARE @countOfGeneralInvalidRecord bigint;
SET @countOfGeneralInvalidRecord=(
	select sum(result) from (
	--account without account_balance
	select count(*) as result from accountcore.account a
	left join accountcore.account_balance ab on a.balance=ab.id
	where ab.id is null
	union
	--account_balance without account
	select count(*) from accountcore.account a
	right join accountcore.account_balance ab on a.balance=ab.id
	where a.balance is null
	union
	--account_balance without account
	select count(*) from accountcore.account_balance
	where account_id is null or account_id=0
	union
	--account_balance invalid link with account
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	where a.id<>ab.account_id
	union
	--account without account_type
	select count(*) from accountcore.account a
	left join accountcore.account_type act on a.account_type=act.id
	where act.id is null
	union
	--account without customer_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.customer_account ca on a.id=ca.id
	where ca.id is null and act.is_internal=0
	union
	--customer_account without account
	select count(*) from accountcore.account a
	right join accountcore.customer_account ca on a.id=ca.id
	where a.id is null
	union
	--account without internal_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.internal_account ia on a.id=ia.id
	where ia.id is null and act.is_internal=1
	union
	--internal_account without account
	select count(*) from accountcore.account a
	right join accountcore.internal_account ia on a.id=ia.id
	where a.id is null
	union
	/*
	--account without letter_of_guarantee
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join noncashloan.letter_of_guarantee lg on a.number=lg.number
	where lg.number is null and act.code in ('RE', 'R9', 'RX')
	union
	--letter_of_guarantee without account
	select count(*) from accountcore.account a
	right join noncashloan.letter_of_guarantee lg on a.number=lg.number
	where a.number is null
	union
	*/
	--customer_account without account_owner
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_owner ao on ao.account=ca.id
	where ao.account is null
	union
	--account_owner without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_owner ao on ao.account=ca.id
	where ca.id is null
	union
	--customer_account without account_contract
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_contract ac on ac.id=ca.contract
	where ac.id is null
	union
	--account_contract without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_contract ac on ac.id=ca.contract
	where ca.contract is null
	union
	--transaction that does not have zero sum
	select count(*) from (
		select transaction_id, sum(transaction_amount) as sum_all from accountcore.monetary_transaction_item 
		group by transaction_id having sum(transaction_amount) <> 0
	) temp_monetary_transaction_item
	union
	-- account balance that is not zero has monetary_transaction_item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	left join accountcore.monetary_transaction_item mti on mti.account=a.id
	where ab.balance_amount - ab.migrated_balance_amount <>0 and mti.account is null
	union
	-- account balance that does not match with monetary transaction item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	join (
		select account, sum(transaction_amount) as sum_of_account from accountcore.monetary_transaction_item group by account
	) temp_monetary_transaction_item on a.id=temp_monetary_transaction_item.account
	where ab.balance_amount<>temp_monetary_transaction_item.sum_of_account
	union
	--  monetary transaction item with invalid side info
	select count(*) from accountcore.monetary_transaction_item where side not in ('DEBIT', 'CREDIT')
	union
	-- DEBIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='DEBIT' and transaction_amount>=0
	union
	-- CREDIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='CREDIT' and transaction_amount<=0
	/*
	union
	-- account_value_dated_balance_history without monetary_transaction_item
	select count(*) from accountcore.account_value_dated_balance_history a
	left join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where  temp_monetary_transaction_item.account is null
	*/
	union
	-- monetary_transaction_item without account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	right join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where a.date is null
	union
	-- unequal monetary_transaction_item and account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	join (
		select account, value_date, sum(sum_of_transaction_amount) OVER (partition by account order by account, value_date) as daily_sum from(
			select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
		) temp
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where daily_sum<>value_dated_balance_amount
	) general_temp_table
)
PRINT 'Count of general invalid record is ' + ISNULL(CAST(@countOfGeneralInvalidRecord AS VARCHAR(100)),0)
IF @countOfGeneralInvalidRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of general invalid record should be zero but actual value is ' + ISNULL(CAST(@countOfGeneralInvalidRecord AS VARCHAR(100)),0)
END
-- END general invalid record is zero



