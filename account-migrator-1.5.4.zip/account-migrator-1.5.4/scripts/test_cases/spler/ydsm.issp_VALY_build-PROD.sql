USE [rallyIQ]
GO

/****** Object:  StoredProcedure [ydsm].[issp_VALY_build]    Script Date: 20.04.2022 13:59:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ydsm].[issp_VALY_build] 

 @brn		smallint	= null -- branch
,@p0date	int			= null -- current brach date
,@nbd		int			= null -- next bussiness date
,@flag5		char(1)		= null -- 'E' ise eod
,@scn		char(1)		= null -- g�n senaryosu 'N' : normal day
,@pldate	int			= null -- bir sonraki ayin ilk g�n� 
,@pyear 	int			= null -- bir sene �ncesi
,@p2year 	int			= null -- bir sene �ncesi int

AS

  BEGIN

	DECLARE
	 @p0sta					char(1)
	,@m31brn				smallint
	,@m31acc				int
	,@m31sfx				smallint
	,@m31typ				char(3)
	,@m31ref				char(13)
	,@m31amt				decimal (18, 2)
	,@m31ccy				char(3)

	,@m31std				int
	,@m31lcd				int
	,@m31ncd				int
	,@m31mtd				int

	,@m31amtDy2d			decimal (18, 2)
	,@m31amtDi1				decimal (18, 2)
	,@m31amtDp4				decimal (18, 2)
	,@m31amtDtot			decimal (18, 2)
	,@m31blcgDi				varchar(10)
	,@m31blcgDir			varchar(10)
	,@m31rtD				char(2)
	,@m31rateD				decimal (18, 9)
	,@m31frqD				char(3)
	,@m31holdD				decimal (18, 2)		

	,@m31amtCy2d			decimal (18, 2)
	,@m31amtCi1				decimal (18, 2)
	,@m31amtCp4				decimal (18, 2)
	,@m31amtCtot			decimal (18, 2)
	,@m31blcgCi				varchar(10)
	,@m31blcgCir			varchar(10)
	,@m31rtC				char(2)
	,@m31rateC				decimal (18, 9)
	,@m31frqC				char(3)

	,@m31blcg				varchar(10)
	,@m31exr				decimal (20, 7)
	,@m31time				char(5)
	,@m31mprice				decimal (11, 9)
	,@m31arc				char(1)

	,@p1ap					char(1)
	,@p1stl					char(1)
	,@a2str					char(1)
	,@a2str2				char(1)
	,@d2app					char(2)
	,@d9Pamt				decimal (18, 2)
	,@d9Samt				decimal (18, 2)
	,@d9Pccy				char(3)
	,@d9Sccy				char(3)
	,@d9Psfx				smallint
	,@d9Ssfx				smallint
	,@d9ref					char(13)
	,@d9opd					int
	,@d9pl					int

	,@m8amtR				decimal (18, 2)
	,@m8amtP				decimal (18, 2)

	,@a1atyp				char(2)
	,@a1blcg				varchar(10)
	,@a1blcg2				varchar(10)
	,@a1sumadj				decimal (18, 2)
	,@a1sumCD				decimal (18, 2)

	,@d1blcg2				varchar(10)

	,@d11ccont				int
	,@d11blcgD				varchar(10)
	,@d11blcgC				varchar(10)
	,@d11tmd				int
	,@d11mtd				int
	,@u1code				smallint

	,@d8dacc				int
	,@d8dsfx				smallint
	,@d8iacc				int
	,@d8isfx				smallint
	,@d8ichr				char(1)

	,@d8amti1				decimal (18, 2)
	,@d8amti3				decimal (18, 2)
	,@d8amtp4				decimal (18, 2)
	,@a8Dpl					int
	,@a8Cpl					int
	,@d8pl					int
	,@d8tot					decimal (18, 2)

	,@a8Damti1				decimal (18, 2)
	,@a8Damti2				decimal (18, 2)
	,@a8Damti3				decimal (18, 2)
	,@a8Camti1				decimal (18, 2)
	,@a8Camti2				decimal (18, 2)
	,@a8Camti3				decimal (18, 2)

	,@a8Cncd				int
	,@a8Dncd				int
	,@a8Clcd				int
	,@a8Dlcd				int

	,@d7net					decimal (18, 2)
	,@d7cycd				int
	,@a7intp1				decimal (18, 2)
	,@a7intp1C				decimal (18, 2)
	,@a7intp1D				decimal (18, 2)
	,@d7intp1				decimal (18, 2)
	,@d2typ0				char(1)

	,@m31code 				smallint
	,@m31codeL 				char(1)	
	,@m31codeX 				tinyint
	,@m31limitAmt			decimal (18, 2)
	,@m31limitccy			char(3)
	,@m31limittype			char(1)
	,@a2cat					char(5)
	,@pl					char(6)

	,@janfirst				int
	,@SQLString				nvarchar(1000)
	,@ParmDefinition		nvarchar(500)
	,@safeP4				decimal (18, 2)
	,@m31abmflg 			tinyint
	,@d11lmd				int
	,@d1mnt 				tinyint
	,@d1tbrn				smallint
	,@d1stl 				char(1)	
	,@d1psd					int
	,@d1ctd					int
	,@d4amt2				decimal (18, 2)
	,@d4mtd2				int
	,@d8amti2				decimal (18, 2)
	,@d8ar					decimal (18, 9)
	,@d8ar2					decimal (18, 9)
	,@d14equpay				char(1)
	,@d14frqP				char(3)
	,@d14cat				char(2)
	,@m31restructured		tinyint
	,@m31cstage				smallint
	,@m31tobrn				smallint
	,@m31toacc				int
	,@m31tosfx				smallint
	,@m31totyp				char(3)
	,@m31toref				char(13)
	,@m31toamtDi1           decimal (18, 2)
	,@m31toamtCi1           decimal (18, 2)
	,@m31todate             int
	,@accountId				int

	

--initialize all related table(s)

	BEGIN TRANSACTION

		delete from VALY where m31brn = @brn
		update ACCT set a1gl = 0 
		from ydsm.acct left join ydsm.rlvz on a1brn = m37brna and a1acc = m37acc and a1sfx = m37sfx
		where a1gl <> 0 and a1brn=@brn and m37brna is null
		set @janfirst = @p0date / 10000
		set @janfirst = @janfirst * 10000 + 101

	COMMIT TRANSACTION

---------------------------------------------------------------------------------------

	set @m31holdD= 0


--step 1: debit ACCT

	BEGIN TRANSACTION

	if @flag5 = 'E'
	begin
		DECLARE csr_VALY_build_ACCT1 cursor for
		select
		 a1brn
		,a1acc
		,a1sfx
		,a1bal + a1sumadj
		,a1sumadj
		,a1sumC + a1sumD

		,a1ccy
		,a1atyp
		,a1blcg

		,a2cat

		,a8Dpl
		,a8Damti1
		,a8damti2
		,a8Damti3
		,a8Damtp4
		,a8Dtot
		,a8Daprr
		,a8Difq
		,a8dlcd
		,a8dncd

		,case a8Dact 
			when 0 then case a8Daprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end

		,a8Cpl
		,a8Camti1
		,a8camti2
		,a8Camti3
		,a8Camtp4
		,a8Ctot
		,a8Caprr
		,a8Cifq
		,a8clcd
		,a8cncd

		,case a8Cact 
			when 0 then case a8Caprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end
		,a7intp1C
		,a7intp1d
		,a1flg7
		,a1flg13
		from ACCT
		left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
		     join ATYP on a1atyp = a2mne
		left join isvw_HR05_a7intp1_D d on a1brn = d.a7brn  and a1acc = d.a7acc  and a1sfx = d.a7sfx
		left join isvw_HR05_a7intp1_C c on a1brn = c.a7brn  and a1acc = c.a7acc  and a1sfx = c.a7sfx
		left join rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
		where a1brn  = @brn
		and   a2blcg = 'N' 
		and   a1bal + a1sumadj <= 0 
        and   a1cls = 'N'
		and   a2str  <> 'X'
		and   m37brna is null
		and   a1atyp <> 'SA'		
		order by a1blcg, a1ccy
	end
	else
	begin
		DECLARE csr_VALY_build_ACCT1 cursor for
		select
		 a1brn
		,a1acc
		,a1sfx
		,a1bal + a1sumC + a1sumD
		,a1sumadj
		,0

		,a1ccy
		,a1atyp
		,a1blcg

		,a2cat

		,a8Dpl
		,a8Damti1
		,a8damti2
		,a8Damti3
		,a8Damtp4
		,a8Dtot
		,a8Daprr
		,a8Difq
		,a8dlcd
		,a8dncd

		,case a8Dact 
			when 0 then case a8Daprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end

		,a8Cpl
		,a8Camti1
		,a8camti2
		,a8Camti3
		,a8Camtp4
		,a8Ctot
		,a8Caprr
		,a8Cifq
		,a8clcd
		,a8cncd

		,case a8Cact 
			when 0 then case a8Caprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end
		,a7intp1C
		,a7intp1d
		,a1flg7
		,a1flg13
		from ACCT
		left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
		     join ATYP on a1atyp = a2mne
		left join isvw_HR05_a7intp1_D d on a1brn = d.a7brn  and a1acc = d.a7acc  and a1sfx = d.a7sfx
		left join isvw_HR05_a7intp1_C c on a1brn = c.a7brn  and a1acc = c.a7acc  and a1sfx = c.a7sfx
		left join rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
		where a1brn  = @brn
		and   a2blcg = 'N' 
		and   a1bal + a1sumC + a1sumD <= 0 
        and   a1cls = 'N'
		and   a2str  <> 'X'
		and   m37brna is null
		and   a1atyp <> 'SA'		
		order by a1blcg, a1ccy

	end

	open csr_VALY_build_ACCT1

	fetch Next from csr_VALY_build_ACCT1 Into
	 @m31brn
	,@m31acc
	,@m31sfx
	,@m31amt
	,@a1sumadj
	,@a1sumCD

	,@m31ccy
	,@a1atyp
	,@m31blcg
	
	,@a2cat

	,@a8Dpl
	,@m31amtDi1
	,@a8Damti2
	,@a8Damti3
	,@m31amtDp4
	,@m31amtDtot
	,@m31rateD
	,@m31frqD
	,@a8Dlcd
	,@a8Dncd
	,@m31rtD

	,@a8Cpl
	,@m31amtCi1
	,@a8Camti2
	,@a8Camti3
	,@m31amtCp4
	,@m31amtCtot
	,@m31rateC
	,@m31frqC
	,@a8Clcd
	,@a8Cncd
	,@m31rtC
	,@a7intp1C
	,@a7intp1D
	,@m31restructured
	,@m31cstage
	while @@Fetch_Status = 0

	begin
                
                if @m31amt = 0 and @m31blcg = ''
                begin
                   select @m31blcg = a1blcg2 from acct 
                   where a1brn = @m31brn and a1acc = @m31acc and a1sfx = @m31sfx
                end
                
		set @safeP4 = 0

		if @a8Dpl is null 
		begin
			set @a8Dpl 	= 0
			set @m31amtDi1	= 0
			set @a8Damti2   = 0 
			set @a8Damti3	= 0
			set @m31amtDp4	= 0
			set @m31amtDtot	= 0
			set @m31rateD	= 0
			set @m31frqD    = ' ' 
			set @m31rtD     = ' '
			set @a8Dlcd     = 0
			set @a8Dncd     = 0
	
			set @a8Cpl	= 0
			set @m31amtCi1	= 0
			set @a8Camti2   = 0 
			set @a8Camti3	= 0
			set @m31amtCp4	= 0
			set @m31amtCtot	= 0
			set @m31rateC	= 0
			set @m31frqC    = ' '
			set @m31rtC     = ' '
			set @a8Clcd     = 0
			set @a8Cncd     = 0
		end

              

		set @m31amtDy2d = 0
		set @m31blcgDi  = ' '
		set @m31blcgDir = ' '

		set @m31amtCy2d = 0
		set @m31blcgCi  = ' '
		set @m31blcgCir = ' '

		set @a7intp1    = 0 

		set @m31code  	= 0
		set @m31codel 	= ' '
		set @m31codeX 	= 0
		set @m31limitAmt= 0
		set @m31limitccy= ' '
		set @m31limittype= ' '

		select TOP 1
		 @m31code  	= l6code
		,@m31codel 	= l6codel
		,@m31codex 	= l6codex
		,@m31limitamt = l6amt
		,@m31limitccy = l0ccy
		,@m31limittype = 'C'
		from LATR 
		join LANA on l6brn = l0brn and l6acc = l0acc
		where l6cat = 'LS350' and l6acc = @m31acc and l6cat = @a2cat
		order by right('0000' + cast(l6code as varchar(4)) , 4) +
					   l6codel + 
					   right('000' + cast(l6codex as varchar(3)) , 3) ASC

		if @m31limitAmt = 0
		begin
				select TOP 1
				 @m31code  	= isnull(l6code, ' ')
				,@m31codel 	= isnull(l6codel, 0)
				,@m31codex 	= isnull(l6codex, ' ')
				,@m31limitamt = isnull(l6amt, 0)
				,@m31limitccy = isnull(l0ccy, ' ')
				,@m31limittype = 'G'
				from LATR
				right join CSTM on l6grp = c1grp and l6brn = @m31brn and l6code = @m31code and l6codel = @m31codel and l6codex = @m31codex  
				join LANA on l6brn = l0brn and l6acc = l0acc
				where l6cat = 'LS350' and l6acc = @m31acc and l6cat = @a2cat and c1acc = @m31acc and c1brn = @brn
				order by right('0000' + cast(l6code as varchar(4)) , 4) +
							   l6codel + 
					   right('000' + cast(l6codex as varchar(3)) , 3) ASC
		end		

		if @m31code is null
		begin
			set @m31code  	= 0
			set @m31codel 	= ' '
			set @m31codeX 	= 0
			set @m31limitAmt= 0
			set @m31limitccy= ' '
			set @m31limittype= ' '
		end

		if @a8Dpl <> 0 or @m31amtDi1 <> 0 or @m31amtDp4 <> 0
		begin
			select @u1code 	  = u1code  from CCYS where u1ccy = @m31ccy
			select @m31blcgDi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @a8Dpl and a1sfx = @u1code
			
			select @a7intp1   = sum(a7intp1) 
			from AINP 
			join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
			where a8brn = @brn and a8acc = @m31acc and a8sfx = @m31sfx and a7cycd >= @janfirst and a7dc = 'D'

	-----------
			select @safeP4  = a3Dibf
			from ABFW 
			where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
	
			if @safeP4 is null
			begin
				set @safeP4  = 0
			end
	
			if @safeP4 = 0 or @safeP4 = null
			begin
				select @safeP4  = a3Ditp
				from ABFW 
				where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
			end
	
			if @safeP4 is null
			begin
				set @safeP4  = 0
			end
	------------
	
			if @a7intp1 is null
			begin
				set @a7intp1  = 0
			end

			if @scn not in ('N', 'W')
			begin
				set @m31amtDi1 = @a8Damti3
			end
--			set @m31amtDy2d =  @m31amtDi1 + @a7intp1 - @m31amtDp4
			set @m31amtDy2d =  @m31amtDi1 + @a7intp1 - @safeP4

			set @pl = '99' + substring(cast(@a8Dpl as char(6)),3,4)

			select @m31blcgDir = a1blcg from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code



		end

		if @a8Cpl <> 0 or @m31amtCi1 <> 0 or @m31amtCp4 <> 0
		begin
			select @u1code 	  = u1code from CCYS where u1ccy = @m31ccy
			select @m31blcgCi = a1blcg from ACCT where a1brn = @brn and a1acc = @a8Cpl and a1sfx = @u1code

			select @a7intp1   = sum(a7intp1) 
			from AINP 
			join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
			where a8brn = @brn and a8acc = @m31acc and a8sfx = @m31sfx and a7cycd >= @janfirst  and a7dc = 'C'

-----------
			select @safeP4  = a3Cibf
			from ABFW 
			where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
	
			if @safeP4 is null
			begin
				set @safeP4  = 0
			end
	
			if @safeP4 = 0 or @safeP4 = null
			begin
				select @safeP4  = a3Citp
				from ABFW 
				where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
			end
	
			if @safeP4 is null
			begin
				set @safeP4  = 0
			end
	------------

			if @a7intp1 is null
			begin
				set @a7intp1  = 0
			end

			if @scn not in ('N', 'W')
			begin
				set @m31amtCi1 = @a8Camti3
			end

--			set @m31amtCy2d =  @m31amtCi1 + @a7intp1 - @m31amtCp4
			set @m31amtCy2d =  @m31amtCi1 + @a7intp1 - @safeP4

			set @pl = '99' + substring(cast(@a8Cpl as char(6)),3,4)

			select @m31blcgCir = a1blcg2 from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code

		end
		
		if @a1atyp = 'YP' 
		begin
			if @scn in ('N','W') 
			begin
				set @m31amtCi1 = @a1sumadj 
			end
			else
			begin
				set @m31amtCi1 = @a1sumadj --+ @a1sumCD
			end
		end

		set @m31exr			= 0
		set @m31time 		= ''
		set @m31mprice 		= 0
		set @m31arc 		= ''
		set @m31tobrn		= 0	
		set @m31toacc		= 0	
		set @m31tosfx		= 0	
		set @m31totyp		= ''	
		set @m31toref		= ''	
		set @m31toamtDi1	= 0   
		set @m31toamtCi1	= 0   
		set @m31todate		= 0   

		insert into VALY values(@m31brn, @m31acc, @m31sfx, ' ',' ', @m31amt, @m31ccy, @p0date, @p0date, @p0date, @p0date, @m31amtDy2d, @m31amtDi1, isnull(@a8Damti2, 0), @m31amtDp4, @a8Dpl, @m31amtDtot, @m31blcgDi, @m31blcgDir, @m31rtD, @m31rateD, @m31frqD, @m31holdD, @m31amtCy2d, @m31amtCi1, isnull(@a8camti2, 0), @m31amtCp4, @a8Cpl, @m31amtCtot, @m31blcgCi, @m31blcgCir, @m31rtC, @m31rateC, @m31frqC, isnull(@a7intp1C, 0), isnull(@a7intp1d, 0), @m31blcg,@m31code,@m31codel,@m31codex,@m31limitAmt,@m31limitccy,@m31limittype,1,@m31exr,@m31time,@m31mprice,@m31arc, 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 'N', ' ', ' ', isnull(@a8dlcd, 0), isnull(@a8dncd, 0), isnull(@a8clcd, 0), isnull(@a8cncd, 0), ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ', @m31restructured,@m31cstage,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)
		
		execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx

		fetch Next from csr_VALY_build_ACCT1 Into
		 @m31brn
		,@m31acc
		,@m31sfx
		,@m31amt
		,@a1sumadj
		,@a1sumCD

		,@m31ccy
		,@a1atyp
		,@m31blcg

		,@a2cat

		,@a8Dpl
		,@m31amtDi1
		,@a8Damti2
		,@a8Damti3
		,@m31amtDp4
		,@m31amtDtot
		,@m31rateD
		,@m31frqD
		,@a8Dlcd
		,@a8Dncd
		,@m31rtD
	
		,@a8Cpl
		,@m31amtCi1
		,@a8Camti2
		,@a8Camti3
		,@m31amtCp4
		,@m31amtCtot
		,@m31rateC
		,@m31frqC
		,@a8Clcd
		,@a8Cncd
		,@m31rtC
		,@a7intp1C
		,@a7intp1D
		,@m31restructured
		,@m31cstage

	end

	close csr_VALY_build_ACCT1

	deallocate csr_VALY_build_ACCT1

	COMMIT TRANSACTION

---------------------------------------------------------------------------------------

--step 2: credit ACCT



	BEGIN TRANSACTION

	set @m31code  	= 0
	set @m31codel 	= ' '
	set @m31codeX 	= 0
	set @m31limitAmt= 0
	set @m31limitccy= ' '
	set @m31limittype= ' '

	if @flag5 = 'E'
	begin
		DECLARE csr_VALY_build_ACCT2 cursor for
		select
		 a1brn
		,a1acc
		,a1sfx
		,a1bal + a1sumadj
		,a1sumadj

		,a1ccy
		,a1atyp
		,a1blcg2

		,a8Dpl
		,a8Damti1
		,a8damti2
		,a8Damti3
		,a8Damtp4
		,a8Dtot
		,a8Daprr
		,a8Difq
		,a8dlcd
		,a8dncd

		,case a8Dact 
			when 0 then case a8Daprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end

		,a8Cpl
		,a8Camti1
		,a8camti2
		,a8Camti3
		,a8Camtp4
		,a8Ctot
		,a8Caprr
		,a8Cifq
		,a8clcd
		,a8cncd
		
		,case a8Cact 
			when 0 then case a8Caprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end
		,a7intp1C
		,a7intp1d

		from ACCT
		left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
		     join ATYP on a1atyp = a2mne
		left join isvw_HR05_a7intp1_D d on a1brn = d.a7brn  and a1acc = d.a7acc  and a1sfx = d.a7sfx
		left join isvw_HR05_a7intp1_C c on a1brn = c.a7brn  and a1acc = c.a7acc  and a1sfx = c.a7sfx
		left join rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
		where a1brn  = @brn
		and   a2blcg = 'N'
		and a1bal + a1sumadj > 0
        and   a1cls = 'N'
		and   a2str  <> 'X'
		and   m37brna is null
		and   a1atyp <> 'SA'		
		order by a1blcg2, a1ccy
	end
	else
	begin
		DECLARE csr_VALY_build_ACCT2 cursor for
		select
		 a1brn
		,a1acc
		,a1sfx
		,a1bal + a1sumC + a1sumD
		,a1sumadj

		,a1ccy
		,a1atyp
		,a1blcg2

		,a8Dpl
		,a8Damti1
		,a8damti2
		,a8Damti3
		,a8Damtp4
		,a8Dtot
		,a8Daprr
		,a8Difq
		,a8dlcd
		,a8dncd

		,case a8Dact 
			when 0 then case a8Daprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end
		,a8Cpl
		,a8Camti1
		,a8camti2
		,a8Camti3
		,a8Camtp4
		,a8Ctot
		,a8Caprr
		,a8Cifq
		,a8clcd
		,a8cncd

		,case a8Cact 
			when 0 then case a8Caprr 
						when 0 then ' '	
						else        'LS'
					end 
			else   'SB'  
		 end
		,a7intp1C
		,a7intp1d

		from ACCT
		left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
		     join ATYP on a1atyp = a2mne
		left join isvw_HR05_a7intp1_D d on a1brn = d.a7brn  and a1acc = d.a7acc  and a1sfx = d.a7sfx
		left join isvw_HR05_a7intp1_C c on a1brn = c.a7brn  and a1acc = c.a7acc  and a1sfx = c.a7sfx
		left join rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
		where a1brn  = @brn
		and   a1bal + a1sumC + a1sumD  > 0 
		and   a2blcg = 'N'
		and   a2str  <> 'X'
        and   a1cls = 'N'
		and   m37brna is null
		and   a1atyp <> 'SA'
		order by a1blcg2, a1ccy
	end

		open csr_VALY_build_ACCT2

		fetch Next from csr_VALY_build_ACCT2 Into
		 @m31brn
		,@m31acc
		,@m31sfx
		,@m31amt
		,@a1sumadj

		,@m31ccy
		,@a1atyp
		,@m31blcg

		,@a8Dpl
		,@m31amtDi1
		,@a8Damti2
		,@a8Damti3
		,@m31amtDp4
		,@m31amtDtot
		,@m31rateD
		,@m31frqD

		,@a8Dlcd
		,@a8Dncd
		,@m31rtD

		,@a8Cpl
		,@m31amtCi1
		,@a8Camti2
		,@a8Camti3
		,@m31amtCp4
		,@m31amtCtot
		,@m31rateC
		,@m31frqC
		,@a8Clcd
		,@a8Cncd
		,@m31rtC
		,@a7intp1C
		,@a7intp1D

		while @@Fetch_Status = 0

		 begin

		set @safeP4 	= 0

		 if @a8Dpl is null 
		 begin
 			set @a8Dpl 	= 0
			set @m31amtDi1	= 0
			set @a8Damti2	= 0
			set @a8Damti3	= 0
			set @m31amtDp4	= 0
			set @m31amtDtot = 0
			set @m31rateD   = 0
			set @m31frqD    = ' '
			set @m31rtD	= ' '
			set @a8Dlcd     = 0
			set @a8Dncd     = 0
	
			set @a8Cpl	= 0
			set @m31amtCi1	= 0
			set @a8Camti2	= 0
			set @a8Camti3	= 0
			set @m31amtCp4	= 0
			set @m31amtCtot = 0
			set @m31rateC   = 0
			set @m31frqC    = ' '
			set @m31rtC	= ' '
			set @a8Clcd     = 0
			set @a8Cncd     = 0
		 end


		set @m31amtDy2d = 0
		set @m31blcgDi  = ' '
		set @m31blcgDir = ' '

		set @m31amtCy2d = 0
		set @m31blcgCi  = ' '
		set @m31blcgCir = ' '

		set @a7intp1    = 0 

			if @a8Dpl <> 0 or @m31amtDi1 <> 0 or @m31amtDp4 <> 0
			begin
				select @u1code 	  = u1code  from CCYS where u1ccy = @m31ccy
				select @m31blcgDi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @a8Dpl and a1sfx = @u1code
	
				select @a7intp1   = sum(a7intp1) 
				from AINP 
				join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
				where a8brn = @brn and a8acc = @m31acc and a8sfx = @m31sfx and a7cycd >= @janfirst and a7dc = 'D'
			
		-----------
				select @safeP4  = a3Dibf
				from ABFW 
				where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
		
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
		
				if @safeP4 = 0 or @safeP4 = null
				begin
					select @safeP4  = a3Ditp
					from ABFW 
					where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
				end
		
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
		------------

				if @a7intp1 is null
				begin
					set @a7intp1  = 0
				end	

				if @scn not in ('N', 'W')
				begin
					set @m31amtDi1 = @a8Damti3
				end
--				set @m31amtDy2d =  @m31amtDi1 + @a7intp1 - @m31amtDp4
				set @m31amtDy2d =  @m31amtDi1 + @a7intp1 - @safeP4

				set @pl = '99' + substring(cast(@a8Dpl as char(6)),3,4)

				select @m31blcgDir = a1blcg from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code

			end
	
			if @a8Cpl <> 0 or @m31amtCi1 <> 0 or @m31amtCp4 <> 0
			begin
				select @u1code 	  = u1code from CCYS where u1ccy = @m31ccy
				select @m31blcgCi = a1blcg from ACCT where a1brn = @brn and a1acc = @a8Cpl and a1sfx = @u1code
	
				select @a7intp1   = sum(a7intp1) 
				from AINP 
				join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
				where a8brn = @brn and a8acc = @m31acc and a8sfx = @m31sfx and a7cycd >= @janfirst  and a7dc = 'C'

		-----------
				select @safeP4  = a3Cibf
				from ABFW 
				where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
		
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
		
				if @safeP4 = 0 or @safeP4 = null
				begin
					select @safeP4  = a3Citp
					from ABFW 
					where a3brn = @brn and a3acc = @m31acc and a3sfx = @m31sfx and a3bfd = @janfirst 
				end
		
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
		------------

				if @a7intp1 is null
				begin
					set @a7intp1  = 0
				end	
	
				if @scn not in ('N', 'W')
				begin
					set @m31amtCi1 = @a8Camti3
				end
--				set @m31amtCy2d =  @m31amtCi1 + @a7intp1 - @m31amtCp4
				set @m31amtCy2d =  @m31amtCi1 + @a7intp1 - @safeP4

				set @pl = '99' + substring(cast(@a8Cpl as char(6)),3,4)

				select @m31blcgCir = a1blcg2 from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code

			end

			if @a1atyp = 'YP' 
			begin
				 set @m31amtDi1 = @a1sumadj
			end

			set @m31exr			= 0
			set @m31time 		= ''
			set @m31mprice 		= 0
			set @m31arc 		= ''

			insert into VALY values(@m31brn, @m31acc, @m31sfx, ' ',' ', @m31amt, @m31ccy, @p0date, @p0date, @p0date, @p0date, @m31amtDy2d, @m31amtDi1, isnull(@a8Damti2, 0), @m31amtDp4, @a8Dpl, @m31amtDtot, @m31blcgDi, @m31blcgDir, @m31rtD, @m31rateD, @m31frqD, @m31holdD, @m31amtCy2d, @m31amtCi1, isnull(@a8camti2, 0), @m31amtCp4, @a8Cpl, @m31amtCtot, @m31blcgCi, @m31blcgCir, @m31rtC, @m31rateC, @m31frqC, isnull(@a7intp1C, 0), isnull(@a7intp1d, 0), @m31blcg, 0, ' ', 0, 0,' ',' ',1,@m31exr,@m31time,@m31mprice,@m31arc, 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 'N', ' ', ' ', isnull(@a8dlcd, 0), isnull(@a8dncd, 0), isnull(@a8clcd, 0), isnull(@a8cncd, 0), ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

			execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx

		
			fetch Next from csr_VALY_build_ACCT2 Into
			 @m31brn
			,@m31acc
			,@m31sfx
			,@m31amt
			,@a1sumadj

			,@m31ccy
			,@a1atyp
			,@m31blcg

			,@a8Dpl	
			,@m31amtDi1
			,@a8Damti2
			,@a8Damti3
			,@m31amtDp4
			,@m31amtDtot
			,@m31rateD
			,@m31frqD
			,@a8Dlcd
			,@a8Dncd
			,@m31rtD

			,@a8Cpl
			,@m31amtCi1
			,@a8Camti2
			,@a8Camti3
			,@m31amtCp4
			,@m31amtCtot
			,@m31rateC
			,@m31frqC	
			,@a8Clcd
			,@a8Cncd
			,@m31rtC
			,@a7intp1C
			,@a7intp1D

		end

		close csr_VALY_build_ACCT2

		deallocate csr_VALY_build_ACCT2

		COMMIT TRANSACTION

---------------------------------------------------------------------------------------

--step 3: DLFX (Fx deals)


	DECLARE csr_VALY_build_DLFX cursor for
	select
	 d9brn
	,d9typ
	,d9ref
	,d9Pamt
	,d9Samt
	,d9Pccy
	,d9Sccy
	,d9Psfx
	,d9Ssfx
	,d9opd
	,d1acc
	,d9pl
	,d9plamt
	,d9plamt2
	,d1arc
	,d1mnt
	,d1tbrn	
	,d1stl	
	,d1psd
	,d1ctd
	,d9exr
	,d29time
	,d29mprice
	,d4amt2
	,d4mtd2
	,d7intp1
	,d8amti2	
	,d8ar		
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app
	from DLFX
	join DEAL on d1brn = d9brn and d1typ = d9typ and d1ref = d9ref
	left join DTRD on d29brn = d9brn and d29typ = d9typ and d29ref = d9ref
	left join DLTR on d4brn = d9brn and d4typ = d9typ and d4ref = d9ref
	left join isvw_HR05_d7intp1 on d1brn = d7brn and d1typ = d7typ  and d1ref = d7ref
	left join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref and d8seq=0
	left join DCLO on d1brn = d14brn  and d1typ = d14typ  and d1ref = d14ref
	left join DTYP on d1typ = d2typ
	where d1brn = @brn
	and   d1mnt in ( 3 , 4 )
	and   d1sts not in ('V' , 'C' ) 
	and   (d1arc = '' or (d1arc = 'A' and d9opd >= @p2year))

	open csr_VALY_build_DLFX

	fetch Next from csr_VALY_build_DLFX Into
	 @m31brn
	,@m31typ
	,@m31ref
	,@d9Pamt
	,@d9Samt
	,@d9Pccy
	,@d9Sccy
	,@d9Psfx
	,@d9Ssfx
	,@m31std
	,@m31acc

	,@d9pl
	,@m31amtDi1
	,@m31amtDp4
	,@m31arc
	,@d1mnt	
	,@d1tbrn	
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@m31exr
	,@m31time
	,@m31mprice
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app
	
	while @@Fetch_Status = 0

	begin

		if @m31typ = 'IWF' 
		begin
			set @d9ref = substring(@m31ref,1,4) + 'SWS' + substring(@m31ref,8,6)
			select @d9opd = d9opd from DLFX where d9brn = @m31brn and d9typ = 'SWS' and d9ref = @d9ref		
		end

		if not (@m31typ = 'IWF' and @d9opd > @p0date)
		begin
			set @m31sfx  = @d9Psfx			
			select @a1blcg  = a1blcg,@a1blcg2  = a1blcg2,@a2str2 = a2str2  from ACCT join ATYP on a1atyp = a2mne
						where a1brn = @brn and a1acc = @m31acc and a1sfx = @m31sfx
			if @a2str2 = 'U'
			begin
				set @m31amt  = @d9Pamt 
				set @a1blcg  = @a1blcg2 
			end
			if @a2str2 <> 'U'
			begin
				set @m31amt  = @d9Pamt * -1 
			end
			set @m31ccy  = @d9Pccy
			set @m31blcg = @a1blcg
	
			set @a8Dpl = @d9pl  + 993000
			select @m31blcgDi = a1blcg  from ACCT where a1brn = @brn and a1acc = @a8Dpl 
			set @a8Cpl = @d9pl  + 994000
			select @m31blcgCi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @a8Cpl
			--
			set @pl = @d9pl  + 993040
			select @m31blcgDir = a1blcg2  from ACCT where a1brn = @brn and a1acc = @pl 
			set @pl = @d9pl  + 994040
			select @m31blcgCir = a1blcg   from ACCT where a1brn = @brn and a1acc = @pl
	
			set @m31abmflg = 1
			if @m31arc = 'A' or @d1mnt = 4  
			begin
				set @m31abmflg = 0
			end

                        if @m31time is null
			begin
				set @m31time = ''
			end

			if @m31mprice is null
			begin
				set @m31mprice = 0
			end

			insert into VALY values(@m31brn, @m31acc, @m31sfx, @m31typ, @m31ref, @m31amt, @m31ccy, @m31std, @m31std, @m31std, @m31std, @m31amtDy2d, @m31amtDi1, 0, @m31amtDp4,  @a8Dpl, 0, @m31blcgDi, @m31blcgDir, ' ', 0, ' ', 0, 0, 0, 0, 0, @a8Cpl, 0, @m31blcgCi, @m31blcgCir, ' ', 0, ' ', 0, 0, @m31blcg, 0, ' ', 0, 0,' ',' ',@m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0), isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

			execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx
	
			set @m31sfx  = @d9Ssfx
			select @a1blcg2 = a1blcg2 from ACCT where a1brn = @brn and a1acc = @m31acc and a1sfx = @m31sfx
			set @m31amt  = @d9Samt
			set @m31ccy  = @d9Sccy
			set @m31blcg = @a1blcg2

			insert into VALY values(@m31brn, @m31acc, @m31sfx, @m31typ, @m31ref, @m31amt, @m31ccy, @m31std, @m31std, @m31std, @m31std, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @m31blcg, 0, ' ', 0, 0,' ',' ',@m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0), isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

			execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx
		end

		fetch Next from csr_VALY_build_DLFX Into
		 @m31brn
		,@m31typ
		,@m31ref
		,@d9Pamt
		,@d9Samt
		,@d9Pccy
		,@d9Sccy
		,@d9Psfx
		,@d9Ssfx
		,@m31std
		,@m31acc

		,@d9pl
		,@m31amtDi1
		,@m31amtDp4

		,@m31arc	
		,@d1mnt
		,@d1tbrn	
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@m31exr
		,@m31time
		,@m31mprice
		,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2 
		,@d8ar
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
		
	end

	close csr_VALY_build_DLFX

	deallocate csr_VALY_build_DLFX



---------------------------------------------------------------------------------------

--step 4: DLTR (Term deals)


	DECLARE csr_VALY_build_DLTR cursor for 	
	select
	 d1brn
	,d1acc
	,d1sfx
	,d1ccy
	,d1blcg
	,d1typ
	,d1ref
	,d1code
	,d1codel
	,d1codex
	,a2cat
	,d4amt
	,d1arc
	,d1tbrn	
	,d1stl	
	,d1psd
	,d1ctd
	,d4std
	,d4mtd
	,d8lcd
	,d8ncd
	,d8dacc
	,d8dsfx
	,d8iacc
	,d8isfx
	,d8amti1
	,d8amti3
	,d8amtp4
	,d8pl
	,d2typ0
	,d8ichr
	,d8tot
	,d8aprr
	,d8ifrq
	,case d14bas
		when '1'     then 'LS'
		when '2'     then 'EX'
		when '3'     then 'SB'
		when '4'     then 'ZZ'
		when '5'     then 'SB'
		when '6'     then 'ES'
		when '7'     then 'YD'
		when '8'     then 'SD'
		else	          'SB'	
	 end
	,d29time
	,d29mprice
	,d4amt2
	,d4mtd2
	,d8amti2	
	,d8ar		
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app
	,d14cat
	,ISNULL(d14restructured,0)
	,ISNULL(d14cstage,0)
	from      DEAL
	     join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
	     join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref  and d8seq = 0 
	left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref  
	     join DTYP on d1typ = d2typ
	     join ATYP on a2mne = d2datyp
	left join DTRD on d29brn = d1brn and d29typ = d1typ and d29ref = d1ref
	where d1brn  = @brn
	and   d1mnt  = 4 
	and   d1sts not in ('V','C')
	and   d2typ0 in ('D','L')
	and   (d1arc = '' or (d1arc = 'A' and d4mtd >= @p2year))

	open csr_VALY_build_DLTR

	fetch Next from csr_VALY_build_DLTR Into
	 @m31brn
	,@m31acc
	,@m31sfx
	,@m31ccy
	,@m31blcg
	,@m31typ
	,@m31ref
	,@m31code
	,@m31codel
	,@m31codex
	,@a2cat
	,@m31amt
	,@m31arc
	,@d1tbrn	
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@m31std
	,@m31mtd
	,@m31lcd
	,@m31ncd
	,@d8dacc
	,@d8dsfx
	,@d8iacc
	,@d8isfx
	,@d8amti1
	,@d8amti3
	,@d8amtp4
	,@d8pl
	,@d2typ0
	,@d8ichr
	,@d8tot
	,@m31rateD
	,@m31frqD
	,@m31rtD
	,@m31time
	,@m31mprice
	,@d4amt2
	,@d4mtd2
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app
	,@d14cat
	,@m31restructured
	,@m31cstage

	while @@Fetch_Status = 0

	begin

		set @m31limitAmt= 0
		set @m31limitccy= ' '
		set @m31limittype= ' '
		set @m31abmflg= 1
		if @m31arc='A' and @m31mtd < @pyear
		begin
			set @m31abmflg= 0
		end
		if @m31arc='A' and @m31mtd <= @p0date
		begin
			set @m31amt= 0
		end

		
		if @m31code is not null and @m31code <>0
		begin
			select
			 @m31limitAmt	= l6amt
			,@m31limitccy	= l0ccy
			,@m31limittype  = 'C'
			from LATR
			join LANA on l6brn = l0brn and l6acc = l0acc
			where l6cat = @a2cat and l6brn = @m31brn and l6acc = @m31acc and l6code = @m31code and l6codel = @m31codel and l6codex = @m31codex
			
			if @m31limitAmt = 0
			begin 
				select 
				 @m31limitAmt	= isnull(l6amt, 0) 
				,@m31limitccy	= l0ccy
				,@m31limittype  = 'G'
				from LATR 
				right join CSTM on l6grp = c1grp and l6brn = @m31brn and l6code = @m31code and l6codel = @m31codel and l6codex = @m31codex 
				join LANA on l6brn = l0brn and l6acc = l0acc
				where c1acc = @m31acc and c1brn = @brn
			end
		end

		set @safeP4 = 0

		if @m31lcd > @p0date and @d2typ0 <> 'L'
		begin

			set @d7cycd = 0
			select @d7cycd  = max(d7cycd) from DINP 
			where d7brn = @m31brn and d7typ = @m31typ and d7ref = @m31ref and d7seq = 0 and d7cycd < @m31lcd

			if @d7cycd is null or @d7cycd < @janfirst
			begin
				select @d8amtp4 =  d3itp from DBFW 
				where d3brn = @m31brn and d3typ = @m31typ and d3ref = @m31ref and d3seq = 0 and d3bfd = @janfirst
			end

			if @scn not in ('N','W')
			begin
				select @d8amti3 =  d3itp from DBFW 
				where d3brn = @m31brn and d3typ = @m31typ and d3ref = @m31ref and d3seq = 0 and d3bfd = @pldate
			end 
			else
			begin
				select @d8amti1   = sum(d7intp1) 
				from DINP 
				join DINT on d7brn = d8brn and d7typ = d8typ and d7ref = d8ref and d7seq = d8seq
				where d8brn = @brn and d8typ = @m31typ and d8ref = @m31ref and d7cycd = @m31lcd
			end
		
		end

		if @m31lcd = 0 
		begin
			set @m31lcd = @m31std
		end

		if @m31ncd = 99999999 
		begin
			set @m31ncd = @m31mtd
		end

		select @u1code 	  = u1code from CCYS where u1ccy = @m31ccy

		select @d7intp1   = sum(d7intp1) 
		from DINP 
		join DINT on d7brn = d8brn and d7typ = d8typ and d7ref = d8ref and d7seq = d8seq
		where d8brn = @brn and d8typ = @m31typ and d8ref = @m31ref and d7cycd >= @janfirst and d7cycd <= @p0date  

		select @safeP4  = d3ibf
		from DBFW 
		where d3brn = @brn and d3typ = @m31typ and d3ref = @m31ref and d3bfd = @janfirst 

		if @safeP4 is null
		begin
			set @safeP4  = 0
		end

		if @safeP4 = 0 or @safeP4 = null
		begin
			select @safeP4  = d3itp
			from DBFW 
			where d3brn = @brn and d3typ = @m31typ and d3ref = @m31ref and d3bfd = @janfirst 
		end

		if @d7intp1 is null
		begin
			set @d7intp1  = 0
		end

		if @safeP4 is null
		begin
			set @safeP4  = 0
		end

		if @scn not in ('N', 'W')
		begin
			set @d8amti1 = @d8amti3
		end

		if @d2typ0  = 'L'
		begin
		
			set @m31amtDp4    =  @d8amtp4
			select @m31blcgDi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @d8pl and a1sfx = @u1code

			set @pl = '99' + substring(cast(@d8pl as char(6)),3,4)
			if @d8ichr = 'D'
			begin
				set @m31amtDy2d    =  @d8amti1 - @d8amtp4

				set @m31amtDi1  = @d8amti1
					
				select @m31blcgDir = a1blcg2 from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code
			end
			else
			begin

--				set @m31amtDy2d    =  @d8amti1 + @d7intp1 - @d8amtp4
				set @m31amtDy2d    =  @d8amti1 + @d7intp1 - @safeP4
				set @m31amtDi1     =  @d8amti1 
				select @m31blcgDir = a1blcg  from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code
			end

			set @m31amtCy2d = 0 
			set @m31amtCi1  = 0 
			set @m31amtCp4  = 0 
			set @m31blcgCi  = ' '  
			set @m31blcgCir = ' '
			set @a8Dpl      = @d8pl
			set @a8Cpl      = 0
			set @m31amtDtot = @d8tot
			set @m31amtCtot = 0

			set @m31rateD   = @m31rateD
			set @m31frqD    = @m31frqD
			set @m31rtD     = @m31rtD

			set @m31rateC   = 0
			set @m31frqC    = 0
			set @m31rtC     = 0

		end
		else
		begin
--			set @m31amtCy2d   =  @d8amti1 + @d7intp1 - @d8amtp4
 			set @m31amtCy2d   =  @d8amti1 + @d7intp1 - @safep4
			set @m31amtCi1    =  @d8amti1 
			set @m31amtCp4    =  @d8amtp4
			select @m31blcgCi = a1blcg   from ACCT where a1brn = @brn and a1acc = @d8pl and a1sfx = @u1code
			set @pl = '99' + substring(cast(@d8pl as char(6)),3,4)
			
			if @d8ichr = 'D'
			begin
				set @m31amtCy2d    =  @d8amti1 - @d8amtp4
				
				set @m31amtCi1 = @d8amti1

				select @m31blcgCir = a1blcg from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code
			end
			else
			begin
--				set @m31amtCy2d    =  @d8amti1 + @d7intp1 - @d8amtp4
				set @m31amtCy2d    =  @d8amti1 + @d7intp1 - @safep4
				set @m31amtCi1     =  @d8amti1 
				select @m31blcgCir = a1blcg2  from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code
			end

			set @m31amtDy2d = 0 
			set @m31amtDi1  = 0 
			set @m31amtDp4  = 0 
			set @m31blcgDi  = ' '  
			set @m31blcgDir = ' '
			set @a8Cpl      = @d8pl
			set @a8Dpl      = 0
			set @m31amtCtot = @d8tot
			set @m31amtDtot = 0

			set @m31rateC   = @m31rateD
			set @m31frqC    = @m31frqD
			set @m31rtC     = @m31rtD

			set @m31rateD   = 0

			set @m31frqD    = 0
			set @m31rtD     = 0

		end

		set @m8amtR = 0

		if ((@flag5 = ' ' and @m31arc = ' ') or @flag5 = 'E' )
		begin
			if @flag5 = ' ' 
			begin
				
				select @m8amtR = sum(m8amtR) - sum(m8amtP) 
				from DEAL
				join MVMT on d1brn = m8brn and d1typ = m8dtyp and d1ref = m8dref
				where d1brn  = @brn
				and   d1typ  = @m31typ
				and   d1ref  = @m31ref
				and   d1arc  = ' '  
				and   m8mvt  = 'P' 
				and   m8mvt2 = 'O' 
				and   m8pst  = 'N'
				and   m8sts  = ' '
				and   m8psd <= @p0date

				if @m8amtR is null 
				begin	
					set @m8amtR = 0
				end				

			end
			else
			begin
				if @m31lcd = @nbd 

				begin
					if @d8iacc = @d8dacc and  @d8isfx = @d8dsfx
					begin
			 	       		select
						 @d7net = d7intp1 - d7tax1
						from DINT
						JOIN DINP on d8brn = d7brn and d8typ = d7typ and d8ref = d7ref and d8seq = d7seq and d8lcd = d7cycd
						where d8brn  = @brn
						and   d8typ  = @m31typ
						and   d8ref  = @m31ref
					
						if @d7net is not null 

						begin
							set @m31amt = @m31amt - @d7net
						end

					end

					if @d7cycd is null
					begin
						set @d7cycd = 0
					end

					set @m31mtd = @m31lcd 
					set @m31ncd = @m31lcd 
					set @m31lcd = @d7cycd
					set @d8amti2 = @m31amtCi1
					--set @m31amtCy2d = @m31amtCy2d - @m31amtCi1 OFSAA raporlar�nda negatif faiz olarak raporlanmas�na neden oldugu icin Vall_Build �rnek al�narak kapatildi
					set @m31amtCtot = @m31amtCtot - @m31amtCi1

					if @m31lcd = 0 
					begin
						set @m31lcd = @m31std
					end

					set @m31arc = ''

				end
	
			end
			
		end

		set @m31amt = @m31amt - @m8amtR

		set @m31exr	= 0

                if @m31time is null
		begin
			set @m31time = ''
		end

		if @m31mprice is null
		begin
			set @m31mprice = 0
		end


		insert into VALY values(@m31brn, @m31acc, @m31sfx, @m31typ, @m31ref, @m31amt, @m31ccy, @m31std, @m31lcd, @m31ncd, @m31mtd, @m31amtDy2d, @m31amtDi1, 0, @m31amtDp4, @a8Dpl, @m31amtDtot, @m31blcgDi, @m31blcgDir, @m31rtD, @m31rateD, @m31frqD, @m31holdD, @m31amtCy2d, @m31amtCi1, 0, @m31amtCp4, @a8Cpl, @m31amtCtot, @m31blcgCi, @m31blcgCir, @m31rtC, @m31rateC, @m31frqC, 0, 0, @m31blcg, @m31code, @m31codel, @m31codex, @m31limitAmt, @m31limitccy, @m31limittype, @m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', isnull(@d14cat, '  '),	@m31restructured ,@m31cstage,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		if @@ERROR <> 0 
		begin
			print @m31ref + @m31typ
		end
		
		execute issp_ACCT_mark @brn, @m31acc, @m31sfx

		fetch Next from csr_VALY_build_DLTR Into
		 @m31brn
		,@m31acc
		,@m31sfx
		,@m31ccy
		,@m31blcg
		,@m31typ
		,@m31ref
		,@m31code
		,@m31codel
		,@m31codex
		,@a2cat
		,@m31amt
		,@m31arc
		,@d1tbrn	
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@m31std
		,@m31mtd
		,@m31lcd
		,@m31ncd
		,@d8dacc
		,@d8dsfx
		,@d8iacc
		,@d8isfx
		,@d8amti1
		,@d8amti3
		,@d8amtp4
		,@d8pl
		,@d2typ0
		,@d8ichr
		,@d8tot
		,@m31rateD
		,@m31frqD
		,@m31rtD
		,@m31time
		,@m31mprice
		,@d4amt2
		,@d4mtd2
		,@d8amti2	
		,@d8ar		
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
		,@d14cat
		,@m31restructured
		,@m31cstage
	end

	close csr_VALY_build_DLTR

	deallocate csr_VALY_build_DLTR



---------------------------------------------------------------------------------------

--step 5: DTAF (T&F deals)


	DECLARE csr_VALY_build_DTAF cursor for 	
	select
	 d1brn
	,d1acc
	,d1sfx
	,d1ccy
	,d1typ
	,d1ref
	,d1code
	,d1codel
	,d1codex
	,d1tbrn
	,d1stl	
	,d1psd
	,d1ctd
	,a2cat
	,d11amt
	,d11ccont
	,d11blcgD
	,d11blcgC
	,u1code
	,d11std
	,d11mtd
	,d11tmd
	,d11lmd
	,d1arc
	,d4amt2
	,d4mtd2
	,d7intp1
	,d8amti2	
	,d8ar		
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app
	,d11cstage
	from DTAF
	join DEAL on d1brn = d11brn and d1typ = d11typ and d1ref = d11ref
	join CCYS on d1ccy = u1ccy
	join DTYP on d1typ = d2typ
	join ATYP on a2mne = d2datyp
	left join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
	left join isvw_HR05_d7intp1 on d1brn = d7brn and d1typ = d7typ  and d1ref = d7ref
	left join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref and d8seq=0
	left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref 
	where d1brn  = @brn
	and   d1mnt  = 3
	and   d1sts not in ('V','C')
	and   (d1arc  = ' ' Or (d1arc = 'A' and (d11mtd >= @p2year or d11tmd >= @p2year)) OR (d1arc = 'A' and d11mtd = 0 and d11tmd = 0 and d11lmd >= @p2year))

	open csr_VALY_build_DTAF

	fetch Next from csr_VALY_build_DTAF Into
	 @m31brn
	,@m31acc
	,@m31sfx
	,@m31ccy
	,@m31typ
	,@m31ref
	,@m31code
	,@m31codel
	,@m31codex
	,@d1tbrn
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@a2cat
	,@m31amt
	,@d11ccont
	,@d11blcgD
	,@d11blcgC
	,@u1code
	,@m31std
	,@d11mtd
	,@d11tmd
	,@d11lmd
	,@m31arc
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app
	,@m31cstage
	while @@Fetch_Status = 0

	begin
		set @m31abmflg= 0
		if (@m31arc  = ' ' Or (@m31arc = 'A' and (@d11mtd >= @pyear or @d11tmd >= @pyear)) OR (@m31arc = 'A' and @d11mtd = 0 and @d11tmd = 0 and @d11lmd >= @pyear))
		begin
		set @m31abmflg= 1
		end


		set @m31limitAmt= 0
		set @m31limitccy= ' '
		set @m31limittype= ' '

		if @m31code is not null and @m31code <>0
		begin
			select
			 @m31limitAmt	= l6amt
			,@m31limitccy	= l0ccy
			,@m31limittype  = 'C'
			from LATR 
			join LANA on l6brn = l0brn and l6acc = l0acc
			where l6cat = @a2cat and l6brn = @m31brn and l6acc = @m31acc and l6code = @m31code and l6codel = @m31codel and l6codex = @m31codex
			
			if @m31limitAmt = 0
			begin
				select 
				 @m31limitamt	= isnull(l6amt, 0) 
				,@m31limitccy	= l0ccy
				,@m31limittype  = 'G'
				from LATR 
				right join CSTM on l6grp = c1grp and l6brn = @m31brn and l6code = @m31code and l6codel = @m31codel and l6codex = @m31codex 
				join LANA on l6brn = l0brn and l6acc = l0acc
				where c1acc = @m31acc and c1brn = @brn
			end
		end

		if @d11mtd <> 0 and @d11mtd >= @d11tmd
		begin
			set @m31mtd = @d11mtd
		end

		if @d11tmd <> 0 and @d11tmd > @d11mtd
		begin
			set @m31mtd = @d11tmd
		end
		
		if @d11mtd = 0 and @d11tmd = 0
		begin
			set @m31mtd = 0
		end
 		
		set @m31exr	= 0
		set @m31time 	= ''
		set @m31mprice 	= 0
		
		insert into VALY values(@m31brn, @m31acc,   @m31sfx, @m31typ, @m31ref, -@m31amt, @m31ccy, @m31std, @m31std, @m31mtd, @m31mtd, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgD, @m31code, @m31codel, @m31codex, @m31limitAmt,@m31limitccy,@m31limittype,@m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,@m31cstage,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx

		insert into VALY values(@m31brn, @d11ccont, @u1code, @m31typ, @m31ref, @m31amt, @m31ccy, @m31std, @m31std, @m31mtd, @m31mtd, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgC, 0, ' ', 0, 0,' ',' ',@m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0), isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		execute issp_ACCT_mark @m31brn, @d11ccont, @u1code

		fetch Next from csr_VALY_build_DTAF Into
		 @m31brn
		,@m31acc
		,@m31sfx
		,@m31ccy
		,@m31typ
		,@m31ref
		,@m31code
		,@m31codel
		,@m31codex
		,@d1tbrn
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@a2cat
		,@m31amt
		,@d11ccont
		,@d11blcgD
		,@d11blcgC
		,@u1code
		,@m31std
		,@d11mtd
		,@d11tmd
		,@d11lmd
        ,@m31arc
        ,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2
		,@d8ar
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
		,@m31cstage
	end

	close csr_VALY_build_DTAF

	deallocate csr_VALY_build_DTAF



---------------------------------------------------------------------------------------

--step 6: VDOC (Valuable Documents)

	DECLARE csr_VALY_build_VDOC cursor for 	
	select
	 d18brn
	,d18typ
	,d18ref
	,d18iaD
	,d18iaC
	,sum(d18amt)
	,d18ccy
	,d18blcgD
	,d18blcgC
	,u1code
	,d1tbrn
	,d1stl	
	,d1psd
	,d1ctd
	,d4amt2
	,d4mtd2
	,d7intp1
	,d8amti2
	,d8ar
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app
	from VDOC
	left join DEAL on d18brn = d1brn and d18typ = d1typ and d18ref = d1ref
	left join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
	join CCYS on d18ccy = u1ccy
	left join isvw_HR05_d7intp1 on d1brn = d7brn and d1typ = d7typ  and d1ref = d7ref
	left join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref and d8seq=0
	left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref 
	left join DTYP on d1typ = d2typ
	where d18brn  = @brn
	and   d18sts  = ' '
	group by d18brn, d18typ, d18ref, d18iaD, d18iaC, d18ccy, d18blcgD,d18blcgC,u1code,d1tbrn,d1stl,d1psd,d1ctd,d4amt2,d4mtd2,d7intp1,d8amti2,d8ar,d8ar2,d14equpay,d14frqP,d2app


	open csr_VALY_build_VDOC

	fetch Next from csr_VALY_build_VDOC Into
	 @m31brn
	,@m31typ
	,@m31ref
	,@m31acc
	,@d11ccont
	,@m31amt
	,@m31ccy
	,@d11blcgD
	,@d11blcgC
	,@u1code
	,@d1tbrn
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app
	while @@Fetch_Status = 0

	begin
	

		set @m31exr	= 0
		set @m31time 	= ''
		set @m31mprice 	= 0
		set @m31arc 	= ''

		insert into VALY values(@m31brn, @m31acc,   @u1code, @m31typ, @m31ref, -@m31amt, @m31ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgD, 0, ' ', 0, 0,' ',' ',1,@m31exr,@m31time,@m31mprice,@m31arc,isnull(@d1tbrn, 0),isnull(@d1stl, ' '),isnull(@d1psd, 0),isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0),isnull(@d8ar, 0),isnull(@d8ar2, 0),isnull(@d14equpay, 'N'),isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		execute issp_ACCT_mark @m31brn, @m31acc, @u1code

		insert into VALY values(@m31brn, @d11ccont, @u1code, @m31typ, @m31ref,  @m31amt, @m31ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgC, 0, ' ', 0, 0,' ',' ',1,@m31exr,@m31time,@m31mprice,@m31arc,isnull(@d1tbrn, 0),isnull(@d1stl, ' '),isnull(@d1psd, 0),isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0),isnull(@d8ar, 0),isnull(@d8ar2, 0),isnull(@d14equpay, 'N'),isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		execute issp_ACCT_mark @m31brn, @d11ccont, @u1code

		fetch Next from csr_VALY_build_VDOC Into
		 @m31brn
		,@m31typ
		,@m31ref
		,@m31acc
		,@d11ccont
		,@m31amt
		,@m31ccy
		,@d11blcgD
		,@d11blcgC
		,@u1code
		,@d1tbrn
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2	
		,@d8ar		
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
        	
	end

	close csr_VALY_build_VDOC

	deallocate csr_VALY_build_VDOC



--step 7: COMT (comitments)


	DECLARE csr_VALY_build_COMT cursor for 	
	select
	 d1brn
	,d1acc
	,d1sfx
	,d1ccy
	,d1blcg
	,d1typ
	,d1ref
	,d1code
	,d1codel
	,d1codex
	,d16amt
	,d1arc
	,d1tbrn
	,d1stl	
	,d1psd
	,d1ctd
	,d4amt2
	,d4mtd2
	,d7intp1
	,d8amti2	
	,d8ar		
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app
	from DEAL
	join COMT on d1brn = d16brn and d1typ = d16typ and d1ref = d16ref
	left join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
	join DTYP on d1typ = d2typ
	left join isvw_HR05_d7intp1 on d1brn = d7brn and d1typ = d7typ  and d1ref = d7ref
	left join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref and d8seq=0
	left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref
	where d1brn  = @brn
	and   d1mnt  = 4
	and   d1sts not in ('V','C')
	and   (d1arc = '' or (d1arc = 'A' and d1psd >= @p2year))


	open csr_VALY_build_COMT

	fetch Next from csr_VALY_build_COMT Into
	 @m31brn
	,@m31acc
	,@m31sfx
	,@m31ccy
	,@m31blcg
	,@m31typ
	,@m31ref
	,@m31code
	,@m31codel
	,@m31codex
	,@m31amt
	,@m31arc
	,@d1tbrn
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app

	while @@Fetch_Status = 0

	begin
	set @m31abmflg= 1
	
	if @m31arc = 'A' 
	begin
		set @m31abmflg= 0
	end

		set @m31exr	= 0
		set @m31time 	= ''
		set @m31mprice 	= 0

		insert into VALY values(@m31brn, @m31acc, @m31sfx, @m31typ, @m31ref, -@m31amt, @m31ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @m31blcg, 0, ' ', 0, 0,' ',' ',@m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc,isnull(@d1tbrn, 0),isnull(@d1stl, ' '),isnull(@d1psd, 0),isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0),isnull(@d14equpay, 'N'),isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx

		fetch Next from csr_VALY_build_COMT Into
		 @m31brn
		,@m31acc
		,@m31sfx
		,@m31ccy
		,@m31blcg
		,@m31typ
		,@m31ref
		,@m31code
		,@m31codel
		,@m31codex
		,@m31amt
		,@m31arc
		,@d1tbrn
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2	
		,@d8ar		
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
	end

	close csr_VALY_build_COMT

	deallocate csr_VALY_build_COMT


---------------------------------------------------------------------------------------

--step 8: CMCP (Commercial Papers)
	DECLARE csr_VALY_build_CMCP cursor for 	
	select
	 d21brn
	,d21typ
	,d21ref
	,d21accD
	,d21accC
	,sum(d21Cqua * d21iprc) - sum(d21post)
	,d21ccy
	,d21blcgD
	,d21blcgC
	,u1code
	,d1tbrn
	,d1stl	
	,d1psd
	,d1ctd
	,d4amt2
	,d4mtd2
	,d7intp1
	,d8amti2	
	,d8ar		
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app
	from CMCP
	left join DEAL on d21brn = d1brn and d21typ = d1typ and d21ref = d1ref
	left join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
	join CCYS on d21ccy = u1ccy
	left join isvw_HR05_d7intp1 on d1brn = d7brn and d1typ = d7typ  and d1ref = d7ref
	left join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref and d8seq=0
	left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref
	left join DTYP on d1typ = d2typ
	where d21brn  = @brn
	 and (d21post <> 0 or d21sts = 'O')
	group by d21brn, d21typ, d21ref, d21accD, d21accC, d21ccy, d21blcgD,d21blcgC, u1code,d1tbrn,d1stl,d1psd,d1ctd,d4amt2,d4mtd2,d7intp1,d8amti2,d8ar,d8ar2,d14equpay,d14frqP,d2app

	open csr_VALY_build_CMCP

	fetch Next from csr_VALY_build_CMCP Into
	 @m31brn
	,@m31typ
	,@m31ref
	,@d11ccont
	,@m31acc
	,@m31amt
	,@m31ccy
	,@d11blcgD
	,@d11blcgC
	,@u1code
	,@d1tbrn
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app

	while @@Fetch_Status = 0

	begin

		if @m31amt <> 0 
		begin

			set @m31exr	= 0
			set @m31time 	= ''
			set @m31mprice 	= 0
			set @m31arc 	= ''

			insert into VALY values(@m31brn, @d11ccont, @u1code, @m31typ, @m31ref, -@m31amt, @m31ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgD, 0, ' ', 0, 0,' ',' ',1,@m31exr,@m31time,@m31mprice,@m31arc,isnull(@d1tbrn, 0),isnull(@d1stl, ' '),isnull(@d1psd, 0),isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0),isnull(@d14equpay, 'N'),isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

			execute issp_ACCT_mark @m31brn, @d11ccont, @u1code

			insert into VALY values(@m31brn, @m31acc,   @u1code, @m31typ, @m31ref,  @m31amt, @m31ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgC, 0, ' ', 0, 0,' ',' ',1,@m31exr,@m31time,@m31mprice,@m31arc,isnull(@d1tbrn, 0),isnull(@d1stl, ' '),isnull(@d1psd, 0),isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0),isnull(@d14equpay, 'N'),isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

			execute issp_ACCT_mark @m31brn, @m31acc, @u1code
		end

		fetch Next from csr_VALY_build_CMCP Into
		 @m31brn
		,@m31typ
		,@m31ref
		,@d11ccont
		,@m31acc
		,@m31amt
		,@m31ccy
		,@d11blcgD
		,@d11blcgC
		,@u1code
		,@d1tbrn
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2	
		,@d8ar		
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app

        	
	end

	close csr_VALY_build_CMCP

	deallocate csr_VALY_build_CMCP

---------------------------------------------------------------------------------------

--step 9: BONC (Securities)

	set @m31amtCy2d  = 0
	set @m31amtCtot  = 0

	DECLARE csr_VALY_build_BONC cursor for 	
	select
	 b2brn
	,b2typ
	,b2ref
	,d1acc
	,d1sfx
	,b2amtP
	,b2ccy
	,b2std
	,b2lcd
	,b2ncd
	,b2mtd
	,b2amti1
	,b2amtp4
	,b2plC
	,b2rateC
	,b2frqC
	,d1blcg
	,u1code
	,d1tbrn
	,d1stl	
	,d1psd
	,d1ctd
	,d4amt2
	,d4mtd2
	,d7intp1
	,d8amti2	
	,d8ar		
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app


	from BONC
	join DEAL on d1brn = b2brn and d1typ = b2typ and d1ref = b2ref
	left join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
	join CCYS on b2ccy = u1ccy
	left join isvw_HR05_d7intp1 on d1brn = d7brn and d1typ = d7typ  and d1ref = d7ref
	left join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref and d8seq=0
	left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref
	left join DTYP on d1typ = d2typ
	where b2brn  = @brn
	 and  d1arc  = ' '

	open csr_VALY_build_BONC

	fetch Next from csr_VALY_build_BONC Into
	 @m31brn
	,@m31typ
	,@m31ref
	,@m31acc
	,@m31sfx
	,@m31amt
	,@m31ccy
	,@m31std
	,@m31lcd
	,@m31ncd
	,@m31mtd
	,@m31amtCi1
	,@m31amtCp4
	,@d8pl
	,@m31rateC
	,@m31frqC
	,@m31blcg
	,@u1code
	,@d1tbrn
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app

	while @@Fetch_Status = 0

	begin

		if @m31amt <> 0 
		begin

			if @m31lcd = 0 
			begin
				set @m31lcd = @m31std
			end
	
			if @m31ncd = 99999999 
			begin
				set @m31ncd = @m31mtd
			end
	
			select @m31blcgCi = a1blcg   from ACCT where a1brn = @brn and a1acc = @d8pl and a1sfx = @u1code
			set @pl = '99' + substring(cast(@d8pl as char(6)),3,4)
			select @m31blcgCir = a1blcg from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code

			set @m31exr	= 0
			set @m31time 	= ''
			set @m31mprice 	= 0
			set @m31arc 	= ''

			insert into VALY values(@m31brn, @m31acc, @m31sfx, @m31typ, @m31ref, -@m31amt, @m31ccy, @m31std, @m31lcd, @m31ncd, @m31mtd, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, @m31amtCy2d, @m31amtCi1, 0, @m31amtCp4, @d8pl, @m31amtCtot, @m31blcgCi, @m31blcgCir, @m31rateC, ' ', @m31frqC, 0, 0, @m31blcg, 0, ' ', 0, 0,' ',' ',1,@m31exr,@m31time,@m31mprice,@m31arc,isnull(@d1tbrn, 0),isnull(@d1stl, ' '),isnull(@d1psd, 0),isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0),isnull(@d14equpay, 'N'),isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

			execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx
		end

		fetch Next from csr_VALY_build_BONC Into
		 @m31brn
		,@m31typ
		,@m31ref
		,@m31acc
		,@m31sfx
		,@m31amt
		,@m31ccy
		,@m31std
		,@m31lcd
		,@m31ncd
		,@m31mtd
		,@m31amtCi1
		,@m31amtCp4
		,@d8pl
		,@m31rateC
		,@m31frqC
		,@m31blcg
		,@u1code
		,@d1tbrn
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2	
		,@d8ar		
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
        	
	end

	close csr_VALY_build_BONC

	deallocate csr_VALY_build_BONC

---------------------------------------------------------------------------------------

--step 10: BNDD (Bond Deals)

	DECLARE csr_VALY_build_BNDD cursor for 	
	select
	 d20brn
	,d20typ
	,d20ref
	,d1acc
	,d1sfx
	,case d20bs when 'B' then   d20Gamt
		    when 'S' then  -d20Gamt	
	 end
	,d1ccy
	,d20vld
	,d20sld
	,d20plamt
	,d20plamt2
	,d1blcg
	,d1tbrn
	,d1stl	
	,d1psd
	,d1ctd
	,d4amt2
	,d4mtd2
	,d7intp1
	,d8amti2	
	,d8ar		
	,d8ar2
	,d14equpay
	,d14frqP
	,d2app

	from BNDD
	join DEAL on d1brn = d20brn and d1typ = d20typ and d1ref = d20ref
	left join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
	left join isvw_HR05_d7intp1 on d1brn = d7brn and d1typ = d7typ  and d1ref = d7ref
	left join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref and d8seq=0
	left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref
	left join DTYP on d1typ = d2typ
	where d20brn = @brn
	 and  d1arc  = ' '
	 and  d1mnt  = 3

	open csr_VALY_build_BNDD

	fetch Next from csr_VALY_build_BNDD Into
	 @m31brn
	,@m31typ
	,@m31ref
	,@m31acc
	,@m31sfx
	,@m31amt
	,@m31ccy
	,@m31std
	,@m31lcd
	,@m31amtCi1
	,@m31amtCp4
	,@m31blcg
	,@d1tbrn
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app
	
	while @@Fetch_Status = 0

	begin

		if @m31amt <> 0 
		begin

			set @m31exr	= 0
			set @m31time 	= ''
			set @m31mprice 	= 0
			set @m31arc 	= ''

			insert into VALY values(@m31brn, @m31acc, @m31sfx, @m31typ, @m31ref, @m31amt, @m31ccy, @m31std, @m31lcd, @m31std, @m31std, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @m31amtCi1, 0, @m31amtCp4, 0, 0, ' ', ' ', 0, ' ', ' ', 0, 0, @m31blcg, 0, ' ', 0, 0,' ',' ',1,@m31exr,@m31time,@m31mprice,@m31arc,isnull(@d1tbrn, 0),isnull(@d1stl, ' '),isnull(@d1psd, 0),isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0),isnull(@d14equpay, 'N'),isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

			execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx
		end

		fetch Next from csr_VALY_build_BNDD Into
		 @m31brn
		,@m31typ
		,@m31ref
		,@m31acc
		,@m31sfx
		,@m31amt
		,@m31ccy
		,@m31std
		,@m31lcd
		,@m31amtCi1
		,@m31amtCp4
		,@m31blcg
		,@d1tbrn
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2	
		,@d8ar		
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
        	
	end

	close csr_VALY_build_BNDD

	deallocate csr_VALY_build_BNDD

--------------------------------------------------------------------------------------------
--step 11: iz hesaplar (account �emas�ndaki hesaplar�n isuba kar��l���)

    delete ydsm.temp_VTRM
	insert into ydsm.temp_VTRM
	select * from ydsm.VTRM

	insert into VALY
	select
	 m30brn
	,m30acc
	,m30sfx
	,m30typ
	,m30ref
	,m30amt
	,m30ccy
	,m30std
	,m30lcd
	,m30ncd
	,m30mtd
	,m30amtDy2d
	,m30amtDi1
	,m30amtDp4
	,0 as m31Damti2
	,m30plD
	,m30amtDtot
	,m30blcgDi
	,m30blcgDir
	,m30rtD
	,m30rateD
	,m30frqD
	,m30holdD
	,m30amtCy2d
	,m30amtCi1
	,0 as m31Camti2
	,m30amtCp4
	,m30plC
	,m30amtCtot
	,m30blcgCi
	,m30blcgCir
	,m30rtC
	,m30rateC
	,m30frqC
	,0 as m31aintp1C
	,0 as m31aintp1D
	,m30blcg
	,m30code
	,m30codeI
	,m30codeX
	,0 as m31limitamt
	,'' as m31limitccy
	,'' as m31limittype
	,case when m30amt=0 and m30mtd<@pyear
		  then 0
		  else 1 
	 end as m31abmflg
	,0 as m31exr
	,''as m31time
	,0 as m31mprice
	,case when m30amt=0 and m30mtd<@p0date
		  then 'A'
		  else '' 
	 end as m31arc
	,0  as m31dtbrn
	,'' as m31stl
	,case when tav.start_date is not null then CAST(convert(varchar,tav.start_date,112) as int) 
		  else @p0date 
		  end as m31psd
	,0 as m31ctd 
	,0 as m31amt2 
	,0 as m31mtd2 
	,0 as m31dintp1 
	,0 as m31amti2
	,ISNULL(tav.announced_rate,0) as m31ar
	,0 as m31ar2
	,'N' as m31equpay
	,''  as m31frqP
	,'DP' as m31app
	, 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0
	,ISNULL(m93brn,0)
	,ISNULL(m93acc,0)
	,ISNULL(m93sfx,0)
	,ISNULL(m93typ,'')
	,ISNULL(m93ref,'')
	,ISNULL(m93amtDy2d,0)
	,ISNULL(m93amtCy2d,0)
	,ISNULL(m93migdate,0)
	from vall
	join acct on a1brn = m30brn 
				  and a1acc = m30acc
				  and a1sfx = m30sfx
	left join deal on d1brn = m30brn
					   and d1acc  = m30acc
					   and d1sfx  = m30sfx
					   and d1typ  = m30typ
					   and d1ref  = m30ref
	left join account.term_account_view tav on tav.reference=m30ref
	left join vmsn on m93brn=m30brn and m93ref=m30ref
	where m30brn = @brn
	and a1atyp = 'DP'
	and tav.is_closed=0 
	
	insert into VALY
	select
	 m30brn
	,m30acc
	,m30sfx
	,m30typ
	,m30ref
	,m30amt
	,m30ccy
	,m30std
	,m30lcd
	,m30ncd
	,m30mtd
	,m30amtDy2d
	,m30amtDi1
	,m30amtDp4
	,0 as m31Damti2
	,m30plD
	,m30amtDtot
	,m30blcgDi
	,m30blcgDir
	,m30rtD
	,m30rateD
	,m30frqD
	,m30holdD
	,m30amtCy2d
	,m30amtCi1
	,0 as m31Camti2
	,m30amtCp4
	,m30plC
	,m30amtCtot
	,m30blcgCi
	,m30blcgCir
	,m30rtC
	,m30rateC
	,m30frqC
	,0 as m31aintp1C
	,0 as m31aintp1D
	,m30blcg
	,m30code
	,m30codeI
	,m30codeX
	,0 as m31limitamt
	,'' as m31limitccy
	,'' as m31limittype
	,case when m30amt=0 and m30mtd<@pyear
		  then 0
		  else 1 
	 end as m31abmflg
	,0 as m31exr
	,''as m31time
	,0 as m31mprice
	,case when m30amt=0 and m30mtd<@p0date
		  then 'A'
		  else '' 
	 end as m31arc
	,0  as m31dtbrn
	,'' as m31stl
	,case when tav.start_date is not null then CAST(convert(varchar,tav.start_date,112) as int) 
		  else @p0date 
		  end as m31psd
	,0 as m31ctd 
	,0 as m31amt2 
	,0 as m31mtd2 
	,0 as m31dintp1 
	,0 as m31amti2
	,ISNULL(tav.announced_rate,0) as m31ar
	,0 as m31ar2
	,'N' as m31equpay
	,''  as m31frqP
	,''  as m31app
	, 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0
	,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate
	from vall
	join acct on a1brn = m30brn 
				  and a1acc = m30acc
				  and a1sfx = m30sfx
	left join deal on d1brn = m30brn
					   and d1acc  = m30acc
					   and d1sfx  = m30sfx
					   and d1typ  = m30typ
					   and d1ref  = m30ref
	left join account.term_account_view tav on tav.reference=m30ref
	where m30brn = @brn
	and ( 
	      ( a1atyp in ( 'YD' , 'YI' , 'YP' ,'YK' ) and m30acc < 800000 )
	     or a1atyp ='SA' 
		)

	-- Rally'de kapanan kapali mevduatlari dahil etmek icin eklendi
	insert into valy
	select
		m30brn
	,m30acc
	,m30sfx
	,m30typ
	,m30ref
	,m30amt
	,m30ccy
	,m30std
	,m30lcd
	,m30ncd
	,m30mtd
	,m30amtDy2d
	,m30amtDi1
	,m30amtDp4
	,0 as m31Damti2
	,m30plD
	,m30amtDtot
	,m30blcgDi
	,m30blcgDir
	,m30rtD
	,m30rateD
	,m30frqD
	,m30holdD
	,m30amtCy2d
	,m30amtCi1
	,0 as m31Camti2
	,m30amtCp4
	,m30plC
	,m30amtCtot
	,m30blcgCi
	,m30blcgCir
	,m30rtC
	,m30rateC
	,m30frqC
	,0 as m31aintp1C
	,0 as m31aintp1D
	,m30blcg
	,m30code
	,m30codeI
	,m30codeX
	,0 as m31limitamt
	,'' as m31limitccy
	,'' as m31limittype
	,case when m30amt=0 and m30mtd<@pyear
			then 0
			else 1 
		end as m31abmflg
	,0 as m31exr
	,''as m31time
	,0 as m31mprice
	,case when m30amt=0 and m30mtd<@p0date
			then 'A'
			else '' 
		end as m31arc
	,0  as m31dtbrn
	,'' as m31stl
	,case when tav.start_date is not null then CAST(convert(varchar,tav.start_date,112) as int) 
			else @p0date 
			end as m31psd
	,0 as m31ctd 
	,0 as m31amt2 
	,0 as m31mtd2 
	,0 as m31dintp1 
	,0 as m31amti2
	,ISNULL(tav.announced_rate,0) as m31ar
	,0 as m31ar2
	,'N' as m31equpay
	,''  as m31frqP
	,'DP' as m31app
	, 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0
	,ISNULL(m93brn,0)
	,ISNULL(m93acc,0)
	,ISNULL(m93sfx,0)
	,ISNULL(m93typ,'')
	,ISNULL(m93ref,'')
	,ISNULL(m93amtDy2d,0)
	,ISNULL(m93amtCy2d,0)
	,ISNULL(m93migdate,0)
	from
	(
			select 
			a1brn																as m30brn
			,a1acc																as m30acc
			,a1sfx																as m30sfx
			,temp_VTRM.product_code													as m30typ
			,RLVZG.m37dref														as m30ref
			,temp_VTRM.balance_amount												as m30amt
			,temp_VTRM.balance_currency												as m30ccy
			, cast(ISNULL(FORMAT(temp_VTRM.open_date, 'yyyyMMdd'),0) as int)        as m30std
			,cast(ISNULL(FORMAT(temp_VTRM.last_cycle_date, 'yyyyMMdd'),0) as int)	as m30lcd
			,cast(ISNULL(FORMAT(temp_VTRM.next_cycle_date, 'yyyyMMdd'),0) as int)	as m30ncd
			,cast(ISNULL(FORMAT(temp_VTRM.close_date, 'yyyyMMdd'),0) as int)		as m30mtd
			,0																	as m30amtDy2d
			,0																	as m30amtDi1
			,0																	as m30amtDp4
			,0																	as m30pld
			,0																	as m30amtDtot
			,''																as m30blcgDi
			,''																as m30blcgDir
			,''																as m30rtD
			,0																	as m30rateD
			,''																as m30frqd
			,0																	as m30holdD
			,ABS(ISNULL(YP.balance_amount,0))									as m30amtCy2d 
			,ISNULL(YI.balance_amount,0)                                       as m30amtci1
			,temp_VTRM.not_posted_previous_years_interest_amount                    as m30amtcp4
			,0																	as m30plc
			,temp_VTRM.total_interest_posted_amount									as m30amtcTot
			,ISNULL(YP.tdhp1,'')												as m30blcgCi
			,ISNULL(YI.tdhp1,'')												as m30blcgCir
			,''																as m30rtc
			,temp_VTRM.resulting_rate												as m30rateC
			,''																as m30frqc
			,temp_VTRM.tdhp1														as m30blcg
			,0      															as m30code
			,0																	as m30codeI
			,0																	as m30codeX
	
			from
		(
		select m37brna,m37acc,m37sfx,m37ccy,m37dref,sum(m37amt) as amount 
		from ydsm.rlvz 
		group by m37brna,m37acc,m37sfx,m37ccy,m37dref
		) RLVZG 
		join temp_VTRM on m37brna = owning_unit_code 
					and m37acc  = customer_number 
					and m37sfx  = account_suffix 
					and m37dref = reference
		left join ydsm.temp_VTRM YI on temp_VTRM.reference=YI.reference and YI.account_type='YI'
		left join ydsm.temp_VTRM YP on temp_VTRM.reference=YP.reference and YP.account_type='YP' and YP.profit_account_nature = 2
		join acct on a1brn = m37brna 
					and a1acc = m37acc 
					and a1sfx = m37sfx
		where a1brn = @brn
			and a1atyp in ('DP')
	) VALL
	join acct on a1brn = m30brn 
				and a1acc = m30acc
				and a1sfx = m30sfx
	left join deal on d1brn = m30brn
					and d1acc  = m30acc
					and d1sfx  = m30sfx
					and d1typ  = m30typ
					and d1ref  = m30ref
	left join account.term_account_view tav on tav.reference = m30ref
	left join vmsn on m93brn = m30brn and m93ref = m30ref
	where m30brn = @brn
		and tav.is_closed=1

---------------------------------------------------------------------------------------

--step 12: Accountcore.letter_of_guarantee
--step 5: DTAF (T&F deals) ile ayni olmasi icin ayni kolon isimleri kullanildi


	DECLARE csr_VALY_build_letter_of_guarantee cursor for 	
		select 
			acct.a1brn as d1brn, 
			acct.a1acc as d1acc, 
			acct.a1sfx as d1sfx,
			acct.a1ccy as d1ccy, 
			letter_of_guarantee.product_type as d1typ, 
			account_contract.reference as d1ref,
			0 as d1code, 
			' ' as d1codel, 
			0 as d1codex,
			letter_of_guarantee.branch_code as d1tbrn,
			'' as d1stl,
			ISNULL(Convert(CHAR(8), letter_of_guarantee.create_date, 112), 0) as d1psd,
			ISNULL(Convert(CHAR(8), letter_of_guarantee.application_date, 112), 0) as d1ctd,
			'' as a2cat,
			letter_of_guarantee.current_amount as d11amt, 
			802000 as d11ccont, 
			letter_of_guarantee.debit_tdhp as d11blcgD, 
			letter_of_guarantee.credit_tdhp as d11blcgC,
			u1code, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.issue_date, 112), 0) as d11std, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.expiry_date, 112), 0) as d11mtd, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.claim_validity_date, 112), 0) as d11tmd, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.last_maintenance_date, 112), 0) as d11lmd, 
			case when letter_of_guarantee.status='ACTIVE' then '' else 'A' end as d1arc, 
			null as d4amt2,
			null as d4mtd2,
			null as d7intp1,
			null as d8amti2,
			null as d8ar,		
			null as d8ar2,
			null as d14equpay,
			null as d14frqP,
			'TF' as d2app,
			'1' as d11cstage
		from noncashloan.letter_of_guarantee
		join accountcore.account on account.number=letter_of_guarantee.number
		join accountcore.customer_account on customer_account.id=account.id
		join accountcore.account_contract on account_contract.id=customer_account.contract
		join accountcore.account_owner on account_owner.account=customer_account.id --and account_owner.is_primary=1
		join accountcore.product on product.product_type = letter_of_guarantee.product_type
		join accountcore.account_type on product.account_type=account_type.id
		join ydsm.acct on acct.a1brn=account.owning_unit_code and acct.a1acc=account_owner.owner_number 
					and acct.a1atyp=account_type.code and acct.a1ccy=account.currency and a1cls='N'
		join ydsm.ccys on ccys.u1ccy=account.currency
		where owning_unit_code=@brn and 
		(
			(letter_of_guarantee.status='ACTIVE' and account.is_closed=0) or 
			(letter_of_guarantee.status<>'ACTIVE' and account.is_closed=1 and 
				(
					ISNULL(Convert(CHAR(8), letter_of_guarantee.expiry_date, 112), 0) >= @p2year or
					ISNULL(Convert(CHAR(8), letter_of_guarantee.claim_validity_date, 112), 0) >= @p2year
				)
			) or
			(letter_of_guarantee.status<>'ACTIVE' and account.is_closed=1 and 
				(
					ISNULL(Convert(CHAR(8), letter_of_guarantee.expiry_date, 112), 0) = 0 and 
					ISNULL(Convert(CHAR(8), letter_of_guarantee.claim_validity_date, 112), 0) = 0 and 
					ISNULL(Convert(CHAR(8), letter_of_guarantee.last_maintenance_date, 112), 0) >= @p2year
				)
			)
		)


	open csr_VALY_build_letter_of_guarantee

	fetch Next from csr_VALY_build_letter_of_guarantee Into
	 @m31brn
	,@m31acc
	,@m31sfx
	,@m31ccy
	,@m31typ
	,@m31ref
	,@m31code
	,@m31codel
	,@m31codex
	,@d1tbrn
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@a2cat
	,@m31amt
	,@d11ccont
	,@d11blcgD
	,@d11blcgC
	,@u1code
	,@m31std
	,@d11mtd
	,@d11tmd
	,@d11lmd
	,@m31arc
	,@d4amt2
	,@d4mtd2
	,@d7intp1
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app
	,@m31cstage
	while @@Fetch_Status = 0

	begin
		set @m31abmflg= 0
		if (@m31arc  = ' ' Or (@m31arc = 'A' and (@d11mtd >= @pyear or @d11tmd >= @pyear)) OR (@m31arc = 'A' and @d11mtd = 0 and @d11tmd = 0 and @d11lmd >= @pyear))
		begin
		set @m31abmflg= 1
		end


		set @m31limitAmt= 0
		set @m31limitccy= ' '
		set @m31limittype= ' '

		if @d11mtd <> 0 and @d11mtd >= @d11tmd
		begin
			set @m31mtd = @d11mtd
		end

		if @d11tmd <> 0 and @d11tmd > @d11mtd
		begin
			set @m31mtd = @d11tmd
		end
		
		if @d11mtd = 0 and @d11tmd = 0
		begin
			set @m31mtd = 0
		end
 		
		set @m31exr	= 0
		set @m31time 	= ''
		set @m31mprice 	= 0
		
		insert into VALY values(@m31brn, @m31acc,   @m31sfx, @m31typ, @m31ref, -@m31amt, @m31ccy, @m31std, @m31std, @m31mtd, @m31mtd, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgD, @m31code, @m31codel, @m31codex, @m31limitAmt,@m31limitccy,@m31limittype,@m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,@m31cstage,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		execute issp_ACCT_mark @m31brn, @m31acc, @m31sfx

		insert into VALY values(@m31brn, @d11ccont, @u1code, @m31typ, @m31ref, @m31amt, @m31ccy, @m31std, @m31std, @m31mtd, @m31mtd, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @d11blcgC, 0, ' ', 0, 0,' ',' ',@m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0), isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', '  ',0,0,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		execute issp_ACCT_mark @m31brn, @d11ccont, @u1code

		fetch Next from csr_VALY_build_letter_of_guarantee Into
		 @m31brn
		,@m31acc
		,@m31sfx
		,@m31ccy
		,@m31typ
		,@m31ref
		,@m31code
		,@m31codel
		,@m31codex
		,@d1tbrn
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@a2cat
		,@m31amt
		,@d11ccont
		,@d11blcgD
		,@d11blcgC
		,@u1code
		,@m31std
		,@d11mtd
		,@d11tmd
		,@d11lmd
        ,@m31arc
        ,@d4amt2
		,@d4mtd2
		,@d7intp1
		,@d8amti2
		,@d8ar
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
		,@m31cstage
	end

	close csr_VALY_build_letter_of_guarantee

	deallocate csr_VALY_build_letter_of_guarantee

---------------------------------------------------------------------------------------
--step 12: loan.loan_account
--step 4: DLTR  ile ayni olmasi icin ayni kolon isimleri kullanildi
	DECLARE csr_VALY_build_loan_account cursor for 
	select
	b.id,
	acct.a1brn as d1brn, 
	acct.a1acc as d1acc, 
	acct.a1sfx as d1sfx,
	acct.a1ccy as d1ccy,
	a.deal_tdhp,
	c.product_code,
	case WHEN LEN(d.reference)<15 THEN d.reference
		 ELSE SUBSTRING(d.reference,0,10)+SUBSTRING(d.reference,12,15)
	end,
	'',
    '',
	'',
	a2cat,
	l.balance_amount,
	case a.status
	 WHEN 25 THEN 'A'
	 ELSE ''
	end ,
	ISNULL(m.detail_value,''),
	'',	
	cast(ISNULL(FORMAT(a.approval_date, 'yyyyMMdd'),ISNULL(FORMAT(a.start_Date, 'yyyyMMdd'),0)) as int),
	cast(ISNULL(FORMAT(a.contract_date, 'yyyyMMdd'),0) as int),
	cast(ISNULL(FORMAT(a.start_date, 'yyyyMMdd'),0) as int),
	cast(ISNULL(FORMAT(a.maturity_date, 'yyyyMMdd'),0) as int),
	cast(ISNULL(FORMAT(h.last_cycle_date, 'yyyyMMdd'),0) as int),
	cast(ISNULL(FORMAT(h.next_cycle_date, 'yyyyMMdd'),0) as int),
	e.owner_number,
	acct.a1sfx,
	CAST(SUBSTRING(settlement_account,6,6) as int),
	CAST(SUBSTRING(settlement_account,13,3) as int),
	i.last_cycle_to_next_business_interest_amount,
	0,
	i.not_posted_previous_years_interest_amount,
	a.interest_account,
	'L',
	case h.is_interest_paid_in_advance
	 WHEN 1 THEN 'D'
	 WHEN 0 THEN 'V'
	end,
	i.total_interest_posted_amount,
	isNull(h.apr,0.00),
	ISNULL(case 
			WHEN h.interest_term_cycle_point = 1 THEN CONCAT('Z',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 2 THEN CONCAT('W',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 3 THEN CONCAT('Y',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 4 THEN CONCAT('V',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 5 AND MONTH(a.start_date) IN ('01','04','07','10') THEN CONCAT('S',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 5 AND MONTH(a.start_date) IN ('02','05','08') THEN CONCAT('T',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 5 AND MONTH(a.start_date) IN ('03','06','09') THEN CONCAT('U',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 6 AND MONTH(a.start_Date) IN ('01','07') THEN CONCAT('M',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 6 AND MONTH(a.start_Date) IN ('02','08') THEN CONCAT('N',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 6 AND MONTH(a.start_Date) IN ('03','09') THEN CONCAT('O',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 6 AND MONTH(a.start_Date) IN ('04','10') THEN CONCAT('P',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 6 AND MONTH(a.start_Date) IN ('05','11') THEN CONCAT('Q',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 6 AND MONTH(a.start_Date) IN ('06','12') THEN CONCAT('R',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '01' THEN CONCAT('A',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '02' THEN CONCAT('B',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '03' THEN CONCAT('C',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '04' THEN CONCAT('D',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '05' THEN CONCAT('E',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '06' THEN CONCAT('F',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '07' THEN CONCAT('G',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '08' THEN CONCAT('H',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '09' THEN CONCAT('I',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '10' THEN CONCAT('J',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '11' THEN CONCAT('K',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 7 AND MONTH(a.start_Date) = '12' THEN CONCAT('L',h.interest_term_cycle_day)
			WHEN h.interest_term_cycle_point = 0 THEN CONCAT('0',h.interest_term_cycle_day)
	end,''),
	case h.rate_composition
	 WHEN 'ACTUAL_RATE'  THEN 'SB'
	 WHEN 'NO_INTEREST' THEN 'ZZ'
	 WHEN 'DISCOUNTED_RATE'  THEN 'SB'
	end,
	'',
	0,
	a.opening_amount_amount,
	cast(ISNULL(FORMAT(a.original_maturity_date, 'yyyyMMdd'),0) as int),
	i.last_cycle_to_next_cycle_interest_amount,
	h.actual_rate,
	0,
	'N',
	'',
	f.d2app,
	ISNULL(n.code,''),
	CASE j.detail_value
	   WHEN 'false' THEN 0
	   WHEN 'true' THEN 1
	   ELSE 0
	END,
	ISNULL(a.customer_stage,0),
	ISNULL(i.year_to_date_interest_amount,0)
	from loan.loan_account a 
		join accountcore.account b on a.account_number = b.number 
		join accountcore.customer_account c on b.id=c.id
		join accountcore.account_contract d on c.contract=d.id
		join accountcore.account_owner e on e.account=b.id
		join accountcore.account_interest h on b.id=h.account
		join accountcore.account_interest_calculation i on h.id=i.account_interest
		join accountcore.account_balance l on l.account_id=b.id
		join ydsm.DTYP f on f.d2typ = c.product_code
		join accountcore.account_type g on g.id=b.account_type
		join ydsm.ATYP k on k.a2mne=g.code
		join ydsm.acct on acct.a1brn=b.owning_unit_code and acct.a1acc=e.owner_number 
						and acct.a1atyp=g.code and acct.a1ccy=b.currency and a1cls='N'
		join ydsm.ccys on ccys.u1ccy=b.currency
		left join loan.loan_account_detail j on j.loan_account_id=a.id and j.detail=1
		left join loan.loan_account_detail m on m.loan_account_id=a.id and m.detail=6
		left join loan.loan_category n on a.loan_category=n.id
		where a.owner_unit_code  = @brn
		and  a.status <> 25
		and  (a.status = 1 or (a.status =25 and  cast(ISNULL(FORMAT(a.maturity_date, 'yyyyMMdd'),0) as int) > @p2year))
	open csr_VALY_build_loan_account

	fetch Next from csr_VALY_build_loan_account Into
	 @accountId
	,@m31brn
	,@m31acc
	,@m31sfx
	,@m31ccy
	,@m31blcg
	,@m31typ
	,@m31ref
	,@m31code
	,@m31codel
	,@m31codex
	,@a2cat
	,@m31amt
	,@m31arc
	,@d1tbrn	
	,@d1stl	
	,@d1psd
	,@d1ctd
	,@m31std
	,@m31mtd
	,@m31lcd
	,@m31ncd
	,@d8dacc
	,@d8dsfx
	,@d8iacc
	,@d8isfx
	,@d8amti1
	,@d8amti3
	,@d8amtp4
	,@d8pl
	,@d2typ0
	,@d8ichr
	,@d8tot
	,@m31rateD
	,@m31frqD
	,@m31rtD
	,@m31time
	,@m31mprice
	,@d4amt2
	,@d4mtd2
	,@d8amti2	
	,@d8ar		
	,@d8ar2
	,@d14equpay
	,@d14frqP
	,@d2app
	,@d14cat
	,@m31restructured
	,@m31cstage
	,@m31amtDy2d
	while @@Fetch_Status = 0

	begin

		set @m31limitAmt= 0
		set @m31limitccy= ' '
		set @m31limittype= ' '
		set @m31abmflg= 1
		if @m31arc='A' and @m31mtd < @pyear
		begin
			set @m31abmflg= 0
		end
		if @m31arc='A' and @m31mtd <= @p0date
		begin
			set @m31amt= 0
		end

		if @m31lcd = 0 or @m31lcd is null
		begin
			set @m31lcd = @m31std
		end

		if @m31ncd =0 or @m31ncd is null 
		begin
			set @m31ncd = @m31mtd
		end

		select @u1code 	  = u1code from CCYS where u1ccy = @m31ccy

		if @d2typ0  = 'L'
		begin
		
			set @m31amtDp4    =  @d8amtp4
			select @m31blcgDi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @d8pl and a1sfx = @u1code

			set @pl = '99' + substring(cast(@d8pl as char(6)),3,4)
			if @d8ichr = 'D'
			begin
				set @m31amtDi1  = @d8amti1 * -1
				select @m31blcgDir = a1blcg2 from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code
			end
			else
			begin
				set @m31amtDi1     =  @d8amti1 * -1
				select @m31blcgDir = a1blcg  from ACCT where a1brn = @m31brn and a1acc = @pl and a1sfx = @u1code
			end

			set @m31amtCy2d = 0 
			set @m31amtCi1  = 0 
			set @m31amtCp4  = 0 
			set @m31blcgCi  = ' '  
			set @m31blcgCir = ' '
			set @a8Dpl      = @d8pl
			set @a8Cpl      = 0
			set @m31amtDtot = @d8tot
			set @m31amtCtot = 0

			set @m31rateD   = @m31rateD
			set @m31frqD    = @m31frqD
			set @m31rtD     = @m31rtD

			set @m31rateC   = 0
			set @m31frqC    = 0
			set @m31rtC     = 0

		end

		if ((@flag5 = ' ' and @m31arc = ' ') or @flag5 = 'E' )
		begin
			if @m31lcd = @nbd 
			begin
				select @d7cycd = cast(ISNULL(FORMAT(MAX(x.payment_date), 'yyyyMMdd'),0) as int) from accountcore.account_payment_plan x join accountcore.account_payment_plan_definition y 
				on x.payment_plan_definition=y.id 
				where account = @accountId and payment_status='PAID' and cast(ISNULL(FORMAT(x.payment_date, 'yyyyMMdd'),0) as int) <@nbd
				if @d7cycd is null
				begin
					set @d7cycd = 0
				end
				set @m31ncd = @m31lcd 
				set @m31lcd = @d7cycd
				if @m31lcd = 0 
				begin
					set @m31lcd = @m31std
				end
			end		
		end

		set @m31exr	= 0

        if @m31time is null
		begin
			set @m31time = ''
		end

		if @m31mprice is null
		begin
			set @m31mprice = 0
		end
		
		if @d4amt2 is not null
		begin
			set @d4amt2 =  @d4amt2 * -1
		end
		
		if @m31amtDy2d is not null
		begin
			set @m31amtDy2d =  @m31amtDy2d * -1
		end
		
		if @d8amti2 is not null
		begin
			set @d8amti2 = @d8amti2 * -1
		end

		insert into VALY values(@m31brn, @m31acc, @m31sfx, @m31typ, @m31ref, @m31amt, @m31ccy, @m31std, @m31lcd, @m31ncd, @m31mtd, @m31amtDy2d, @m31amtDi1, 0, @m31amtDp4, @a8Dpl, @m31amtDtot, @m31blcgDi, @m31blcgDir, @m31rtD, @m31rateD, @m31frqD, @m31holdD, @m31amtCy2d, @m31amtCi1, 0, @m31amtCp4, @a8Cpl, @m31amtCtot, @m31blcgCi, @m31blcgCir, @m31rtC, @m31rateC, @m31frqC, 0, 0, @m31blcg, @m31code, @m31codel, @m31codex, @m31limitAmt, @m31limitccy, @m31limittype, @m31abmflg,@m31exr,@m31time,@m31mprice,@m31arc, isnull(@d1tbrn, 0), isnull(@d1stl, ' '), isnull(@d1psd, 0), isnull(@d1ctd, 0), isnull(@d4amt2, 0), isnull(@d4mtd2, 0), isnull(@d7intp1, 0),isnull(@d8amti2, 0), isnull(@d8ar, 0), isnull(@d8ar2, 0), isnull(@d14equpay, 'N'), isnull(@d14frqP, ' '), isnull(@d2app, ' '), 0, 0, 0, 0, ' ', ' ', 0, ' ', 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, ' ', ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, '', isnull(@d14cat, '  '),	@m31restructured ,@m31cstage,@m31tobrn,@m31toacc,@m31tosfx,@m31totyp,@m31toref,@m31toamtDi1,@m31toamtCi1,@m31todate)

		if @@ERROR <> 0 
		begin
			print @m31ref + @m31typ
		end
		
		execute issp_ACCT_mark @brn, @m31acc, @m31sfx

		fetch Next from csr_VALY_build_loan_account Into
		 @accountId
		,@m31brn
		,@m31acc
		,@m31sfx
		,@m31ccy
		,@m31blcg
		,@m31typ
		,@m31ref
		,@m31code
		,@m31codel
		,@m31codex
		,@a2cat
		,@m31amt
		,@m31arc
		,@d1tbrn	
		,@d1stl	
		,@d1psd
		,@d1ctd
		,@m31std
		,@m31mtd
		,@m31lcd
		,@m31ncd
		,@d8dacc
		,@d8dsfx
		,@d8iacc
		,@d8isfx
		,@d8amti1
		,@d8amti3
		,@d8amtp4
		,@d8pl
		,@d2typ0
		,@d8ichr
		,@d8tot
		,@m31rateD
		,@m31frqD
		,@m31rtD
		,@m31time
		,@m31mprice
		,@d4amt2
		,@d4mtd2
		,@d8amti2	
		,@d8ar		
		,@d8ar2
		,@d14equpay
		,@d14frqP
		,@d2app
		,@d14cat
		,@m31restructured
		,@m31cstage
		,@m31amtDy2d
	end

	close csr_VALY_build_loan_account

	deallocate csr_VALY_build_loan_account

---------------------------------------------------------------------------------------


	update VALY set 
	 m31IbanNo   = a1IbanNo                                       
	,m31atyp		= a1atyp
	,m31atbrn	= a1tbrn
	,m31blc		= a1blc 
	,m31crd      = a1crd
	,m31cld      = a1cld
	,m31cls		= a1cls
	,m31aana		= a1ana
	,m31rec		= case 	when c1rec is null then a1rec 
		else c1rec end 
	,m31pac		= isnull(c1pac, ' ')
	,m31ctyp		= isnull(c1typ, ' ')
	,m31fnm      = isnull(c1fnm, ' ')                                
	,m31sub		= isnull(c1sub, ' ')
	,m31tacc     = case 	when ISNUMERIC(c1tacc) = 1 then c1tacc 
		else 0 end
	,m31tno		= isnull(c1tno, 0)
	,m31txno     = isnull(c1txno, 0)                           
	,m31cana		= isnull(c1ana, ' ')
	,m31snm      = isnull(c1snm, ' ')  
	,m31fnsc		= isnull(v6fnsc, ' ')
	,m31qua		= isnull(v8qua, ' ')
	,m31ot		= isnull(v8ot, ' ')
	,m31ap		= case 	when m31amt < 0 then 'A' 
		when m31amt > 0 then 'P'
		else isnull(p1ap,'') end
	,m31avyD     = isnull(a10avyD, 0)                            
	,m31avyDoRM  = isnull(a10avyDoRM, 0)                           
	,m31avyC     = isnull(a10avyC, 0)                           
	,m31avyCoRM  = isnull(a10avyCoRM, 0)                           
	,m31cbc      = isnull(c1cbc, 0)
	,m31asnm     = ISNULL(a1snm, 0)
	from valy
	LEFT JOIN CSTM ON m31brn = c1brn AND m31acc = c1acc 
	LEFT JOIN CTYP ON c1typ = v8mne
	LEFT JOIN ANLZ ON c1ana = v6mne
	LEFT JOIN ACST ON m31brn = a10brn AND m31acc = a10acc AND m31sfx = a10sfx and a10tod = 99999999
	LEFT JOIN ACCT ON m31brn = a1brn AND m31acc = a1acc AND m31sfx = a1sfx
	LEFT JOIN TDHP ON m31blcg = p1tdhp
	WHERE (c1brn=@brn or c1brn is null)

  END
GO


