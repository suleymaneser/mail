USE [rallyIQ]
GO

/****** Object:  StoredProcedure [ydsm].[issp_VALL_build]    Script Date: 8/23/2021 5:06:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ydsm].[issp_VALL_build] 

	 @brn		smallint  = null -- branch
	,@p0date	int       = null -- current brach date
	,@nbd		int       = null -- next bussiness date
	,@flag5		char(1)   = null -- 'E' ise eod
	,@scn		char(1)   = null -- gun senaryosu 'N' : normal day
	,@pldate	int	  = null --  bir sonraki ayin ilk gunu

	AS

	  BEGIN

		DECLARE
		 @p0sta			char(1)
		,@m30brn		smallint
		,@m30acc		int
		,@m30sfx		smallint
		,@m30typ		char(3)
		,@m30ref		char(13)
		,@m30amt		decimal (18, 2)
		,@m30ccy		char(3)

		,@m30std		int
		,@m30lcd		int
		,@m30ncd		int
		,@m30mtd		int

		,@m30amtDy2d		decimal (18, 2)
		,@m30amtDi1		decimal (18, 2)
		,@m30amtDp4		decimal (18, 2)
		,@m30amtDtot		decimal (18, 2)
		,@m30blcgDi		varchar(10)
		,@m30blcgDir		varchar(10)
		,@m30rtD		char(2)
		,@m30rateD		decimal (18, 9)
		,@m30frqD		char(3)
		,@m30holdD		decimal (18, 2)		

		,@m30amtCy2d		decimal (18, 2)
		,@m30amtCi1		decimal (18, 2)
		,@m30amtCp4		decimal (18, 2)
		,@m30amtCtot		decimal (18, 2)
		,@m30blcgCi		varchar(10)
		,@m30blcgCir		varchar(10)
		,@m30rtC		char(2)
		,@m30rateC		decimal (18, 9)
		,@m30frqC		char(3)

		,@m30blcg		varchar(10)

		,@p1ap			char(1)
		,@p1stl			char(1)
		,@a2str			char(1)
		,@a2str2		char(1)
		,@d2app			char(2)
		,@d1arc			char(1)
		,@d9Pamt		decimal (18, 2)
		,@d9Samt		decimal (18, 2)
		,@d9Pccy		char(3)
		,@d9Sccy		char(3)
		,@d9Psfx		smallint
		,@d9Ssfx		smallint
		,@d9ref			char(13)
		,@d9opd			int
		,@d9pl			int

		,@m8amtR		decimal (18, 2)
		,@m8amtP		decimal (18, 2)

		,@a1atyp			char(2)
		,@a1blcg		varchar(10)
		,@a1blcg2		varchar(10)
		,@a1sumadj		decimal (18, 2)
		,@a1sumCD		decimal (18, 2)

		,@d1blcg2		varchar(10)

		,@d11ccont		int
		,@d11blcgD		varchar(10)
		,@d11blcgC		varchar(10)
		,@d11tmd		int
		,@d11mtd		int
		,@u1code		smallint

		,@d8dacc		int
		,@d8dsfx		smallint
		,@d8iacc		int
		,@d8isfx		smallint
		,@d8ichr		char(1)

		,@d8amti1		decimal (18, 2)
		,@d8amti3		decimal (18, 2)
		,@d8amtp4		decimal (18, 2)
		,@a8Dpl			int
		,@a8Cpl			int
		,@d8pl			int
		,@d8tot			decimal (18, 2)

		,@a8Damti1		decimal (18, 2)
		,@a8Damti3		decimal (18, 2)
		,@a8Camti1		decimal (18, 2)
		,@a8Camti3		decimal (18, 2)

		,@a8Cncd		int
		,@a8Dncd		int
		,@a8Clcd		int
		,@a8Dlcd		int

		,@d7net			decimal (18, 2)
		,@d7cycd		int
		,@a7intp1		decimal (18, 2)
		,@d7intp1		decimal (18, 2)
		,@d2typ0		char(1)

		,@m30code 		smallint
		,@m30codeL 		char(1)	
		,@m30codeX 		tinyint
		,@a2cat			char(5)
		,@pl			char(6)

		,@janfirst		int
		,@SQLString		nvarchar(1000)
		,@ParmDefinition	nvarchar(500)
		,@safeP4		decimal (18, 2)

		,@a1flg12	char(2)--stage
		,@a1flg13	char(2)--cstage


		,@m30stage	smallint
		,@m30cstage smallint
		,@m30restructured tinyint

		,@m30a1sumadj decimal(18,2)
	--initialize all related table(s)

		BEGIN TRANSACTION

			delete from VALL where m30brn = @brn
			update ACCT set a1gl = 0 where a1gl <> 0 and a1brn= @brn
			set @janfirst = @p0date / 10000
			set @janfirst = @janfirst * 10000 + 101
		
		COMMIT TRANSACTION

	---------------------------------------------------------------------------------------

		set @m30holdD= 0

	--step 1: debit ACCT

		BEGIN TRANSACTION

		if @flag5 = 'E'
		begin
			DECLARE csr_VALL_build_ACCT1 cursor for
			select
			 a1brn
			,a1acc
			,a1sfx
			,a1bal + a1sumadj
			,a1sumadj
			,a1sumC + a1sumD

			,a1ccy
			,a1atyp
			,case when a1ana in ('IA', 'IC') then a1blcg2 else a1blcg end as a1blcg

			,a2cat

			,a8Dpl
			,a8Damti1
			,a8Damti3
			,a8Damtp4
			,a8Dtot
			,a8Daprr
			,a8Difq
			,a8Dlcd
			,a8Dncd

			,case a8Dact 
				when 0 then case a8Daprr 
							when 0 then ' '	
							else        'LS'
						end 


				else   'SB'  
			 end

			,a8Cpl
			,a8Camti1
			,a8Camti3
			,a8Camtp4
			,a8Ctot
			,a8Caprr
			,a8Cifq
			,a8Clcd
			,a8Cncd

			,case a8Cact 
				when 0 then case a8Caprr 
							when 0 then ' '	
							else        'LS'
						end 
				else   'SB'  
			 end

		 
			 ,a1flg12	--stage
			 ,a1flg13	--cstage
			 ,a1flg7		--restructured

			 ,a1sumadj 

			from ACCT
			left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
				 join ATYP on a1atyp = a2mne
			left join ydsm.rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
			where a1brn  = @brn
			and   a2blcg = 'N' 
			and   a1bal + a1sumadj <= 0 
			and   a1cls = 'N'
			and   a2str  <> 'X'
			and   m37brna is null
			order by a1blcg, a1ccy
		end
		else
		begin
			DECLARE csr_VALL_build_ACCT1 cursor for
			select
			 a1brn
			,a1acc
			,a1sfx
			,a1bal + a1sumC + a1sumD
			,a1sumadj
			,0

			,a1ccy
			,a1atyp
			,case when a1ana in ('IA', 'IC') then a1blcg2 else a1blcg end as a1blcg

			,a2cat

			,a8Dpl
			,a8Damti1
			,a8Damti3
			,a8Damtp4
			,a8Dtot
			,a8Daprr
			,a8Difq
			,a8Dlcd
			,a8Dncd

			,case a8Dact 
				when 0 then case a8Daprr 
							when 0 then ' '	
							else        'LS'
						end 
				else   'SB'  
			 end

			,a8Cpl
			,a8Camti1
			,a8Camti3
			,a8Camtp4
			,a8Ctot
			,a8Caprr
			,a8Cifq
			,a8Clcd
			,a8Cncd

			,case a8Cact 
				when 0 then case a8Caprr 
							when 0 then ' '	
							else        'LS'
						end 
				else   'SB'  
			 end


		 
			 ,a1flg12	--stage
			 ,a1flg13	--cstage
			 ,a1flg7		--restructured
			 ,a1sumadj

			from ACCT
			left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
				 join ATYP on a1atyp = a2mne
			left join ydsm.rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
			where a1brn  = @brn
			and   a2blcg = 'N' 
			and   a1bal + a1sumC + a1sumD <= 0 
			and   a1cls = 'N'
			and   a2str  <> 'X'
			and m37brna is null
			order by a1blcg, a1ccy

		end

		open csr_VALL_build_ACCT1

		fetch Next from csr_VALL_build_ACCT1 Into
		 @m30brn
		,@m30acc
		,@m30sfx
		,@m30amt
		,@a1sumadj
		,@a1sumCD

		,@m30ccy
		,@a1atyp
		,@m30blcg

		,@a2cat

		,@a8Dpl
		,@m30amtDi1
		,@a8Damti3
		,@m30amtDp4
		,@m30amtDtot
		,@m30rateD
		,@m30frqD
		,@a8Dlcd
		,@a8Dncd
		,@m30rtD

		,@a8Cpl
		,@m30amtCi1
		,@a8Camti3
		,@m30amtCp4
		,@m30amtCtot
		,@m30rateC
		,@m30frqC
		,@a8Clcd
		,@a8Cncd
		,@m30rtC

		,@a1flg12
		,@a1flg13
		,@m30restructured
		,@m30a1sumadj
		while @@Fetch_Status = 0

		begin

					if @m30amt = 0 and @m30blcg = ''
					begin
					   select @m30blcg = a1blcg2 from acct 
					   where a1brn = @m30brn and a1acc = @m30acc and a1sfx = @m30sfx
					end

			set @safeP4 = 0

			if @a8Dpl is null 
			begin
				set @a8Dpl 	= 0
				set @m30amtDi1	= 0
				set @a8Damti3	= 0
				set @m30amtDp4	= 0
				set @m30amtDtot	= 0
				set @m30rateD	= 0
				set @m30frqD    = ' ' 
				set @m30rtD     = ' '
				set @a8Dlcd     = 0
				set @a8Dncd     = 0
	
				set @a8Cpl	= 0
				set @m30amtCi1	= 0
				set @a8Camti3	= 0
				set @m30amtCp4	= 0
				set @m30amtCtot	= 0
				set @m30rateC	= 0
				set @m30frqC    = ' '
				set @m30rtC     = ' '
				set @a8Clcd     = 0
				set @a8Cncd     = 0
			end

			set @m30amtDy2d = 0
			set @m30blcgDi  = ' '
			set @m30blcgDir = ' '

			set @m30amtCy2d = 0
			set @m30blcgCi  = ' '
			set @m30blcgCir = ' '

			set @a7intp1    = 0 

			set @m30code  = 0
			set @m30codel = ' '
			set @m30codeX = 0

			select TOP 1
			 @m30code  = l6code
			,@m30codel = l6codel
			,@m30codex = l6codex
			from LATR 
			where l6cat = 'LS350' and l6acc = @m30acc and l6cat = @a2cat
			order by right('0000' + cast(l6code as varchar(4)) , 4) +
						   l6codel + 
						   right('000' + cast(l6codex as varchar(3)) , 3) ASC

			if @m30code is null
			begin
				set @m30code  = 0
				set @m30codel = ' '
				set @m30codeX = 0
			end

			if @a8Dpl <> 0 or @m30amtDi1 <> 0 or @m30amtDp4 <> 0
			begin
				select @u1code 	  = u1code  from CCYS where u1ccy = @m30ccy
				select @m30blcgDi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @a8Dpl and a1sfx = @u1code
			
				select @a7intp1   = sum(a7intp1) 
				from AINP 
				join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
				where a8brn = @brn and a8acc = @m30acc and a8sfx = @m30sfx and a7cycd >= @janfirst and a7dc = 'D'

		-----------
				select @safeP4  = a3Dibf
				from ABFW 
				where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
	
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
	
				if @safeP4 = 0 or @safeP4 = null
				begin
					select @safeP4  = a3Ditp
					from ABFW 
					where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
				end
	
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
		------------
	
				if @a7intp1 is null
				begin
					set @a7intp1  = 0
				end

				if @scn not in ('N', 'W')
				begin
					set @m30amtDi1 = @a8Damti3
				end
	--			set @m30amtDy2d =  @m30amtDi1 + @a7intp1 - @m30amtDp4
				set @m30amtDy2d =  @m30amtDi1 + @a7intp1 - @safeP4

				set @pl = '99' + substring(cast(@a8Dpl as char(6)),3,4)

				select @m30blcgDir = a1blcg from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code

			end

			if @a8Cpl <> 0 or @m30amtCi1 <> 0 or @m30amtCp4 <> 0
			begin
				select @u1code 	  = u1code from CCYS where u1ccy = @m30ccy
				select @m30blcgCi = a1blcg from ACCT where a1brn = @brn and a1acc = @a8Cpl and a1sfx = @u1code

				select @a7intp1   = sum(a7intp1) 
				from AINP 
				join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
				where a8brn = @brn and a8acc = @m30acc and a8sfx = @m30sfx and a7cycd >= @janfirst  and a7dc = 'C'

	-----------
				select @safeP4  = a3Cibf
				from ABFW 
				where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
	
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
	
				if @safeP4 = 0 or @safeP4 = null
				begin
					select @safeP4  = a3Citp
					from ABFW 
					where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
				end
	
				if @safeP4 is null
				begin
					set @safeP4  = 0
				end
		------------

				if @a7intp1 is null
				begin
					set @a7intp1  = 0
				end

				if @scn not in ('N', 'W')
				begin
					set @m30amtCi1 = @a8Camti3
				end

	--			set @m30amtCy2d =  @m30amtCi1 + @a7intp1 - @m30amtCp4
				set @m30amtCy2d =  @m30amtCi1 + @a7intp1 - @safeP4

				set @pl = '99' + substring(cast(@a8Cpl as char(6)),3,4)

				select @m30blcgCir = a1blcg2 from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code

			end
		
			if @a1atyp = 'YP' 
			begin
				if @scn in ('N','W') 
				begin
					set @m30amtCi1 = @a1sumadj 
				end
				else
				begin
					set @m30amtCi1 = @a1sumadj --+ @a1sumCD
				end
			end

			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj) 
					values(@m30brn, @m30acc, @m30sfx, ' ',' ', @m30amt, @m30ccy, @p0date, @a8Dlcd, @p0date, @p0date, @m30amtDy2d, @m30amtDi1, @m30amtDp4, @a8Dpl, @m30amtDtot, @m30blcgDi, @m30blcgDir, @m30rtD, @m30rateD, @m30frqD, @m30holdD, @m30amtCy2d, @m30amtCi1, @m30amtCp4, @a8Cpl, @m30amtCtot, @m30blcgCi, @m30blcgCir, @m30rtC, @m30rateC, @m30frqC, @m30blcg,@m30code,@m30codel,@m30codex,CAST(@a1flg12 as smallint),CAST(@a1flg13 as smallint),@m30restructured,@m30a1sumadj)
			execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx

			fetch Next from csr_VALL_build_ACCT1 Into
			 @m30brn
			,@m30acc
			,@m30sfx
			,@m30amt
			,@a1sumadj
			,@a1sumCD

			,@m30ccy
			,@a1atyp
			,@m30blcg

			,@a2cat

			,@a8Dpl
			,@m30amtDi1
			,@a8Damti3
			,@m30amtDp4
			,@m30amtDtot
			,@m30rateD
			,@m30frqD
			,@a8Dlcd
			,@a8Dncd
			,@m30rtD
	
			,@a8Cpl
			,@m30amtCi1
			,@a8Camti3
			,@m30amtCp4
			,@m30amtCtot
			,@m30rateC
			,@m30frqC
			,@a8Clcd
			,@a8Cncd
			,@m30rtC

			,@a1flg12
			,@a1flg13
			,@m30restructured
			,@m30a1sumadj
		end

		close csr_VALL_build_ACCT1

		deallocate csr_VALL_build_ACCT1

		COMMIT TRANSACTION

	---------------------------------------------------------------------------------------

	--step 2: credit ACCT



		BEGIN TRANSACTION

		set @m30code  = 0
		set @m30codel = ' '
		set @m30codeX = 0

		if @flag5 = 'E'
		begin
			DECLARE csr_VALL_build_ACCT2 cursor for
			select
			 a1brn
			,a1acc
			,a1sfx
			,a1bal + a1sumadj
			,a1sumadj

			,a1ccy
			,a1atyp
			,case when a1ana in ('IB', 'ID') then a1blcg else a1blcg2 end as a1blcg2

			,a8Dpl
			,a8Damti1
			,a8Damti3
			,a8Damtp4
			,a8Dtot
			,a8Daprr
			,a8Difq
			,a8Dlcd
			,a8Dncd

			,case a8Dact 
				when 0 then case a8Daprr 
							when 0 then ' '	
							else        'LS'
						end 
				else   'SB'  
			 end

			,a8Cpl
			,a8Camti1
			,a8Camti3
			,a8Camtp4
			,a8Ctot
			,a8Caprr
			,a8Cifq
			,a8Clcd
			,a8Cncd

			,case a8Cact 
				when 0 then case a8Caprr 
							when 0 then ' '	
							else        'LS'
						end 
				else   'SB'  
			 end

			 ,a1flg12	--stage
			 ,a1flg13	--cstage
			 ,a1flg7		--restructured
			 ,a1sumadj
			from ACCT

			left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
				 join ATYP on a1atyp = a2mne
			left join ydsm.rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
			where a1brn  = @brn
			and   a2blcg = 'N'
			and a1bal + a1sumadj > 0
			and   a1cls = 'N'
			and   a2str  <> 'X'
			and m37brna is null
			order by a1blcg2, a1ccy
		end
		else
		begin
			DECLARE csr_VALL_build_ACCT2 cursor for
			select
			 a1brn
			,a1acc
			,a1sfx
			,a1bal + a1sumC + a1sumD
			,a1sumadj

			,a1ccy
			,a1atyp
			,case when a1ana in ('IB', 'ID') then a1blcg else a1blcg2 end as a1blcg2

			,a8Dpl
			,a8Damti1
			,a8Damti3
			,a8Damtp4
			,a8Dtot
			,a8Daprr
			,a8Difq
			,a8Dlcd
			,a8Dncd

			,case a8Dact 
				when 0 then case a8Daprr 
							when 0 then ' '	
							else        'LS'
						end 
				else   'SB'  
			 end
			,a8Cpl
			,a8Camti1
			,a8Camti3
			,a8Camtp4
			,a8Ctot
			,a8Caprr
			,a8Cifq
			,a8Clcd
			,a8Cncd

			,case a8Cact 
				when 0 then case a8Caprr 
							when 0 then ' '	
							else        'LS'
						end 
				else   'SB'  
			 end

			 ,a1flg12	--stage
			 ,a1flg13	--cstage
			 ,a1flg7		--restructured
			 ,a1sumadj
			from ACCT
			left join AINT on a1brn  = a8brn and a1acc  = a8acc and a1sfx  = a8sfx
				 join ATYP on a1atyp = a2mne
			left join ydsm.rlvz on a1brn  = m37brna and a1acc  = m37acc and a1sfx  = m37sfx
			where a1brn  = @brn
			and   a1bal + a1sumC + a1sumD  > 0 
			and   a2blcg = 'N'
			and   a2str  <> 'X'
			and   a1cls = 'N'
			and m37brna is null
			order by a1blcg2, a1ccy
		end

			open csr_VALL_build_ACCT2

			fetch Next from csr_VALL_build_ACCT2 Into
			 @m30brn
			,@m30acc
			,@m30sfx
			,@m30amt
			,@a1sumadj

			,@m30ccy
			,@a1atyp
			,@m30blcg

			,@a8Dpl
			,@m30amtDi1
			,@a8Damti3
			,@m30amtDp4
			,@m30amtDtot
			,@m30rateD
			,@m30frqD

			,@a8Dlcd
			,@a8Dncd
			,@m30rtD

			,@a8Cpl
			,@m30amtCi1
			,@a8Camti3
			,@m30amtCp4
			,@m30amtCtot
			,@m30rateC
			,@m30frqC
			,@a8Clcd
			,@a8Cncd
			,@m30rtC
			,@a1flg12
			,@a1flg13
			,@m30restructured
			,@m30a1sumadj
			while @@Fetch_Status = 0

			 begin

			set @safeP4 	= 0

			 if @a8Dpl is null 
			 begin
 				set @a8Dpl 	= 0
				set @m30amtDi1	= 0
				set @a8Damti3	= 0
				set @m30amtDp4	= 0
				set @m30amtDtot = 0
				set @m30rateD   = 0
				set @m30frqD    = ' '
				set @m30rtD	= ' '
				set @a8Dlcd     = 0
				set @a8Dncd     = 0
	
				set @a8Cpl	= 0
				set @m30amtCi1	= 0
				set @a8Camti3	= 0
				set @m30amtCp4	= 0
				set @m30amtCtot = 0
				set @m30rateC   = 0
				set @m30frqC    = ' '
				set @m30rtC	= ' '
				set @a8Clcd     = 0
				set @a8Cncd     = 0
			 end


			set @m30amtDy2d = 0
			set @m30blcgDi  = ' '
			set @m30blcgDir = ' '

			set @m30amtCy2d = 0
			set @m30blcgCi  = ' '
			set @m30blcgCir = ' '

			set @a7intp1    = 0 

				if @a8Dpl <> 0 or @m30amtDi1 <> 0 or @m30amtDp4 <> 0
				begin
					select @u1code 	  = u1code  from CCYS where u1ccy = @m30ccy
					select @m30blcgDi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @a8Dpl and a1sfx = @u1code
	
					select @a7intp1   = sum(a7intp1) 
					from AINP 
					join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
					where a8brn = @brn and a8acc = @m30acc and a8sfx = @m30sfx and a7cycd >= @janfirst and a7dc = 'D'
			
			-----------
					select @safeP4  = a3Dibf
					from ABFW 
					where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
		
					if @safeP4 is null
					begin
						set @safeP4  = 0
					end
		
					if @safeP4 = 0 or @safeP4 = null
					begin
						select @safeP4  = a3Ditp
						from ABFW 
						where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
					end
		
					if @safeP4 is null
					begin
						set @safeP4  = 0
					end
			------------

					if @a7intp1 is null
					begin
						set @a7intp1  = 0
					end	

					if @scn not in ('N', 'W')
					begin
						set @m30amtDi1 = @a8Damti3
					end
	--				set @m30amtDy2d =  @m30amtDi1 + @a7intp1 - @m30amtDp4
					set @m30amtDy2d =  @m30amtDi1 + @a7intp1 - @safeP4

					set @pl = '99' + substring(cast(@a8Dpl as char(6)),3,4)

					select @m30blcgDir = a1blcg from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code

				end
	
				if @a8Cpl <> 0 or @m30amtCi1 <> 0 or @m30amtCp4 <> 0
				begin
					select @u1code 	  = u1code from CCYS where u1ccy = @m30ccy
					select @m30blcgCi = a1blcg from ACCT where a1brn = @brn and a1acc = @a8Cpl and a1sfx = @u1code
	
					select @a7intp1   = sum(a7intp1) 
					from AINP 
					join AINT on a7brn = a8brn and a7acc = a8acc and a7sfx = a8sfx
					where a8brn = @brn and a8acc = @m30acc and a8sfx = @m30sfx and a7cycd >= @janfirst  and a7dc = 'C'

			-----------
					select @safeP4  = a3Cibf
					from ABFW 
					where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
		
					if @safeP4 is null
					begin
						set @safeP4  = 0
					end
		
					if @safeP4 = 0 or @safeP4 = null
					begin
						select @safeP4  = a3Citp
						from ABFW 
						where a3brn = @brn and a3acc = @m30acc and a3sfx = @m30sfx and a3bfd = @janfirst 
					end
		
					if @safeP4 is null
					begin
						set @safeP4  = 0
					end
			------------

					if @a7intp1 is null
					begin
						set @a7intp1  = 0
					end	
	
					if @scn not in ('N', 'W')
					begin
						set @m30amtCi1 = @a8Camti3
					end
	--				set @m30amtCy2d =  @m30amtCi1 + @a7intp1 - @m30amtCp4
					set @m30amtCy2d =  @m30amtCi1 + @a7intp1 - @safeP4

					set @pl = '99' + substring(cast(@a8Cpl as char(6)),3,4)

					select @m30blcgCir = a1blcg2 from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code

				end

				if @a1atyp = 'YP' 
				begin
					 set @m30amtDi1 = @a1sumadj
				end
				insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, ' ',' ', @m30amt, @m30ccy, @p0date, @a8Clcd, @p0date, @p0date, @m30amtDy2d, @m30amtDi1, @m30amtDp4, @a8Dpl, @m30amtDtot, @m30blcgDi, @m30blcgDir, @m30rtD, @m30rateD, @m30frqD, @m30holdD, @m30amtCy2d, @m30amtCi1, @m30amtCp4, @a8Cpl, @m30amtCtot, @m30blcgCi, @m30blcgCir, @m30rtC, @m30rateC, @m30frqC,  @m30blcg, 0,      ' ',      0,CAST(@a1flg12 as smallint),CAST(@a1flg13 as smallint),@m30restructured,@m30a1sumadj)
				execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx

		
				fetch Next from csr_VALL_build_ACCT2 Into
				 @m30brn
				,@m30acc
				,@m30sfx
				,@m30amt
				,@a1sumadj

				,@m30ccy
				,@a1atyp
				,@m30blcg

				,@a8Dpl	
				,@m30amtDi1
				,@a8Damti3
				,@m30amtDp4
				,@m30amtDtot
				,@m30rateD
				,@m30frqD
				,@a8Dlcd
				,@a8Dncd
				,@m30rtD

				,@a8Cpl
				,@m30amtCi1
				,@a8Camti3
				,@m30amtCp4
				,@m30amtCtot
				,@m30rateC
				,@m30frqC	
				,@a8Clcd
				,@a8Cncd
				,@m30rtC
				,@a1flg12
				,@a1flg13
				,@m30restructured
				,@m30a1sumadj
			end

			close csr_VALL_build_ACCT2

			deallocate csr_VALL_build_ACCT2

			COMMIT TRANSACTION

	---------------------------------------------------------------------------------------

	--step 3: DLFX (Fx deals)


		DECLARE csr_VALL_build_DLFX cursor for
		select
		 d9brn
		,d9typ
		,d9ref
		,d9Pamt
		,d9Samt
		,d9Pccy
		,d9Sccy
		,d9Psfx
		,d9Ssfx
		,d9opd
		,d1acc
		,d9pl
		,d9plamt
		,d9plamt2


		from DLFX
		join DEAL on d1brn = d9brn and d1typ = d9typ and d1ref = d9ref
		where d1brn = @brn
		and   d1mnt = 3 
		and   d1arc = ' '
		and   d1sts not in ('V') 

		open csr_VALL_build_DLFX

		fetch Next from csr_VALL_build_DLFX Into
		 @m30brn
		,@m30typ
		,@m30ref
		,@d9Pamt
		,@d9Samt
		,@d9Pccy
		,@d9Sccy
		,@d9Psfx
		,@d9Ssfx
		,@m30std
		,@m30acc

		,@d9pl
		,@m30amtDi1
		,@m30amtDp4
	
		while @@Fetch_Status = 0

		begin

			if @m30typ = 'IWF' 
			begin
				set @d9ref = substring(@m30ref,1,4) + 'SWS' + substring(@m30ref,8,6)
				select @d9opd = d9opd from DLFX where d9brn = @m30brn and d9typ = 'SWS' and d9ref = @d9ref		
			end

			if not (@m30typ = 'IWF' and @d9opd > @p0date)
			begin
				set @m30sfx  = @d9Psfx			
				select @a1blcg  = a1blcg,@a1blcg2  = a1blcg2,@a2str2 = a2str2  from ACCT join ATYP on a1atyp=a2mne
							where a1brn = @brn and a1acc = @m30acc and a1sfx = @m30sfx
				if @a2str2 = 'U'
				begin
					set @m30amt  = @d9Pamt 
					set @a1blcg  = @a1blcg2 
				end
				if @a2str2 <> 'U'
				begin
					set @m30amt  = @d9Pamt * -1 
				end
				set @m30ccy  = @d9Pccy
				set @m30blcg = @a1blcg
	
				set @a8Dpl = @d9pl  + 993000
				select @m30blcgDi = a1blcg  from ACCT where a1brn = @brn and a1acc = @a8Dpl 
				set @a8Cpl = @d9pl  + 994000
				select @m30blcgCi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @a8Cpl
				--
				set @pl = @d9pl  + 993040
				select @m30blcgDir = a1blcg2  from ACCT where a1brn = @brn and a1acc = @pl 
				set @pl = @d9pl  + 994040
				select @m30blcgCir = a1blcg   from ACCT where a1brn = @brn and a1acc = @pl
	
				insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, @m30amt, @m30ccy, @m30std, @m30std, @m30std, @m30std, @m30amtDy2d, @m30amtDi1, @m30amtDp4,  @a8Dpl, 0, @m30blcgDi, @m30blcgDir, ' ', 0, ' ', 0, 0, 0, 0, @a8Cpl, 0, @m30blcgCi, @m30blcgCir, ' ', 0, ' ', @m30blcg, 0, ' ', 0,0,0,0,0)
				execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx
	
				set @m30sfx  = @d9Ssfx
				select @a1blcg2 = a1blcg2 from ACCT where a1brn = @brn and a1acc = @m30acc and a1sfx = @m30sfx
				set @m30amt  = @d9Samt
				set @m30ccy  = @d9Sccy
				set @m30blcg = @a1blcg2

				insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, @m30amt, @m30ccy, @m30std, @m30std, @m30std, @m30std, 0,           0,          0,           0,       0,       ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0,     0,  0, ' '       , ' ', ' ', 0, ' ', @m30blcg, 0, ' ', 0,0,0,0,0)
	
				execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx
			end

			fetch Next from csr_VALL_build_DLFX Into
			 @m30brn
			,@m30typ
			,@m30ref
			,@d9Pamt
			,@d9Samt
			,@d9Pccy
			,@d9Sccy
			,@d9Psfx
			,@d9Ssfx
			,@m30std
			,@m30acc

			,@d9pl
			,@m30amtDi1
			,@m30amtDp4
	
		end

		close csr_VALL_build_DLFX

		deallocate csr_VALL_build_DLFX

	---------------------------------------------------------------------------------------

	--step 4: DLTR (Term deals)

		DECLARE csr_VALL_build_DLTR cursor for 	
		select
		 d1brn
		,d1acc
		,d1sfx
		,d1ccy
		,d1blcg
		,d1typ
		,d1ref
		,d1code
		,d1codel
		,d1codex
		,d4amt
		,d1arc
		,d4std
		,d4mtd
		,d8lcd
		,d8ncd
		,d8dacc
		,d8dsfx
		,d8iacc
		,d8isfx
		,d8amti1
		,d8amti3
		,d8amtp4
		,d8pl
		,d2typ0
		,d8ichr
		,d8tot
		,d8aprr
		,d8ifrq
		,case d14bas
			when '1'     then 'LS'
			when '2'     then 'EX'
			when '3'     then 'SB'
			when '4'     then 'ZZ'
			when '5'     then 'SB'
			when '6'     then 'ES'
			when '7'     then 'YD'
			when '8'     then 'SD'
			else	          'SB'	
		 end
		 ,isnull(d14stage, 0)
		 ,isnull(d14cstage,0)
		 ,isnull(d14restructured,0)
		from      DEAL
			 join DLTR on d1brn = d4brn  and d1typ = d4typ  and d1ref = d4ref
			 join DINT on d1brn = d8brn  and d1typ = d8typ  and d1ref = d8ref  and d8seq = 0 
		left join DCLO on d1brn = d14brn and d1typ = d14typ and d1ref = d14ref  
			 join DTYP on d1typ = d2typ
		where d1brn  = @brn
		and   d1mnt  = 4 
		and   d1sts not in ('V','C')
		and   d2typ0 in ('D','L')
		and  (d1arc  = ' ' or (d4mtd > @p0date)) --or (d4mtd < @nbd and d1psd = @p0date)

		open csr_VALL_build_DLTR

		fetch Next from csr_VALL_build_DLTR Into
		 @m30brn
		,@m30acc
		,@m30sfx
		,@m30ccy
		,@m30blcg
		,@m30typ
		,@m30ref
		,@m30code
		,@m30codel
		,@m30codex
		,@m30amt
		,@d1arc
		,@m30std
		,@m30mtd
		,@m30lcd
		,@m30ncd
		,@d8dacc
		,@d8dsfx
		,@d8iacc
		,@d8isfx
		,@d8amti1
		,@d8amti3
		,@d8amtp4
		,@d8pl
		,@d2typ0
		,@d8ichr
		,@d8tot
		,@m30rateD
		,@m30frqD
		,@m30rtD
		,@m30stage
		,@m30cstage
		,@m30restructured

		while @@Fetch_Status = 0

		begin

			set @safeP4 = 0
		

			if @m30lcd > @p0date and @d2typ0 <> 'L'
			begin

				set @d7cycd = 0
				select @d7cycd  = max(d7cycd) from DINP 
				where d7brn = @m30brn and d7typ = @m30typ and d7ref = @m30ref and d7seq = 0 and d7cycd < @m30lcd

				if @d7cycd is null or @d7cycd < @janfirst
				begin
					select @d8amtp4 =  d3itp from DBFW 
					where d3brn = @m30brn and d3typ = @m30typ and d3ref = @m30ref and d3seq = 0 and d3bfd = @janfirst
				end
			

				if @scn not in ('N','W')
				begin
					select @d8amti3 =  d3itp from DBFW 
					where d3brn = @m30brn and d3typ = @m30typ and d3ref = @m30ref and d3seq = 0 and d3bfd = @pldate
				end 
				else
				begin
					select @d8amti1   = sum(d7intp1) 
					from DINP 
					join DINT on d7brn = d8brn and d7typ = d8typ and d7ref = d8ref and d7seq = d8seq
					where d8brn = @brn and d8typ = @m30typ and d8ref = @m30ref and d7cycd = @m30lcd
				end
		
			end

			if @m30lcd = 0 
			begin
				set @m30lcd = @m30std
			end

			if @m30ncd = 99999999 
			begin
				set @m30ncd = @m30mtd
			end


			select @u1code 	  = u1code from CCYS where u1ccy = @m30ccy

			select @d7intp1   = sum(d7intp1) 
			from DINP 
			join DINT on d7brn = d8brn and d7typ = d8typ and d7ref = d8ref and d7seq = d8seq
			where d8brn = @brn and d8typ = @m30typ and d8ref = @m30ref and d7cycd >= @janfirst and d7cycd <= @p0date 


			select @safeP4  = d3ibf
			from DBFW 
			where d3brn = @brn and d3typ = @m30typ and d3ref = @m30ref and d3bfd = @janfirst 

			if @safeP4 is null
			begin
				set @safeP4  = 0
			end

			if @safeP4 = 0 or @safeP4 = null
			begin
				select @safeP4  = d3itp
				from DBFW 
				where d3brn = @brn and d3typ = @m30typ and d3ref = @m30ref and d3bfd = @janfirst 
			end

			if @d7intp1 is null
			begin
				set @d7intp1  = 0
			end

			if @safeP4 is null
			begin
				set @safeP4  = 0
			end

			if @scn not in ('N', 'W')
			begin
				set @d8amti1 = @d8amti3
			end
	
		
			if @d2typ0  = 'L'
			begin
		
				set @m30amtDp4    =  @d8amtp4
				select @m30blcgDi = a1blcg2 from ACCT where a1brn = @brn and a1acc = @d8pl and a1sfx = @u1code

				set @pl = '99' + substring(cast(@d8pl as char(6)),3,4)
				if @d8ichr = 'D'
				begin
					set @m30amtDy2d    =  @d8amti1 - @d8amtp4

					set @m30amtDi1  = @d8amti1
	
					select @m30blcgDir = a1blcg2 from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code
				end
				else
				begin

	--				set @m30amtDy2d    =  @d8amti1 + @d7intp1 - @d8amtp4
					set @m30amtDy2d    =  @d8amti1 + @d7intp1 - @safeP4
					set @m30amtDi1     =  @d8amti1 
					select @m30blcgDir = a1blcg  from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code
				end

				set @m30amtCy2d = 0 
				set @m30amtCi1  = 0 
				set @m30amtCp4  = 0 
				set @m30blcgCi  = ' '  
				set @m30blcgCir = ' '
				set @a8Dpl      = @d8pl
				set @a8Cpl      = 0
				set @m30amtDtot = @d8tot
				set @m30amtCtot = 0

				set @m30rateD   = @m30rateD
				set @m30frqD    = @m30frqD
				set @m30rtD     = @m30rtD

				set @m30rateC   = 0
				set @m30frqC    = 0
				set @m30rtC     = 0

			end
			else
			begin
	--			set @m30amtCy2d   =  @d8amti1 + @d7intp1 - @d8amtp4
				set @m30amtCy2d   =  @d8amti1 + @d7intp1 - @safep4
				set @m30amtCi1    =  @d8amti1 
				set @m30amtCp4    =  @d8amtp4
				select @m30blcgCi = a1blcg   from ACCT where a1brn = @brn and a1acc = @d8pl and a1sfx = @u1code
				set @pl = '99' + substring(cast(@d8pl as char(6)),3,4)
			
				if @d8ichr = 'D'
				begin
					set @m30amtCy2d    =  @d8amti1 - @d8amtp4
				
					set @m30amtCi1 = @d8amti1			
				
					select @m30blcgCir = a1blcg from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code
				end
				else
				begin
	--				set @m30amtCy2d    =  @d8amti1 + @d7intp1 - @d8amtp4
					set @m30amtCy2d    =  @d8amti1 + @d7intp1 - @safep4
					set @m30amtCi1     =  @d8amti1 
					select @m30blcgCir = a1blcg2  from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code
				end

				set @m30amtDy2d = 0 
				set @m30amtDi1  = 0 
				set @m30amtDp4  = 0 
				set @m30blcgDi  = ' '  
				set @m30blcgDir = ' '
				set @a8Cpl      = @d8pl
				set @a8Dpl      = 0
				set @m30amtCtot = @d8tot
				set @m30amtDtot = 0

				set @m30rateC   = @m30rateD
				set @m30frqC    = @m30frqD
				set @m30rtC     = @m30rtD

				set @m30rateD   = 0

				set @m30frqD    = 0
				set @m30rtD     = 0

			end

			set @m8amtR = 0

			if ((@flag5 = ' ' and @d1arc = ' ') or @flag5 = 'E' )
			begin
				if @flag5 = ' ' 
				begin
				
					select @m8amtR = sum(m8amtR) - sum(m8amtP) 
					from DEAL
					join MVMT on d1brn = m8brn and d1typ = m8dtyp and d1ref = m8dref
					where d1brn  = @brn
					and   d1typ  = @m30typ
					and   d1ref  = @m30ref
					and   d1arc  = ' '  
					and   m8mvt  = 'P' 
					and   m8mvt2 = 'O' 
					and   m8pst  = 'N'
					and   m8sts  = ' '
					and   m8psd <= @p0date

					if @m8amtR is null 
					begin	
						set @m8amtR = 0
					end				

				end
				else
				begin
					if @m30lcd = @nbd 

					begin
						if @d8iacc = @d8dacc and  @d8isfx = @d8dsfx
						begin
			 	       			select

							 @d7net = d7intp1 
							from DINT
							JOIN DINP on d8brn = d7brn and d8typ = d7typ and d8ref = d7ref and d8seq = d7seq and d8lcd = d7cycd
							where d8brn  = @brn
							and   d8typ  = @m30typ
							and   d8ref  = @m30ref
					
							if @d7net is not null 

							begin
								set @m30amt = @m30amt - @d7net
							end

						end

						if @d7cycd is null
						begin
							set @d7cycd = 0
						end

						set @m30ncd = @m30lcd 
						set @m30lcd = @d7cycd
				
						if @m30lcd = 0 
						begin
							set @m30lcd = @m30std
						end

					end
	
				end
			
			end

			set @m30amt = @m30amt - @m8amtR

			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
					values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, @m30amt, @m30ccy, @m30std, @m30lcd, @m30ncd, @m30mtd, @m30amtDy2d, @m30amtDi1, @m30amtDp4, @a8Dpl, @m30amtDtot, @m30blcgDi, @m30blcgDir, @m30rtD, @m30rateD, @m30frqD, @m30holdD, @m30amtCy2d, @m30amtCi1, @m30amtCp4, @a8Cpl, @m30amtCtot, @m30blcgCi, @m30blcgCir, @m30rtC, @m30rateC, @m30frqC, @m30blcg, @m30code, @m30codel, @m30codex,@m30stage,@m30cstage,@m30restructured,0)
			if @@ERROR <> 0 
			begin
				print @m30ref + @m30typ
			end
		
			execute issp_ACCT_mark @brn, @m30acc, @m30sfx

			fetch Next from csr_VALL_build_DLTR Into
			 @m30brn
			,@m30acc
			,@m30sfx
			,@m30ccy
			,@m30blcg
			,@m30typ
			,@m30ref
			,@m30code
			,@m30codel
			,@m30codex
			,@m30amt
			,@d1arc
			,@m30std
			,@m30mtd
			,@m30lcd
			,@m30ncd
			,@d8dacc
			,@d8dsfx
			,@d8iacc
			,@d8isfx
			,@d8amti1
			,@d8amti3
			,@d8amtp4
			,@d8pl
			,@d2typ0
			,@d8ichr
			,@d8tot
			,@m30rateD
			,@m30frqD
			,@m30rtD
			,@m30stage
			,@m30cstage
			,@m30restructured

		end

		close csr_VALL_build_DLTR

		deallocate csr_VALL_build_DLTR

	---------------------------------------------------------------------------------------

	--step 5: DTAF (T&F deals)


		DECLARE csr_VALL_build_DTAF cursor for 	
		select
		 d1brn
		,d1acc
		,d1sfx
		,d1ccy
		,d1typ
		,d1ref
		,d1code
		,d1codel
		,d1codex
		,d11amt
		,d11ccont
		,d11blcgD
		,d11blcgC
		,u1code
		,d11std
		,d11mtd
		,d11tmd
		,d11stage
		,d11cstage
		from DTAF
		join DEAL on d1brn = d11brn and d1typ = d11typ and d1ref = d11ref
		join CCYS on d1ccy = u1ccy
		where d1brn  = @brn
		and   d1mnt  = 3
		and   d1arc  = ' ' 

		open csr_VALL_build_DTAF

		fetch Next from csr_VALL_build_DTAF Into
		 @m30brn
		,@m30acc
		,@m30sfx
		,@m30ccy
		,@m30typ
		,@m30ref
		,@m30code
		,@m30codel
		,@m30codex
		,@m30amt
		,@d11ccont
		,@d11blcgD
		,@d11blcgC
		,@u1code
		,@m30std
		,@d11mtd
		,@d11tmd
		,@m30stage
		,@m30cstage

		while @@Fetch_Status = 0

		begin
	
			if @d11mtd <> 0 and @d11mtd >= @d11tmd
			begin
				set @m30mtd = @d11mtd
			end

			if @d11tmd <> 0 and @d11tmd > @d11mtd
			begin
				set @m30mtd = @d11tmd
			end
		
			if @d11mtd = 0 and @d11tmd = 0
			begin
				set @m30mtd = 0
			end
 
			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc,   @m30sfx, @m30typ, @m30ref, -@m30amt, @m30ccy, @m30std, @m30std, @m30mtd, @m30mtd, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', @d11blcgD, @m30code, @m30codel, @m30codex,@m30stage,@m30cstage,0,0)
			execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx

			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @d11ccont, @u1code, @m30typ, @m30ref, @m30amt, @m30ccy, @m30std, @m30std, @m30mtd, @m30mtd, 0, 0, 0,  0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', @d11blcgC, 0, ' ', 0,@m30stage,@m30cstage,0,0)
			execute issp_ACCT_mark @m30brn, @d11ccont, @u1code

			fetch Next from csr_VALL_build_DTAF Into
			 @m30brn
			,@m30acc
			,@m30sfx
			,@m30ccy
			,@m30typ
			,@m30ref
			,@m30code
			,@m30codel
			,@m30codex
			,@m30amt
			,@d11ccont
			,@d11blcgD
			,@d11blcgC
			,@u1code
			,@m30std
			,@d11mtd
			,@d11tmd
			,@m30stage
			,@m30cstage	
		end

		close csr_VALL_build_DTAF

		deallocate csr_VALL_build_DTAF

	---------------------------------------------------------------------------------------

	--step 6: VDOC (Valuable Documents)


		DECLARE csr_VALL_build_VDOC cursor for 	
		select
		 d18brn
		,d18typ
		,d18ref
		,d18iaD
		,d18iaC
		,sum(d18amt)
		,d18ccy
		,d18blcgD
		,d18blcgC
		,u1code
		from VDOC
		join CCYS on d18ccy = u1ccy
		where d18brn  = @brn
		and   d18sts  = ' '
		group by d18brn, d18typ, d18ref, d18iaD, d18iaC, d18ccy, d18blcgD,d18blcgC,u1code


		open csr_VALL_build_VDOC

		fetch Next from csr_VALL_build_VDOC Into
		 @m30brn
		,@m30typ
		,@m30ref
		,@m30acc
		,@d11ccont
		,@m30amt
		,@m30ccy
		,@d11blcgD
		,@d11blcgC
		,@u1code

		while @@Fetch_Status = 0

		begin
	
			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc,   @u1code, @m30typ, @m30ref, -@m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', @d11blcgD, 0, ' ', 0,0,0,0,0)
			execute issp_ACCT_mark @m30brn, @m30acc, @u1code

			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
					values(@m30brn, @d11ccont, @u1code, @m30typ, @m30ref,  @m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', @d11blcgC, 0, ' ', 0,0,0,0,0)
			execute issp_ACCT_mark @m30brn, @d11ccont, @u1code

			fetch Next from csr_VALL_build_VDOC Into
			 @m30brn
			,@m30typ
			,@m30ref
			,@m30acc
			,@d11ccont
			,@m30amt
			,@m30ccy
			,@d11blcgD
			,@d11blcgC
			,@u1code

		end

		close csr_VALL_build_VDOC

		deallocate csr_VALL_build_VDOC



	--step 7: COMT (comitments)


		DECLARE csr_VALL_build_COMT cursor for 	
		select
		 d1brn
		,d1acc
		,d1sfx
		,d1ccy
		,d1blcg
		,d1typ
		,d1ref
		,d1code
		,d1codel
		,d1codex
		,d16amt
		,d1arc
		from DEAL
		join COMT on d1brn = d16brn and d1typ = d16typ and d1ref = d16ref
		join DTYP on d1typ = d2typ
		where d1brn  = @brn
		and   d1mnt  = 4
		and   d1sts not in ('V','C')
		and   d1arc  = ' '  

		open csr_VALL_build_COMT

		fetch Next from csr_VALL_build_COMT Into
		 @m30brn
		,@m30acc
		,@m30sfx
		,@m30ccy
		,@m30blcg
		,@m30typ
		,@m30ref
		,@m30code
		,@m30codel
		,@m30codex
		,@m30amt
		,@d1arc

		while @@Fetch_Status = 0

		begin
	
			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, -@m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', @m30blcg, 0, ' ', 0,0,0,0,0)
			execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx

			fetch Next from csr_VALL_build_COMT Into
			 @m30brn
			,@m30acc
			,@m30sfx
			,@m30ccy
			,@m30blcg
			,@m30typ
			,@m30ref
			,@m30code
			,@m30codel
			,@m30codex
			,@m30amt
			,@d1arc


		end

		close csr_VALL_build_COMT

		deallocate csr_VALL_build_COMT

	---------------------------------------------------------------------------------------

	--step 8: CMCP (Commercial Papers)

		DECLARE csr_VALL_build_CMCP cursor for 	
		select
		 d21brn
		,d21typ
		,d21ref
		,d21accD
		,d21accC
		,sum(d21Cqua * d21iprc) - sum(d21post)
		,d21ccy
		,d21blcgD
		,d21blcgC
		,u1code
		from CMCP
		join CCYS on d21ccy = u1ccy
		where d21brn  = @brn
		 and (d21post <> 0 or d21sts = 'O')
		group by d21brn, d21typ, d21ref, d21accD, d21accC, d21ccy, d21blcgD,d21blcgC, u1code

		open csr_VALL_build_CMCP

		fetch Next from csr_VALL_build_CMCP Into
		 @m30brn
		,@m30typ
		,@m30ref
		,@d11ccont
		,@m30acc
		,@m30amt
		,@m30ccy
		,@d11blcgD
		,@d11blcgC
		,@u1code

		while @@Fetch_Status = 0

		begin

			if @m30amt <> 0 
			begin
				insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @d11ccont, @u1code, @m30typ, @m30ref, -@m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', @d11blcgD, 0, ' ', 0,0,0,0,0)
				execute issp_ACCT_mark @m30brn, @d11ccont, @u1code
	
				insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc,   @u1code, @m30typ, @m30ref,  @m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', @d11blcgC, 0, ' ', 0,0,0,0,0)
				execute issp_ACCT_mark @m30brn, @m30acc, @u1code
			end


			fetch Next from csr_VALL_build_CMCP Into
			 @m30brn
			,@m30typ
			,@m30ref
			,@d11ccont
			,@m30acc
			,@m30amt
			,@m30ccy
			,@d11blcgD
			,@d11blcgC
			,@u1code
        	
		end

		close csr_VALL_build_CMCP

		deallocate csr_VALL_build_CMCP

	---------------------------------------------------------------------------------------

	--step 9: BONC (Securities)

		set @m30amtCy2d  = 0
		set @m30amtCtot  = 0

		DECLARE csr_VALL_build_BONC cursor for 	
		select
		 b2brn
		,b2typ
		,b2ref
		,d1acc
		,d1sfx
		,b2amtP
		,b2ccy
		,b2std

		,b2lcd
		,b2ncd
		,b2mtd
		,b2amti1
		,b2amtp4
		,b2plC
		,b2rateC
		,b2frqC
		,d1blcg
		,u1code

		from BONC
		join DEAL on d1brn = b2brn and d1typ = b2typ and d1ref = b2ref
		join CCYS on b2ccy = u1ccy
		where b2brn  = @brn
		 and  d1arc  = ' '

		open csr_VALL_build_BONC

		fetch Next from csr_VALL_build_BONC Into
		 @m30brn
		,@m30typ
		,@m30ref
		,@m30acc
		,@m30sfx
		,@m30amt
		,@m30ccy
		,@m30std
		,@m30lcd
		,@m30ncd
		,@m30mtd
		,@m30amtCi1
		,@m30amtCp4
		,@d8pl
		,@m30rateC
		,@m30frqC
		,@m30blcg
		,@u1code

		while @@Fetch_Status = 0

		begin

			if @m30amt <> 0 
			begin

				if @m30lcd = 0 
				begin
					set @m30lcd = @m30std
				end
	
				if @m30ncd = 99999999 
				begin
					set @m30ncd = @m30mtd
				end
	
				select @m30blcgCi = a1blcg   from ACCT where a1brn = @brn and a1acc = @d8pl and a1sfx = @u1code
				set @pl = '99' + substring(cast(@d8pl as char(6)),3,4)
				select @m30blcgCir = a1blcg from ACCT where a1brn = @m30brn and a1acc = @pl and a1sfx = @u1code

				insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, -@m30amt, @m30ccy, @m30std, @m30lcd, @m30ncd, @m30mtd, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, @m30amtCy2d, @m30amtCi1, @m30amtCp4, @d8pl, @m30amtCtot, @m30blcgCi, @m30blcgCir, @m30rateC, ' ', @m30frqC, @m30blcg, 0, ' ', 0,0,0,0,0)
				execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx
			end

			fetch Next from csr_VALL_build_BONC Into
			 @m30brn
			,@m30typ
			,@m30ref
			,@m30acc
			,@m30sfx
			,@m30amt
			,@m30ccy
			,@m30std
			,@m30lcd
			,@m30ncd
			,@m30mtd
			,@m30amtCi1
			,@m30amtCp4
			,@d8pl
			,@m30rateC
			,@m30frqC
			,@m30blcg
			,@u1code
        	
		end

		close csr_VALL_build_BONC

		deallocate csr_VALL_build_BONC

	---------------------------------------------------------------------------------------

	--step 10: BNDD (Bond Deals)

		DECLARE csr_VALL_build_BNDD cursor for 	
		select
		 d20brn
		,d20typ
		,d20ref
		,d1acc
		,d1sfx
		,case d20bs when 'B' then   d20Gamt
				when 'S' then  -d20Gamt	
		 end
		,d1ccy
		,d20vld
		,d20sld
		,d20plamt
		,d20plamt2
		,d1blcg

		from BNDD
		join DEAL on d1brn = d20brn and d1typ = d20typ and d1ref = d20ref
		where d20brn = @brn
		 and  d1arc  = ' '
		 and  d1mnt  = 3

		open csr_VALL_build_BNDD

		fetch Next from csr_VALL_build_BNDD Into
		 @m30brn
		,@m30typ
		,@m30ref
		,@m30acc
		,@m30sfx
		,@m30amt
		,@m30ccy
		,@m30std
		,@m30lcd
		,@m30amtCi1
		,@m30amtCp4
		,@m30blcg

		while @@Fetch_Status = 0

		begin

			if @m30amt <> 0 
			begin
				insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, @m30amt, @m30ccy, @m30std, @m30lcd, @m30std, @m30std, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, @m30amtCi1, @m30amtCp4, 0, 0, ' ', ' ', 0, ' ', ' ', @m30blcg, 0, ' ', 0,0,0,0,0)
				execute issp_ACCT_mark @m30brn, @m30acc, @m30sfx
			end

			fetch Next from csr_VALL_build_BNDD Into
			 @m30brn
			,@m30typ
			,@m30ref
			,@m30acc
			,@m30sfx
			,@m30amt
			,@m30ccy
			,@m30std
			,@m30lcd
			,@m30amtCi1
			,@m30amtCp4
			,@m30blcg
        	
		end

		close csr_VALL_build_BNDD

		deallocate csr_VALL_build_BNDD

	---------------------------------------------------------------------------------------

		--step 11: iz hesaplar (account semasindaki hesaplarin isuba karsiligi)

			delete ydsm.temp_rlevent_details
			insert into ydsm.temp_rlevent_details 
			select * from rlevent.journal_entry_detail_view where tdhp1 <> '294' and tdhp1 <> '295'

			delete ydsm.temp_ITRM
			insert into ydsm.temp_ITRM
			select * from ydsm.ITRM 

	    
			insert into ydsm.vall 
			select 
			  a1brn																-- m30brn
			 ,a1acc																-- m30acc
			 ,a1sfx																-- m30sfx
			 ,temp_ITRM.product_code													-- m30typ
			 ,RLVZG.m37dref														-- m30ref
			 ,temp_ITRM.balance_amount												-- m30amt
			 ,temp_ITRM.balance_currency												-- m30ccy
			 , cast(ISNULL(FORMAT(temp_ITRM.open_date, 'yyyyMMdd'),0) as int)        -- m30std
			 ,cast(ISNULL(FORMAT(temp_ITRM.last_cycle_date, 'yyyyMMdd'),0) as int)	-- m30lcd
			 ,cast(ISNULL(FORMAT(temp_ITRM.next_cycle_date, 'yyyyMMdd'),0) as int)	-- m30ncd
			 ,cast(ISNULL(FORMAT(temp_ITRM.close_date, 'yyyyMMdd'),0) as int)		-- m30mtd
			 ,0																	-- m30amtDy2d
			 ,0																	-- m30amtDi1
			 ,0																	-- m30amtDp4
			 ,0																	-- m30pld
			 ,0																	-- m30amtDtot
			 ,''																-- m30blcgDi
			 ,''																-- m30blcgDir
			 ,''																-- m30rtD
			 ,0																	-- m30rateD
			 ,''																-- m30frqd
			 ,0																	-- m30holdD
			 ,ABS(ISNULL(YP.balance_amount,0))									-- m30amtCy2d 
			 ,ISNULL(YI.balance_amount,0)                                       -- m30amtci1,
			 ,temp_ITRM.not_posted_previous_years_interest_amount                    -- m30amtcp4
			 ,0																	-- m30plc
			 ,temp_ITRM.total_interest_posted_amount									-- m30amtcTot
			 ,ISNULL(YP.tdhp1,'')												-- m30blcgCi
			 ,ISNULL(YI.tdhp1,'')												-- m30blcgCir
			 ,''																-- m30rtc
			 ,temp_ITRM.resulting_rate												-- m30rateC
			 ,''																-- m30frqc
			 ,temp_ITRM.tdhp1														-- m30blcg
			 ,0      															-- m30code
			 ,0																	-- m30codeI
			 ,0																	-- m30codeX
			 ,0																--m30stage
			 ,0																--m30cstage
			 ,0																--m30restructured
			 ,0																--m30a1sumadj	
			 from
			(
			select m37brna,m37acc,m37sfx,m37ccy,m37dref,sum(m37amt) as amount from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy,m37dref
			) RLVZG join  temp_ITRM  on m37brna = owning_unit_code and m37acc=customer_number and m37sfx = account_suffix and m37dref=reference
			left join ydsm.temp_ITRM YI on temp_ITRM.reference=YI.reference and YI.account_type='YI'
			left join ydsm.temp_ITRM YP on temp_ITRM.reference=YP.reference and YP.account_type='YP' and YP.profit_account_nature = 2
			join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			 where a1brn  = @brn
			--and   TAV.is_closed=0  --(kar zarar hesabi halen dahaacik burayi acinca onlar vall a yansimiyor)
			and a1atyp in ('DA','DB','DP')


			--kar zarar hesaplari base ve original currency
			insert into ydsm.vall 
			select 
			  a1brn    --m30brn
			  ,a1acc   --m30acc
			 ,a1sfx    --m30sfx
			 ,temp_ITRM.product_code   --m30typ
			 ,RLVZG.m37dref       --m30ref
			 --,CASE a1atyp WHEN 'YI' THEN temp_ITRM.balance_amount-ISNULL(DP.not_posted_previous_years_interest_amount,0) 
			 --             ELSE temp_ITRM.balance_amount END AS m30amt -- m30amt
			 ,amount  --temp_ITRM.balance_amount
			 ,a1ccy ---temp_ITRM.balance_currency  --m30ccy
			 ,(select top 1 p0date from ydsm.brnc) --m30std
			 ,0										--m30lcd
			 ,(select top 1 p0date from ydsm.brnc)  --m30ncd
			 ,(select top 1 p0date from ydsm.brnc)   --m30mtd
			 ,0  --m30amtDy2d
			 ,0  --m30amtDi1,
			 ,0  --m30amtDp4
			 ,0  --m30pld
			 ,0  --m30amtDtot
			 ,'' -- m30blcgDi
			 ,'' --m30blcgDir
			 ,'' --m30rtD
			 ,0  --m30rateD
			 ,'' --m30frqd
			 ,0  --m30holdD
			 ,0  --m30amtCy2d  ??
			 ,0--ISNULL(-DP.last_cycle_to_next_business_interest_amount,0)  --m30amtci1,
			 ,0 --m30amtcp4
			 ,0  -- m30plc
			 ,0 -- m30amtcTot
			 ,0-- m30blcgCi
			 ,0 -- m30blcgCir
			 ,''        -- m30rtc
			 ,0-- m30rateC
			 ,''        --m30frqc
			 ,temp_ITRM.tdhp1  -- m30blcg
			 ,0      ---m30code
			 ,0      --m30codeI
			 ,0      --m30codeX
			 ,0																--m30stage
			 ,0																--m30cstage
			 ,0																--m30restructured
		 			 ,0																--m30a1sumadj	
			 from
			(
			select m37brna,m37acc,m37sfx,m37ccy,m37dref,sum(m37amt) as amount from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy,m37dref
			) RLVZG join  temp_ITRM  on m37brna = owning_unit_code and m37acc=customer_number and m37sfx = account_suffix and m37dref=reference
			--left join ydsm.temp_ITRM DP on temp_ITRM.reference=DP.reference and DP.account_type in ('DA','DB','DP')
			join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			 where a1brn  = @brn
			and a1atyp in ('YP') and temp_ITRM.profit_account_nature in (2,8)


			--gecen yila ait kar zarar hesaplari base ve original currency
			DECLARE V000_056_000_040V000_047_000_028VALL_build_Projection_Account_lastyear_profit_account cursor for
        

			select a1brn,a1acc,a1sfx,temp_ITRM.product_code,RLVZG.m37dref,amount,a1ccy,temp_ITRM.tdhp1 from 
			(
			select m37brna,m37acc,m37sfx,m37ccy,m37dref,sum(m37amt) as amount from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy,m37dref
			) RLVZG join  temp_ITRM  on m37brna = owning_unit_code and m37acc=customer_number and m37sfx = account_suffix and m37dref=reference
			--left join ydsm.temp_ITRM DP on temp_ITRM.reference=DP.reference and DP.account_type in ('DA','DB','DP')
			join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			where a1brn  = @brn
			and a1atyp in ('YP') and temp_ITRM.profit_account_nature in (1,7)


			open V000_056_000_040V000_047_000_028VALL_build_Projection_Account_lastyear_profit_account
		
			fetch Next from V000_056_000_040V000_047_000_028VALL_build_Projection_Account_lastyear_profit_account Into
			 @m30brn
			,@m30acc
			,@m30sfx
			,@m30typ
			,@m30ref
			,@m30amt
			,@m30ccy
			,@m30blcg

			while @@Fetch_Status = 0

			begin
    
						set @m30std = (select top 1 p0date from ydsm.brnc) 
						delete from vall where m30brn=@m30brn and m30acc=@m30acc and m30sfx=@m30sfx and m30ref=@m30ref and m30typ=@m30typ and m30blcg like '6%'
                    
						insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
								  values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, @m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', '',0, ' ', @m30blcg, 0, ' ', 0,0,0,0,0) 

						fetch Next from V000_056_000_040V000_047_000_028VALL_build_Projection_Account_lastyear_profit_account Into
			 @m30brn
			,@m30acc
			,@m30sfx
			,@m30typ
			,@m30ref
			,@m30amt
			,@m30ccy
			,@m30blcg
       
	   
		   end
	   
		   close V000_056_000_040V000_047_000_028VALL_build_Projection_Account_lastyear_profit_account
	   
		   deallocate V000_056_000_040V000_047_000_028VALL_build_Projection_Account_lastyear_profit_account
				   


			--gecen yila ait kar zarar hesaplari base ve original currency
			--insert into ydsm.vall 
			--select 
			--  a1brn    --m30brn
			--  ,a1acc   --m30acc
			-- ,a1sfx    --m30sfx
			-- ,''   --m30typ
			-- ,RLVZG.m37dref       --m30ref
			-- --,CASE a1atyp WHEN 'YI' THEN temp_ITRM.balance_amount-ISNULL(DP.not_posted_previous_years_interest_amount,0) 
			-- --             ELSE temp_ITRM.balance_amount END AS m30amt -- m30amt
			-- ,amount  --temp_ITRM.balance_amount
			-- ,a1ccy ---temp_ITRM.balance_currency  --m30ccy
			-- ,(select top 1 p0date from ydsm.brnc) --m30std
			-- ,0										--m30lcd
			-- ,(select top 1 p0date from ydsm.brnc)  --m30ncd
			-- ,(select top 1 p0date from ydsm.brnc)   --m30mtd
			-- ,0  --m30amtDy2d
			-- ,0  --m30amtDi1,
			-- ,0  --m30amtDp4
			-- ,0  --m30pld
			-- ,0  --m30amtDtot
			-- ,'' -- m30blcgDi
			-- ,'' --m30blcgDir
			-- ,'' --m30rtD
			-- ,0  --m30rateD
			-- ,'' --m30frqd
			-- ,0  --m30holdD
			-- ,0  --m30amtCy2d  ??
			-- ,0--ISNULL(-DP.last_cycle_to_next_business_interest_amount,0)  --m30amtci1,
			-- ,0 --m30amtcp4
			-- ,0  -- m30plc
			-- ,0 -- m30amtcTot
			-- ,0-- m30blcgCi
			-- ,0 -- m30blcgCir
			-- ,''        -- m30rtc
			-- ,0-- m30rateC
			-- ,''        --m30frqc
			-- ,temp_ITRM.tdhp1  -- m30blcg
			-- ,0      ---m30code
			-- ,0      --m30codeI
			-- ,0      --m30codeX
			-- ,0																--m30stage
			-- ,0																--m30cstage
			-- ,0																--m30restructured
			-- 		 ,0																--m30a1sumadj	
			-- from
			--(
			--select m37brna,m37acc,m37sfx,m37ccy,m37dref,sum(m37amt) as amount from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy,m37dref
			--) RLVZG join  temp_ITRM  on m37brna = owning_unit_code and m37acc=customer_number and m37sfx = account_suffix and m37dref=reference
			----left join ydsm.temp_ITRM DP on temp_ITRM.reference=DP.reference and DP.account_type in ('DA','DB','DP')
			--join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			-- where a1brn  = @brn
			--and a1atyp in ('YP') and temp_ITRM.profit_account_nature in (1,7)


			insert into ydsm.vall 
			select 
			  a1brn    --m30brn
			  ,a1acc   --m30acc
			 ,a1sfx    --m30sfx	
			 ,temp_ITRM.product_code    --m30typ
			 ,RLVZG.m37dref       --m30ref
			 --,CASE a1atyp WHEN 'YI' THEN temp_ITRM.balance_amount-ISNULL(DP.not_posted_previous_years_interest_amount,0) 
			 --             ELSE temp_ITRM.balance_amount END AS m30amt -- m30amt
			 ,temp_ITRM.balance_amount
			 ,temp_ITRM.balance_currency  --m30ccy
			 ,(select top 1 p0date from ydsm.brnc) --m30std
			 ,0										--m30lcd
			 ,(select top 1 p0date from ydsm.brnc)  --m30ncd
			 ,(select top 1 p0date from ydsm.brnc)   --m30mtd
			 ,0  --m30amtDy2d
			 ,0  --m30amtDi1,
			 ,0  --m30amtDp4
			 ,0  --m30pld
			 ,0  --m30amtDtot
			 ,'' -- m30blcgDi
			 ,'' --m30blcgDir
			 ,'' --m30rtD
			 ,0  --m30rateD
			 ,'' --m30frqd
			 ,0  --m30holdD
			 ,0  --m30amtCy2d  ??
			 ,0  --m30amtci1,
			 ,0 --m30amtcp4
			 ,0  -- m30plc
			 ,0 -- m30amtcTot
			 ,0-- m30blcgCi
			 ,0 -- m30blcgCir
			 ,''        -- m30rtc
			 ,0-- m30rateC
			 ,''        --m30frqc
			 ,temp_ITRM.tdhp1  -- m30blcg
			 ,0      ---m30code
			 ,0      --m30codeI
			 ,0      --m30codeX
			 ,0																--m30stage
			 ,0																--m30cstage
			 ,0																--m30restructured
		 			 ,0																--m30a1sumadj	
			 from
			(
			select m37brna,m37acc,m37sfx,m37ccy,m37dref,sum(m37amt) as amount from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy,m37dref
			) RLVZG join  temp_ITRM  on m37brna = owning_unit_code and m37acc=customer_number and m37sfx = account_suffix and m37dref=reference
			--left join ydsm.temp_ITRM DP on temp_ITRM.reference=DP.reference and DP.account_type in ('DA','DB','DP')
			join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			 where a1brn  = @brn
			and a1atyp in ('YI')

			insert into ydsm.vall 
			select 
			  a1brn    --m30brn
			  ,a1acc   --m30acc
			 ,a1sfx    --m30sfx
			 ,''   --m30typ
			 ,RLVZG.m37dref       --m30ref
			 --,CASE a1atyp WHEN 'YI' THEN temp_ITRM.balance_amount-ISNULL(DP.not_posted_previous_years_interest_amount,0) 
			 --             ELSE temp_ITRM.balance_amount END AS m30amt -- m30amt
			 ,temp_ITRM.balance_amount
			 ,temp_ITRM.balance_currency  --m30ccy
			 ,(select top 1 p0date from ydsm.brnc) --m30std
			 ,0										--m30lcd
			 ,(select top 1 p0date from ydsm.brnc)  --m30ncd
			 ,(select top 1 p0date from ydsm.brnc)   --m30mtd
			 ,0  --m30amtDy2d
			 ,0  --m30amtDi1,
			 ,0  --m30amtDp4
			 ,0  --m30pld
			 ,0  --m30amtDtot
			 ,'' -- m30blcgDi
			 ,'' --m30blcgDir
			 ,'' --m30rtD
			 ,0  --m30rateD
			 ,'' --m30frqd
			 ,0  --m30holdD
			 ,0  --m30amtCy2d  ??
			 ,0  --m30amtci1,
			 ,0 --m30amtcp4
			 ,0  -- m30plc
			 ,0 -- m30amtcTot
			 ,0-- m30blcgCi
			 ,0 -- m30blcgCir
			 ,''        -- m30rtc
			 ,0-- m30rateC
			 ,''        --m30frqc
			 ,temp_ITRM.tdhp1  -- m30blcg
			 ,0      ---m30code
			 ,0      --m30codeI
			 ,0      --m30codeX
			 ,0																--m30stage
			 ,0																--m30cstage
			 ,0																--m30restructured
		 			 ,0																--m30a1sumadj	
			 from
			(
			select m37brna,m37acc,m37sfx,m37ccy,m37dref,sum(m37amt) as amount from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy,m37dref
			) RLVZG join  temp_ITRM  on m37brna = owning_unit_code and m37acc=customer_number and m37sfx = account_suffix and m37dref=reference
			--left join ydsm.temp_ITRM DP on temp_ITRM.reference=DP.reference and DP.account_type in ('DA','DB','DP')
			join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			 where a1brn  = @brn
			and a1atyp in ('YK')

			DECLARE csr_VALL_build_Projection_Account cursor for
		

			select a1brn,'',a1acc,a1sfx,a1bal+a1sumc+a1sumd,a1ccy,a1blcg,'' from 
			(
			select m37brna,m37acc,m37sfx,m37ccy from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy
			) RLVZG join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			where a1atyp='SA' and a1brn=@brn
	
		open csr_VALL_build_Projection_Account

		fetch Next from csr_VALL_build_Projection_Account Into
		 @m30brn
		 ,@m30ref
		,@m30acc
		,@m30sfx
		,@m30amt
		,@m30ccy
		,@m30blcg
		,@m30typ
	

		while @@Fetch_Status = 0

		begin
               
			set @safeP4 = 0
			set @m30amtCi1 =0
			set @m30amtCp4 = 0
		
			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, @m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', '',0, ' ', @m30blcg, 0, ' ', 0,0,0,0,0) 

			fetch Next from csr_VALL_build_Projection_Account Into
		 @m30brn
		 ,@m30ref
		,@m30acc
		,@m30sfx
		,@m30amt
		,@m30ccy
		,@m30blcg
		,@m30typ
	

		end

		close csr_VALL_build_Projection_Account

		deallocate csr_VALL_build_Projection_Account



		DECLARE csr_VALL_build_Tax_Collection_Account cursor for
		

			select a1brn,'',a1acc,a1sfx,a1bal+a1sumc+a1sumd,a1ccy,a1blcg,'' from 
			(
			select m37brna,m37acc,m37sfx,m37ccy from ydsm.rlvz group by m37brna,m37acc,m37sfx,m37ccy
			) RLVZG join acct on a1brn=m37brna and a1acc=m37acc and a1sfx=m37sfx
			where a1atyp='YK' and a1brn=@brn and m37acc = 913000
	
		open csr_VALL_build_Tax_Collection_Account

		fetch Next from csr_VALL_build_Tax_Collection_Account Into
		 @m30brn
		 ,@m30ref
		,@m30acc
		,@m30sfx
		,@m30amt
		,@m30ccy
		,@m30blcg
		,@m30typ
	
		while @@Fetch_Status = 0

		begin
               
			set @safeP4 = 0
			set @m30amtCi1 =0
			set @m30amtCp4 = 0
		
			insert into VALL(m30brn,m30acc,m30sfx,m30typ,m30ref,m30amt,m30ccy,m30std,m30lcd,m30ncd,m30mtd,m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
						 values(@m30brn, @m30acc, @m30sfx, @m30typ, @m30ref, @m30amt, @m30ccy, @p0date, @p0date, @p0date, @p0date, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', '',0, ' ', @m30blcg, 0, ' ', 0,0,0,0,0) 

			fetch Next from csr_VALL_build_Tax_Collection_Account Into
		 @m30brn
		 ,@m30ref
		,@m30acc
		,@m30sfx
		,@m30amt
		,@m30ccy
		,@m30blcg
		,@m30typ
	
		end

		close csr_VALL_build_Tax_Collection_Account

		deallocate csr_VALL_build_Tax_Collection_Account

		Update ydsm.acct set a1gl = 1 from ydsm.acct join ydsm.rlvz on a1brn = m37brna and a1acc = m37acc and a1sfx = m37sfx
	  END
GO

