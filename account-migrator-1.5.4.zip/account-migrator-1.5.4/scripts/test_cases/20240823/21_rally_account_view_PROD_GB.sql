USE [rallyGB]
GO

/****** Object:  View [rally].[account_view]    Script Date: 22/08/2024 09:29:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [rally].[account_view]
AS
select
CASE WHEN len(a1.a1brn)>3 THEN CAST(CAST(a1.a1brn as NCHAR(4)) + '-' + RIGHT('000000'+ CAST(a1.a1acc as NVARCHAR(6)),6) + '-' + RIGHT('000'+ CAST(a1.a1sfx as NVARCHAR(3)),3) as nvarchar(255))
ELSE CAST('0' + CAST(a1.a1brn as NCHAR(3)) + '-' + RIGHT('000000'+ CAST(a1.a1acc as NVARCHAR(6)),6) + '-' + RIGHT('000'+ CAST(a1.a1sfx as NVARCHAR(3)),3) as nvarchar(255))
END as account_number
,CAST(a1.a1IbanNo as nvarchar(255)) as account_iban
,CAST(a2.a2str as nvarchar(255)) as account_structure
,CAST(a2.a2str2 as nvarchar(255)) as account_structure2
,CAST(a1.a1sadr as nvarchar(255)) as statement_address
,Account_Type.id as account_type
,Currency.id as account_currency
,Currency.mnemonic as currency_mnemonic
,Customer.id as customer
,Customer.customer_number as customer_number
,CAST(a1.a1snm as nvarchar(255)) as account_name
,System_Branch.id as account_branch
,CASE WHEN a1.a1oexd < CONVERT ( varchar(8) ,System_Branch.operating_date , 112) THEN a1.a1bal + a1.a1sumc + a1.a1sumd - a1.a1sum1 - a1.a1sum2 - a1.a1bbal  ELSE a1.a1bal + a1.a1sumc + a1.a1sumd - a1.a1sum1 - a1.a1sum2 - a1.a1bbal - a1.a1obal end  as available_balance
,a1.a1bal + a1.a1sumC + a1.a1sumD as balance
,a1.a1bbal as blocked_balance
,(a1.a1obal * (-1)) as overdraft_limit

,CAST(CASE WHEN a1.[a1blc] = 'Y' THEN 1 ELSE 0 END as smallint) as  is_blocked
,CAST(CASE WHEN a1.[a1cls] = 'Y' THEN 1 ELSE 0 END as smallint) as  is_closed
,CAST(CASE WHEN a1.[a1ina] = 'Y' THEN 1 ELSE 0 END as smallint) as  is_inactive

,CASE WHEN a1.[a1obal] <> 0 THEN
(select MIN(CAST(SUBSTRING(CAST(drrt.a4chd as CHAR(8)),1,4)+'-'+SUBSTRING( CAST(drrt.a4chd as CHAR(8)),5,2)+'-'+SUBSTRING( CAST(drrt.a4chd as CHAR(8)),7,2)+' 00:00:00' as datetime))
from ydsm.drrt as drrt where drrt.a4brn = a1.[a1brn]
and  drrt.a4acc = a1.[a1acc]
and drrt.a4sfx = a1.[a1sfx])
ELSE NULL END as overdraft_create_date

,CASE WHEN a1.a1oexd in (0, 99999999) THEN null ELSE CAST(SUBSTRING(CAST(a1.a1oexd as CHAR(8)),1,4)+'-'+SUBSTRING( CAST(a1.a1oexd as CHAR(8)),5,2)+'-'+SUBSTRING( CAST(a1.a1oexd as CHAR(8)),7,2)+' 00:00:00' as datetime) END as overdraft_expire_date
,CASE WHEN a1.a1crd = 0 THEN null ELSE CAST(SUBSTRING(CAST(a1.a1crd as CHAR(8)),1,4)+'-'+SUBSTRING( CAST(a1.a1crd as CHAR(8)),5,2)+'-'+SUBSTRING( CAST(a1.a1crd as CHAR(8)),7,2)+' 00:00:00' as datetime) END as effective_date
,CASE WHEN a1.a1cld in (0, 99999999) THEN null ELSE CAST(SUBSTRING(CAST(a1.a1cld as CHAR(8)),1,4)+'-'+SUBSTRING( CAST(a1.a1cld as CHAR(8)),5,2)+'-'+SUBSTRING( CAST(a1.a1cld as CHAR(8)),7,2)+' 00:00:00' as datetime) END as end_date
,CASE WHEN a1.a1lmd = 0 THEN null ELSE CAST(SUBSTRING(CAST(a1.a1lmd as CHAR(8)),1,4)+'-'+SUBSTRING( CAST(a1.a1lmd as CHAR(8)),5,2)+'-'+SUBSTRING( CAST(a1.a1lmd as CHAR(8)),7,2)+' 00:00:00' as datetime) END as information_date

,a1.id as id
,CAST(0 as int) as version
,CAST(1 as bigint) as initiated_by
,CAST('0:0:0:0:0:0:0:1' as nvarchar(255)) as from_computer
,CAST(1 as bigint) as approved_by
,CAST('2013-12-24 10:11:35' as datetime) as approval_date
,a1.a1blcg as debit_tdhp
,a1.a1blcg2 as credit_tdhp
,system_branch.code as account_branch_code
,Account_Type.code as type_code
from 
(select CAST(ROW_NUMBER() OVER (ORDER BY a1brn,a1acc,a1sfx) as bigint) as id, *
from ydsm.ACCT) a1 
JOIN rally.currency Currency on Currency.mnemonic = a1.[a1ccy]
JOIN rally.system_branch System_Branch on System_Branch.code = a1.[a1brn]
JOIN rally.account_type Account_Type on Account_Type.code = a1.[a1atyp]
LEFT OUTER JOIN rally.customer Customer on Customer.customer_number = a1.[a1acc]
JOIN ydsm.ATYP a2 on a2.a2mne = a1.[a1atyp]
LEFT OUTER JOIN ydsm.espa on a1brn = a22brn and a1acc = a22acc and a1sfx = a22sfx 
where (select string_value from rally.preference where mnemonic = 'LIST_ESPA_ACCOUNTS' )='true' or a22brn is null or a22acc > 900000

GO


