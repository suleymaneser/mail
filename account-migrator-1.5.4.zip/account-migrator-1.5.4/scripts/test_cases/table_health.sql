EXEC tSQLt.NewTestClass 'TableHealth';
GO

CREATE PROCEDURE TableHealth.[test that (T1) customer_account_definition table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.customer_account_definition)
    PRINT 'Record count of   customer_account_definition table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T3) delinquent_loan_account table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.delinquent_loan_account)
    PRINT 'Record count of   delinquent_loan_account table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
/*CREATE PROCEDURE TableHealth.[test that (T4) accounting_idempotency table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.accounting_idempotency)
    PRINT 'Record count of   accounting_idempotency table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO*/
CREATE PROCEDURE TableHealth.[test that (T5) internal_account_definition table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.internal_account_definition)
    PRINT 'Record count of   internal_account_definition table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T9) loan_account table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.loan_account)
    PRINT 'Record count of   loan_account table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T11) nostro_account table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.nostro_account)
    PRINT 'Record count of   nostro_account table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T13) term_account table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.term_account)
    PRINT 'Record count of   term_account table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
/*CREATE PROCEDURE TableHealth.[test that (T14) account table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.account)
    PRINT 'Record count of   account table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO*/
CREATE PROCEDURE TableHealth.[test that (T23) account_statement table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.account_statement)
    PRINT 'Record count of   account_statement table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T28) account_type table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.account_type)
    PRINT 'Record count of   account_type table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
/*CREATE PROCEDURE TableHealth.[test that (T31) external_account table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.external_account)
    PRINT 'Record count of   external_account table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO*/
CREATE PROCEDURE TableHealth.[test that (T32) base_component_deposit_possible_from_account_types table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.base_component_deposit_possible_from_account_types)
    PRINT 'Record count of   base_component_deposit_possible_from_account_types table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T35) base_component_withdrawal_possible_to_account_types table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.base_component_withdrawal_possible_to_account_types)
    PRINT 'Record count of   base_component_withdrawal_possible_to_account_types table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T37) account_owner table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_owner)
    PRINT 'Record count of   account_owner table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T40) account_balance table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_balance)
    PRINT 'Record count of   account_balance table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T41) account_blockage table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_blockage)
    PRINT 'Record count of   account_blockage table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T42) account_contract table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_contract)
    PRINT 'Record count of   account_contract table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T43) account_definition table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_definition)
    PRINT 'Record count of   account_definition table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T44) account_event_history table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.account_event_history)
    PRINT 'Record count of   account_event_history table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T45) collateral_chart_of_account_mapping table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.collateral_chart_of_account_mapping)
    PRINT 'Record count of   collateral_chart_of_account_mapping table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T46) account_event_history_amendment table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_event_history_amendment)
    PRINT 'Record count of   account_event_history_amendment table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T47) account_interest_calculation table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_interest_calculation)
    PRINT 'Record count of   account_interest_calculation table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T48) account_interest_definition table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_interest_definition)
    PRINT 'Record count of   account_interest_definition table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T49) account_interest_rate_history table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_interest_rate_history)
    PRINT 'Record count of   account_interest_rate_history table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T50) account_ledger_balance_history table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_ledger_balance_history)
    PRINT 'Record count of   account_ledger_balance_history table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
-- statement.account_statement_definition does not exists
--CREATE PROCEDURE TableHealth.[test that (T53) account_statement_definition table have records]
--AS
--BEGIN
--    DECLARE @actual int;
--    DECLARE @expected int;
--    SET @expected=0
--    SET @actual=(SELECT COUNT(*) FROM statement.account_statement_definition)
--    PRINT 'Record count of   account_statement_definition table .... ' + STR(ISNULL(@actual,0))
--    EXEC tSQLt.AssertNotEquals @expected, @actual;
--END;
--GO
CREATE PROCEDURE TableHealth.[test that (T56) chart_of_account_book_definition table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM rally.chart_of_account_book_definition)
    PRINT 'Record count of   chart_of_account_book_definition table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T57) account_value_dated_balance_history table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.account_value_dated_balance_history)
    PRINT 'Record count of   account_value_dated_balance_history table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
CREATE PROCEDURE TableHealth.[test that (T62) current_account table have records]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;
    SET @expected=0
    SET @actual=(SELECT COUNT(*) FROM account.current_account)
    PRINT 'Record count of   current_account table .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO
