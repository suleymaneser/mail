	--account without account_balance
	select count(*) as result from accountcore.account a
	left join accountcore.account_balance ab on a.balance=ab.id
	where ab.id is null
	union
	--account_balance without account
	select count(*) from accountcore.account a
	right join accountcore.account_balance ab on a.balance=ab.id
	where a.balance is null
	union
	--account_balance without account
	select count(*) from accountcore.account_balance
	where account_id is null or account_id=0
	union
	--account_balance invalid link with account
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	where a.id<>ab.account_id
	union
	--account without account_type
	select count(*) from accountcore.account a
	left join accountcore.account_type act on a.account_type=act.id
	where act.id is null
	union
	--account without customer_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.customer_account ca on a.id=ca.id
	where ca.id is null and act.is_internal=0
	union
	--customer_account without account
	select count(*) from accountcore.account a
	right join accountcore.customer_account ca on a.id=ca.id
	where a.id is null
	union
	--account without internal_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.internal_account ia on a.id=ia.id
	where ia.id is null and act.is_internal=1
	union
	--internal_account without account
	select count(*) from accountcore.account a
	right join accountcore.internal_account ia on a.id=ia.id
	where a.id is null
	union
	--customer_account without account_owner
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_owner ao on ao.account=ca.id
	where ao.account is null
	union
	--account_owner without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_owner ao on ao.account=ca.id
	where ca.id is null
	union
	--customer_account without account_contract
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_contract ac on ac.id=ca.contract
	where ac.id is null
	union
	--account_contract without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_contract ac on ac.id=ca.contract
	where ca.contract is null
	union
	--transaction that does not have zero sum
	select count(*) from (
		select transaction_id, sum(transaction_amount) as sum_all from accountcore.monetary_transaction_item 
		group by transaction_id having sum(transaction_amount) <> 0
	) temp_monetary_transaction_item
	union
	-- account balance that is not zero has monetary_transaction_item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	left join accountcore.monetary_transaction_item mti on mti.account=a.id
	where ab.balance_amount<>0 and mti.account is null
	union
	-- account balance that does not match with monetary transaction item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	join (
		select account, sum(transaction_amount) as sum_of_account from accountcore.monetary_transaction_item group by account
	) temp_monetary_transaction_item on a.id=temp_monetary_transaction_item.account
	where ab.balance_amount<>temp_monetary_transaction_item.sum_of_account
	union
	--  monetary transaction item with invalid side info
	select count(*) from accountcore.monetary_transaction_item where side not in ('DEBIT', 'CREDIT')
	union
	-- DEBIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='DEBIT' and transaction_amount>=0
	union
	-- CREDIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='CREDIT' and transaction_amount<=0
	union
	-- account_value_dated_balance_history without monetary_transaction_item
	select count(*) from accountcore.account_value_dated_balance_history a
	left join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where  temp_monetary_transaction_item.account is null
	union
	-- monetary_transaction_item without account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	right join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where a.date is null
	union
	-- unequal monetary_transaction_item and account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	join (
		select account, value_date, sum(sum_of_transaction_amount) OVER (partition by account order by account, value_date) as daily_sum from(
			select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
		) temp
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where daily_sum<>value_dated_balance_amount








		--account without letter_of_guarantee
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join noncashloan.letter_of_guarantee lg on a.number=lg.number
	where lg.number is null and act.code in ('RE', 'R9', 'RX')
	union
	--letter_of_guarantee without account
	select count(*) from accountcore.account a
	right join noncashloan.letter_of_guarantee lg on a.number=lg.number
	where a.number is null
	union
