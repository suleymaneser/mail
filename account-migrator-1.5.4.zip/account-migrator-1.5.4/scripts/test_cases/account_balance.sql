PRINT '*****************************************************************************************************'
PRINT '***                          AccountBalance Migration Tests                                       ***'
PRINT '*****************************************************************************************************'

EXEC tSQLt.NewTestClass 'AccountBalance';
GO

/* Financials */

CREATE PROCEDURE AccountBalance.[test that sum of balances of account_balance for type field and ACCT for a1atyp field with join are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT SUM(balance_amount) FROM account.[account_definition] adfn INNER JOIN account.account_balance On account_balance.id = adfn.balance INNER JOIN rally.[account_type] atyp on adfn.[type] = atyp.[id] WHERE atyp.[code] IN (SELECT a1.a1atyp FROM ydsm.[ACCT] a1 INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND a2.a2qrng <> 'I'))
	PRINT 'Sum of Balance of [account_balance] Table with join ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(a1bal+a1sumc+a1sumd) FROM ydsm.[ACCT] a1 join ydsm.ATYP a2 on a1.a1atyp = a2.a2mne where a2.a2deal <> 'Y' AND NOT (a2.a2qrng = 'I' and a2.a2str='F' and a2.a2str2='G'))
	PRINT 'Sum of Balance of [ACCT] Table with join ................. ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that sum of balances of account_balance for type field and ACCT for a1atyp field for specified account types are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT SUM(balance_amount) FROM account.[account_definition] ad INNER JOIN account.account_balance On account_balance.id = ad.balance  INNER JOIN rally.[account_type] at on ad.[type] = at.[id] WHERE at.[code] IN ('B5','CA','CB','CN','DJ','EA','RM','RP','RT'))
	PRINT 'Sum of Balance of [account_balance] Table for code in (B5,CA,CB,CN,DJ,EA,RM,RP,RT) ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(a1bal+a1sumc+a1sumd) FROM ydsm.[ACCT] WHERE [a1atyp] IN ('B5','CA','CB','CN','DJ','EA','RM','RP','RT'))
	PRINT 'Sum of Balance of [ACCT] Table for a1atyp in (B5,CA,CB,CN,DJ,EA,RM,RP,RT) ............... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that sum of balances of account_balance and ACCT/DEAL/DLFX/DLTR are equal]
AS
BEGIN
        DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);
	DECLARE @expected_ACCT DECIMAL(38,2);
	DECLARE @expected_DLTR DECIMAL(38,2);    
	DECLARE @expected_DLFX DECIMAL(38,2);
	DECLARE @expected_DTAF DECIMAL(38,2);

    DECLARE @actual_count INT;
	DECLARE @expected_count INT;
	DECLARE @ACCTcount INT;
    DECLARE @DLTRcount INT;
    DECLARE @DLFXcount INT;    
    DECLARE @DTAFcount INT;

    SET @actual=(SELECT SUM(balance_amount) FROM account.[account_definition] INNER JOIN account.account_balance On account_balance.id = [account_definition].balance)
	SET @actual_count=(SELECT COUNT(*) FROM account.[account_definition] INNER JOIN account.account_balance On account_balance.id = [account_definition].balance)
	PRINT 'Sum of Balance of [account_balance] Table ............ ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	PRINT 'Count Record of Balance of [account_balance] Table ... ' + ISNULL(CAST(@actual_count AS VARCHAR(100)),0)
	SET @expected_ACCT=(SELECT SUM(a1bal+a1sumc+a1sumd) FROM ydsm0648.ydsm.[ACCT] a1 JOIN ydsm0648.ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND NOT (a2.a2qrng = 'I' and a2.a2str='F' and a2.a2str2='G'))
	SET @ACCTcount=(SELECT COUNT(*) FROM ydsm0648.ydsm.[ACCT] a1 JOIN ydsm0648.ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND NOT (a2.a2qrng = 'I' and a2.a2str='F' and a2.a2str2='G'))
	PRINT 'Sum of Balance of [ACCT] Table with join ............. ' + ISNULL(CAST(@expected_ACCT AS VARCHAR(100)),0)
	PRINT 'Count Record of Balance of [ACCT] Table with join .... ' + ISNULL(CAST(@ACCTcount AS VARCHAR(100)),0)
	SET @expected_DLTR=(SELECT SUM(d4amt) FROM ydsm0648.ydsm.[DLTR])
	SET @DLTRcount=(SELECT COUNT(*) FROM ydsm0648.ydsm.[DLTR])
	PRINT 'Sum of Balance of [DLTR] Table ....................... ' + ISNULL(CAST(@expected_DLTR AS VARCHAR(100)),0)	
	PRINT 'Count Record of Balance of [DLTR] Table .............. ' + ISNULL(CAST(@DLTRcount AS VARCHAR(100)),0)	
	SET @expected_DLFX=(SELECT SUM(d9samt+d9pamt) FROM ydsm0648.ydsm.[DLFX])
	SET @DLFXcount=(SELECT COUNT(*) FROM ydsm0648.ydsm.[DLFX])
	PRINT 'Sum of Balance of [DLFX] Table ....................... ' + ISNULL(CAST(@expected_DLFX AS VARCHAR(100)),0)	
	PRINT 'Count Record of Balance of [DLFX] Table .............. ' + ISNULL(CAST(@DLFXcount AS VARCHAR(100)),0)	
	SET @expected_DTAF=(SELECT SUM(d11amt) FROM ydsm0648.ydsm.[DTAF] JOIN ydsm0648.ydsm.[DEAL] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ WHERE NOT (d1mnt=1 AND d1sts='C'))
	SET @DTAFcount=(SELECT COUNT(*) FROM ydsm0648.ydsm.[DTAF] JOIN ydsm0648.ydsm.[DEAL] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ WHERE NOT (d1mnt=1 AND d1sts='C'))
	PRINT 'Sum of Balance of [DTAF] Table ....................... ' + ISNULL(CAST(@expected_DTAF AS VARCHAR(100)),0)	
	PRINT 'Count Record of Balance of [DTAF] Table .............. ' + ISNULL(CAST(@DTAFcount AS VARCHAR(100)),0)	
	SET @expected = @expected_ACCT + @expected_DLTR + @expected_DLFX +@expected_DTAF
	SET @expected_count = @ACCTcount + @DLTRcount +@DLFXcount+@DTAFcount
	PRINT 'Sum of Balance of All ISUBA Source Tables ............ ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)	
	PRINT 'Count Record of Balance of All ISUBA Source Tables ... ' + ISNULL(CAST(@expected_count AS VARCHAR(100)),0)	
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that sum of balances of account_balance currency are zero]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;  
    SET @actual=(SELECT COUNT(*) FROM 
					 (SELECT currency.mnemonic AS currency, SUM(balance_amount) AS currency_sum FROM account.[account_definition]
					 	INNER JOIN account.account_balance On account_balance.id = account_definition.balance
						INNER JOIN rally.currency ON currency.id = account_definition.currency WHERE is_closed=0
						GROUP BY currency.mnemonic) AS Target_Table
					WHERE Target_Table.currency_sum>0)
	PRINT 'No of zero Sum Over Currency of Balance of [account_balance] Table... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)	
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that sum of balances of account_balance and ACCT over currency are equal]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;  
    SET @actual=(SELECT COUNT(*) FROM 
					(SELECT a1ccy AS currency,SUM(a1bal+a1sumc+a1sumd) AS currency_sum FROM ydsm.ACCT a1 
						INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND a2.a2qrng <> 'I' 
						GROUP BY a1ccy) AS SourceTable
					 INNER JOIN 
					 (SELECT currency.mnemonic AS currency, SUM(balance_amount) AS currency_sum FROM account.[account_definition]
					 	INNER JOIN account.account_balance On account_balance.id = account_definition.balance
						INNER JOIN rally.currency ON currency.id = account_definition.currency
						GROUP BY currency.mnemonic) AS Target_Table
					ON SourceTable.currency = Target_Table.currency
					WHERE SourceTable.currency_sum <> Target_Table.currency_sum)
	PRINT 'Inequivalent Sum of Balance over currency of [account_balance]/ACCT Tables ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)	
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that sum of overdraft limit of account_balance are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT SUM(overdraft_limit_amount) FROM account.[account_definition] adfn INNER JOIN account.account_balance On account_balance.id = adfn.balance INNER JOIN rally.[account_type] atyp on adfn.[type] = atyp.[id] WHERE atyp.[code] IN (SELECT a1.a1atyp FROM ydsm.[ACCT] a1 INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND a2.a2qrng <> 'I'))
	PRINT 'Sum of overdraft limit of [account_balance] Table ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(a1obal) FROM ydsm.[ACCT] a1 join ydsm.ATYP a2 on a1.a1atyp = a2.a2mne where a2.a2deal <> 'Y' AND NOT (a2.a2qrng = 'I' and a2.a2str='F' and a2.a2str2='G'))
	PRINT 'Sum of a1obal of [ACCT] Table ................. ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/*CREATE PROCEDURE AccountBalance.[test that sum of blocked balances of account_balance for type field and ACCT for a1atyp field with join are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT SUM(blocked_balance_amount) FROM account.[account_balance] ab INNER JOIN account.[account_definition] ad ON ab.id=ad.id INNER JOIN rally.[account_type] atyp on ad.[type] = atyp.[id] WHERE atyp.[code] IN (SELECT a1.a1atyp FROM ydsm.[ACCT] a1 INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND a2.a2qrng <> 'I'))
	PRINT 'Sum of Balance of [account_balance] Table with join ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(a1bbal) FROM ydsm.[ACCT] a1 join ydsm.ATYP a2 on a1.a1atyp = a2.a2mne where a2.a2deal <> 'Y' and a2.a2qrng <> 'I')
	PRINT 'Sum of Balance of [ACCT] Table with join ................. ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that sum of blocked balances of account_balance for type field and ACCT for a1atyp field with join are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT SUM(blocked_balance_amount) FROM account.[account_balance] ab INNER JOIN account.[account_definition] ad ON ab.id=ad.id INNER JOIN rally.[account_type] atyp on ad.[type] = atyp.[id] WHERE atyp.[code] IN (SELECT a1.a1atyp FROM ydsm.[ACCT] a1 INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND a2.a2qrng <> 'I'))
	PRINT 'Sum of Balance of [account_balance] Table with join ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(a1bbal) FROM ydsm.[ACCT] a1 join ydsm.ATYP a2 on a1.a1atyp = a2.a2mne where a2.a2deal <> 'Y' and a2.a2qrng <> 'I')
	PRINT 'Sum of Balance of [ACCT] Table with join ................. ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO*/

/*CREATE PROCEDURE AccountBalance.[test that sum of block bal. of account_balance for type fld and ACCT for a1atyp fld for specified acc.types are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT SUM(blocked_balance_amount) FROM account.[account_balance] ab INNER JOIN account.[account_definition] ad ON ab.id=ad.id INNER JOIN rally.[account_type] at on ad.[type] = at.[id] WHERE at.[code] IN ('B5','CA','CB','CN','DJ','EA','RM','RP','RT'))
	PRINT 'Sum of Balance of [account_balance] Table for code in (B5,CA,CB,CN,DJ,EA,RM,RP,RT) ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(a1bbal) FROM ydsm.[ACCT] WHERE [a1atyp] IN ('B5','CA','CB','CN','DJ','EA','RM','RP','RT'))
	PRINT 'Sum of Balance of [ACCT] Table for a1atyp in (B5,CA,CB,CN,DJ,EA,RM,RP,RT) ............... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO*/

/*CREATE PROCEDURE AccountBalance.[test that sum of ballance of account_balance and DLTR are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT sum(account_balance.balance) FROM account.account_balance INNER JOIN account.account_definition  ON account_balance.id=account_definition.balance INNER JOIN account.account_contract on account_definition.number=account_contract.reference)
	PRINT 'Sum of Balance of [account_balance] Table for account that has contract ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(d4amt) FROM ydsm.DLTR)
	PRINT 'Sum of Balance of [DLTR] Table for deals ............... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO*/

/*CREATE PROCEDURE AccountBalance.[test that sum of block bal. of account_balance and DEAL/DBLC joined are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SET @actual=(SELECT SUM(blocked_balance_amount) FROM account.account_balance INNER JOIN account.account_definition  ON account_balance.id=account_definition.balance INNER JOIN account.account_contract on account_definition.number=account_contract.reference)
	PRINT 'Sum of Balance of [account_balance] Table for account that has contract ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=(SELECT SUM(d32bbal) FROM ydsm.DEAL INNER JOIN ydsm.DBLC ON d1brn=d32brn AND d1typ=d32typ AND d1ref = d32ref)
	PRINT 'Sum of Balance of [ACCT] Table for deals ............... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO*/

/* Data Checks */
CREATE PROCEDURE AccountBalance.[test that overdraft limit cannot be less than zero]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[account_balance] WHERE overdraft_limit_amount < 0)
	PRINT 'Count of records when overdraft_limit < 0 ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that overdraft expire date cannot be null when overdraft limit is > 0]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[account_balance] ab INNER JOIN account.[customer_account_definition] cad ON ab.id=cad.id  WHERE overdraft_expire_date is null and overdraft_limit_amount > 0)
	PRINT 'Count of records when overdraft expire date is null and overdraft limit is > 0 ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBalance.[test that balance of closed accounts are zero]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);    
    SELECT @actual=COUNT(*) FROM account.account_definition INNER JOIN account.account_balance On account_balance.id = account_definition.balance WHERE account_definition.close_date IS NOT NULL AND account_balance.balance_amount>0
	PRINT 'Count of overdraft limit of [account_balance] Table ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/* Fields */

