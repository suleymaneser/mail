EXEC tSQLt.NewTestClass 'AccountContract';
GO

/* Record Counts */
CREATE PROCEDURE AccountContract.[test that record count of account_contract and DEAL are equal]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[account_contract])
	PRINT 'Record count of account_contract ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = (
		SELECT COUNT(*) FROM ydsm.[DEAL]
		LEFT JOIN ydsm.[DTAF] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ
		LEFT JOIN ydsm.[DLFX] ON d1brn=d9brn AND d1ref=d9ref AND d1typ=d9typ
		LEFT JOIN ydsm.[ACCT] a on d1brn=a.a1brn and d1acc=a.a1acc and d1sfx=a.a1sfx
		LEFT JOIN ydsm.[CCYS] on d1ccy=u1ccy
		LEFT JOIN ydsm.[ACCT] b on d11brn=b.a1brn and d11ccont=b.a1acc and u1code=b.a1sfx
		WHERE NOT (
			(d11ref IS NOT NULL and d1mnt=1 AND d1sts='C') OR
			(d11ref IS NOT NULL and (d11ccont=0 or a.a1brn is null or b.a1brn is null)) or
			(d9ref IS NOT NULL and (d9Psfx=0 or d9Ssfx=0))
		)
	)
	-- hic hesap acilmayan TF kayitlari aktarilmadi
	PRINT 'Record count of DEAL ... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/* Integrity */
CREATE PROCEDURE AccountContract.[test that each contract has at least one account]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[account_contract] acon LEFT JOIN account.[customer_account_definition] cad on acon.id = cad.contract WHERE cad.contract IS NULL)
	PRINT 'Record count of join where account is null ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/* Data Checks */
CREATE PROCEDURE AccountContract.[test that check reference data is the same on source and target]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
        SET @actual=(SELECT COUNT(*) FROM account.[account_contract] acon LEFT JOIN ydsm.[DEAL] deal on acon.reference = deal.d1ref WHERE deal.d1ref IS NULL)
	PRINT 'Record count of join where account is null ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountContract.[test that reference data is null other than deals]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[account_definition] adfn INNER JOIN rally.[account_type] atyp on adfn.[type] = atyp.[id] LEFT JOIN account.account_contract acon on adfn.number=acon.reference
                 WHERE acon.reference  IS NOT NULL AND atyp.[code] IN (SELECT a1.a1atyp FROM ydsm.[ACCT] a1 INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' AND a2.a2qrng <> 'I'))
	PRINT 'Record count of join where account is null ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO


