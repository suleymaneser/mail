EXEC tSQLt.NewTestClass 'AccountOwner';
GO
/* Record Counts */
CREATE PROCEDURE AccountOwner.[test that record count of customer_account_definition and account_owner are equal]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[customer_account_definition])
	PRINT 'Record count of customer_account_definition ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = (SELECT COUNT(*) FROM account.[account_owner])
	PRINT 'Record count of account_owner ... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO
/* Integrity */
CREATE PROCEDURE AccountOwner.[test that each account has an owner record]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.account_definition INNER JOIN account.customer_account_definition ON customer_account_definition.id=account_definition.id LEFT JOIN account.account_owner ON account_definition.id = account_owner.account WHERE account_owner.id IS NULL)
	PRINT 'Record count of join where owner is null ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO
CREATE PROCEDURE AccountOwner.[test that each account has an customer]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[account_owner] aown LEFT JOIN rally.[customer] cstm on cstm.id = aown.owner WHERE cstm.id IS NULL)
	PRINT 'Count of records where customer is null ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/* Fields */
