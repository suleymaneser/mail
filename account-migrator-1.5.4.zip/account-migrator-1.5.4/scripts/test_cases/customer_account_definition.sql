EXEC tSQLt.NewTestClass 'CustomerAccountDefinition';
GO

/* Integrity */
CREATE PROCEDURE CustomerAccountDefinition.[test that joint customer have more than one owner]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM (SELECT adfn.id, COUNT(*) AS [RecordCount] FROM account.[account_definition] adfn INNER JOIN account.[customer_account_definition] cadfn ON adfn.id = cadfn.id WHERE cadfn.is_joint = 1 GROUP BY adfn.id HAVING COUNT(*) < 2) AS AGGR_TABLE)
	PRINT 'Count of records where owner < 2 when is_joint=true ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO
--test


