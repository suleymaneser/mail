EXEC tSQLt.NewTestClass 'AccountDefinition';
GO


--TO DO
--POST sayilari kontrol


/* Record Counts */
CREATE PROCEDURE AccountDefinition.[test that record counts of account_definition and ACCT/DEAL/DLFX/DTAF are equal]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;
    DECLARE @ACCTcount INT;
    DECLARE @ACCTcount_internal INT;
    DECLARE @DEALcount INT;
    DECLARE @DLFXcount INT;    
    DECLARE @DTAFcount INT;
    SET @actual=(SELECT COUNT(*) FROM account.[account_definition])
       PRINT 'Record Count of [account_definition] Table ... ' + STR(ISNULL(@actual,0))
       SET @ACCTcount=(SELECT COUNT(*) FROM ydsm.[ACCT] a1 INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE a2.a2deal <> 'Y' and a2.a2qrng <> 'I')
       PRINT 'Record Count of [ACCT] Table for customer..... ' + STR(ISNULL(@ACCTcount,0))
       SET @ACCTcount_internal=(SELECT COUNT(*) FROM ydsm.[ACCT] a1 INNER JOIN ydsm.ATYP a2 ON a1.a1atyp = a2.a2mne WHERE (a2.a2qrng = 'I' and not (a2.a2str='F' and a2.a2str2='G')) )
       PRINT 'Record Count of [ACCT] Table for internal..... ' + STR(ISNULL(@ACCTcount,0))
       SET @DEALcount=(
       		SELECT COUNT(*) FROM ydsm.[DEAL]
       		LEFT JOIN ydsm.[DTAF] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ
       		LEFT JOIN ydsm.[DLFX] ON d1brn=d9brn AND d1ref=d9ref AND d1typ=d9typ
			LEFT JOIN ydsm.[ACCT] a on d1brn=a.a1brn and d1acc=a.a1acc and d1sfx=a.a1sfx
			LEFT JOIN ydsm.[CCYS] on d1ccy=u1ccy
			LEFT JOIN ydsm.[ACCT] b on d11brn=b.a1brn and d11ccont=b.a1acc and u1code=b.a1sfx
       		WHERE NOT (
       			(d11ref IS NOT NULL and d1mnt=1 AND d1sts='C') OR
       			(d11ref IS NOT NULL and (d11ccont=0 or a.a1brn is null or b.a1brn is null)) OR
       			(d9ref IS NOT NULL and (d9Psfx=0 or d9Ssfx=0))
       		)
       	)
       PRINT 'Record Count of [DEAL] Table ................. ' + STR(ISNULL(@Dealcount,0))    
       SET @DLFXcount=(SELECT COUNT(*) FROM ydsm.[DLFX] JOIN ydsm.[DEAL] ON d1brn=d9brn AND d1ref=d9ref AND d1typ=d9typ WHERE NOT (d9ref IS NOT NULL and (d9Psfx=0 or d9Ssfx=0)))
       PRINT 'Record Count of [DLFX] Table ................. ' + STR(ISNULL(@DLFXcount,0))
       SET @DTAFcount =(
       		SELECT COUNT(*) FROM ydsm.[DTAF]
       		JOIN ydsm.[DEAL] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ
			LEFT JOIN ydsm.[ACCT] a on d1brn=a.a1brn and d1acc=a.a1acc and d1sfx=a.a1sfx
			LEFT JOIN ydsm.[CCYS] on d1ccy=u1ccy
			LEFT JOIN ydsm.[ACCT] b on d11brn=b.a1brn and d11ccont=b.a1acc and u1code=b.a1sfx
       		WHERE NOT (
       			(d11ref IS NOT NULL and d1mnt=1 AND d1sts='C') OR
       			(d11ref IS NOT NULL and (d11ccont=0 or a.a1brn is null or b.a1brn is null))
       		)
       	)
       PRINT 'Record Count of [DTAF] Table ................. ' + STR(ISNULL(@DTAFcount,0))
    SET @expected = @ACCTcount + @ACCTcount_internal + @DEALcount +@DLFXcount+@DTAFcount
    PRINT 'Total of Source count ........................ ' + STR(ISNULL(@expected,0))
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountDefinition.[test that Record counts of account_definition for type field and ACCT for a1atyp field for specified account types are equal]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
    SET @actual=(SELECT COUNT(*) FROM account.[account_definition] adfn INNER JOIN rally.[account_type] atyp ON adfn.[type] = atyp.[id] WHERE atyp.[code] IN ('B5','CA','CB','CN','DJ','EA','RM','RP','RT','BN', 'BT'))
	PRINT 'Record Count of [account_definition] Table for code in (B5,CA,CB,CN,DJ,EA,RM,RP,RT) ... ' + STR(ISNULL(@actual,0))
	SET @expected=(SELECT COUNT(*) FROM ydsm.[ACCT] WHERE [a1atyp] IN ('B5','CA','CB','CN','DJ','EA','RM','RP','RT','BN','BT'))
	PRINT 'Record Count of [ACCT] Table for a1atyp in (B5,CA,CB,CN,DJ,EA,RM,RP,RT) ............... ' + STR(ISNULL(@expected,0))
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountDefinition.[test that Record count of account types of Rally and Isuba are equal]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
    SET @expected = 0
    SET @actual = (SELECT COUNT(*) FROM (
             SELECT DISTINCT code FROM (
                    SELECT DISTINCT a1atyp as code FROM ydsm.[ACCT]
                    UNION
                    SELECT DISTINCT d2datyp as code FROM ydsm.[DEAL] join ydsm.DTYP on d1typ=d2typ
             ) tmp_table WHERE code NOT IN (SELECT DISTINCT code FROM rally.[account_type])
    ) AS COUNTALL)
    PRINT 'Count of not matching account types in account_type .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertEquals @expected, @actual;    
END;
GO
/* Integrity */
CREATE PROCEDURE AccountDefinition.[test that Deal Types of Isuba match account types of Rally ]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
    SET @expected = 0
    SET @actual = (SELECT COUNT(*) FROM (SELECT DISTINCT d2datyp FROM ydsm.[DEAL] join ydsm.DTYP on d1typ=d2typ) AS DEAL_TYPES INNER JOIN rally.[account_type] ON d2datyp = code)
    PRINT 'Count of matching account types of DEAL .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountDefinition.[test that Account Types of Isuba match account types of Rally ]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
    SET @expected = 0
    SET @actual = (SELECT COUNT(*) FROM (SELECT DISTINCT a1atyp FROM ydsm.[ACCT]) AS ACCOUNT_TYPES INNER JOIN rally.[account_type] ON a1atyp = code)
    PRINT 'Count of matching account types of ACCT .... ' + STR(ISNULL(@actual,0))    
        EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountDefinition.[test that DLFX Types of Isuba match account types of Rally ]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
    SET @expected = 0
    SET @actual = (SELECT COUNT(*) FROM (SELECT DISTINCT d2datyp FROM ydsm.[DLFX] join ydsm.DTYP on d9typ=d2typ) AS DLFX_TYPES INNER JOIN rally.[account_type] ON d2datyp = code)
    PRINT 'Count of matching account types of DLFX .... ' + STR(ISNULL(@actual,0))    
    EXEC tSQLt.AssertNotEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountDefinition.[test that all migrated account numbers are matched]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;
    
    ;IF OBJECT_ID('tempdb..#TempRally') IS NOT NULL DROP TABLE #TempRally 
	;IF OBJECT_ID('tempdb..#TempIsuba') IS NOT NULL DROP TABLE #TempIsuba 
	;SELECT * INTO #TempRally FROM ( 
   	;SELECT number AS Join_Field_Ra FROM account.account_definition   ) TempRa
	;SELECT * INTO #TempIsuba FROM ( 
   		SELECT dbo.FormAccountNumber(a1brn,a1acc,a1sfx) AS Join_Field_Is FROM ydsm.ACCT INNER JOIN ydsm.ATYP ON a1atyp = a2mne WHERE a2deal <> 'Y'
   		UNION
   		SELECT d1ref AS Join_Field_Is FROM ydsm.DEAL
   		UNION
        SELECT d9ref + '-cntr' AS Join_Field_Is FROM ydsm.DLFX 
        UNION 
        SELECT d11ref + '-cntr' AS Join_Field_Is FROM ydsm.DTAF LEFT JOIN ydsm.[DEAL] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ WHERE NOT (d11ref IS NOT NULL and d1mnt=1 AND d1sts='C') -- hi� hesap a��lmayan TF kay�tlar� aktar�lmad�
   		) TempIs 
	;SET @actual=ISNULL((SELECT COUNT(*) FROM #TempIsuba GROUP BY Join_Field_Is HAVING COUNT(*) > 1),0) 
	;IF (@actual <> 0)
	BEGIN
		PRINT 'Dublicated key count in source tables ... ' + STR(ISNULL(@actual,0))
	END 
	ELSE
	BEGIN    
	    SET @expected=0
		SET @actual=(SELECT COUNT(*) FROM #TempRally LEFT JOIN #TempIsuba ON Join_Field_Ra = Join_Field_Is WHERE Join_Field_Is IS NULL)
		PRINT 'Record Count of not matched accounts ... ' + STR(ISNULL(@actual,0))	
	    EXEC tSQLt.AssertEquals @expected, @actual
	END
END;
GO

CREATE PROCEDURE AccountDefinition.[test that all source account numbers are matched]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;
    
    ;IF OBJECT_ID('tempdb..#TempRally') IS NOT NULL DROP TABLE #TempRally 
	;IF OBJECT_ID('tempdb..#TempIsuba') IS NOT NULL DROP TABLE #TempIsuba 
	;SELECT * INTO #TempRally FROM ( 
		SELECT number AS Join_Field_Ra FROM account.account_definition   ) TempRa
	;SELECT * INTO #TempIsuba FROM ( 
   		SELECT dbo.FormAccountNumber(a1brn,a1acc,a1sfx) AS Join_Field_Is FROM ydsm.ACCT INNER JOIN ydsm.ATYP ON a1atyp = a2mne WHERE a2deal <> 'Y'
   		UNION
   		SELECT d1ref AS Join_Field_Is FROM ydsm.DEAL
   		UNION
   		SELECT d9ref + '-cntr' AS Join_Field_Is FROM ydsm.DLFX 
        UNION 
        SELECT d11ref + '-cntr' AS Join_Field_Is FROM ydsm.DTAF LEFT JOIN ydsm.[DEAL] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ WHERE NOT (d11ref IS NOT NULL and d1mnt=1 AND d1sts='C') -- hi� hesap a��lmayan TF kay�tlar� aktar�lmad�
   		) TempIs 
	;SET @actual=ISNULL((SELECT COUNT(*) FROM #TempIsuba GROUP BY Join_Field_Is HAVING COUNT(*) > 1),0) 
	;IF (@actual <> 0)
	BEGIN
		PRINT 'Dublicated key count in source tables ... ' + STR(ISNULL(@actual,0))
	END 
	ELSE
	BEGIN    
	    SET @expected=0
		SET @actual=(SELECT COUNT(*) FROM #TempIsuba LEFT JOIN #TempRally ON Join_Field_Ra = Join_Field_Is WHERE Join_Field_Ra IS NULL)
		PRINT 'Record Count of not matched accounts ... ' + STR(ISNULL(@actual,0))	
	    EXEC tSQLt.AssertEquals @expected, @actual
	END
END;
GO

CREATE PROCEDURE AccountDefinition.[test that there is no dublicate source account]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;
    
	;IF OBJECT_ID('tempdb..#TempIsuba') IS NOT NULL DROP TABLE #TempIsuba 
	;SELECT * INTO #TempIsuba FROM ( 
   		SELECT dbo.FormAccountNumber(a1brn,a1acc,a1sfx) AS Join_Field_Is FROM ydsm.ACCT INNER JOIN ydsm.ATYP ON a1atyp = a2mne WHERE a2deal <> 'Y'
   		UNION
   		SELECT d1ref AS Join_Field_Is FROM ydsm.DEAL
   		UNION
   		SELECT d9ref + '-cntr' AS Join_Field_Is FROM ydsm.DLFX 
        UNION 
        SELECT d11ref + '-cntr' AS Join_Field_Is FROM ydsm.DTAF LEFT JOIN ydsm.[DEAL] ON d1brn=d11brn AND d1ref=d11ref AND d1typ=d11typ WHERE NOT (d11ref IS NOT NULL and d1mnt=1 AND d1sts='C') -- hi� hesap a��lmayan TF kay�tlar� aktar�lmad�
   		) TempIs 
	;SET @actual=ISNULL((SELECT COUNT(*) FROM #TempIsuba GROUP BY Join_Field_Is HAVING COUNT(*) > 1),0) 
    SET @expected=0
	PRINT 'Record Count of dublicate source accounts ... ' + STR(ISNULL(@actual,0))	
    EXEC tSQLt.AssertEquals @expected, @actual
END;
GO

CREATE PROCEDURE AccountDefinition.[test that there is no dublicate migrated account]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
	SET @actual=ISNULL((SELECT COUNT(*) FROM account_definition GROUP BY number HAVING COUNT(*) > 1),0) 
    SET @expected=0
	PRINT 'Record Count of dublicate source accounts ... ' + STR(ISNULL(@actual,0))	
    EXEC tSQLt.AssertEquals @expected, @actual
END;
GO

CREATE PROCEDURE AccountDefinition.[test that all account blockage is migrated]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
	SET @actual=ISNULL((SELECT COUNT(*) FROM account.account_definition LEFT JOIN account.account_blockage ON account_definition.id = account_blockage.account WHERE account_definition.is_blocked = 1 and account_blockage.id is null
    SET @expected=0
	PRINT 'Record Count of missing blockage ... ' + STR(ISNULL(@actual,0))	
    EXEC tSQLt.AssertEquals @expected, @actual
END;
GO

/* Data Checks */
CREATE PROCEDURE AccountDefinition.[test that iban field is not null]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;
    
	SET @actual=(SELECT COUNT(*) FROM account.account_definition WHERE iban is null)
    SET @expected=0
	PRINT 'Record Count of iban field is null ... ' + STR(ISNULL(@actual,0))	
    EXEC tSQLt.AssertEquals @expected, @actual
END;
GO

/* Fields */

/* Function/Procedure */
