EXEC [ydsm].[issp_VALYSILAFTER_build] 0653, 20210704, 20210705, 'E', 'N', 20210801, 20210101, 20190101


EXEC [ydsm].[issp_VALYSIL_build] 0653, 20210704, 20210705, 'E', 'N', 20210801, 20210101, 20190101
select * from ydsm.VALYSIL where m31typ in (select d2typ from ydsm.dtyp where d2app='TF' and d2typ0='G')
select count(*) from ydsm.VALYSIL a --12593
select count(*) from ydsm.VALYSILAFTER a --12403


exec ydsm.issp_VALLSILAFTER_build 0653, 20210704, 20210705, 'E', 'N', 20210801


select count(*) from ydsm.vallSIL a
select count(*) from ydsm.vallSILafter a


select * from ydsm.vallSIL a
join ydsm.vallSILafter b
on a.m30brn=b.m30brn
and a.m30acc=b.m30acc
and a.m30sfx=b.m30sfx
and a.m30typ=b.m30typ
and a.m30ref=b.m30ref
where
a.m30amt<>b.m30amt or
a.m30ccy<>b.m30ccy or
a.m30std<>b.m30std or
a.m30lcd<>b.m30lcd or
a.m30ncd<>b.m30ncd or
a.m30mtd<>b.m30mtd or

a.m30blcg<>b.m30blcg or
a.m30code<>b.m30code or
a.m30codeI<>b.m30codeI or
a.m30codeX<>b.m30codeX or
a.m30stage<>b.m30stage or
a.m30cstage<>b.m30cstage

select count(*) from ydsm.VALYSIL a --12593
select count(*) from ydsm.VALYSILAFTER a --12403

select a.m31arc, b.m31arc, * from ydsm.VALYSIL a
join ydsm.VALYSILAFTER b
on a.m31brn=b.m31brn and
a.m31acc=b.m31acc and
a.m31sfx=b.m31sfx and
a.m31typ=b.m31typ and
a.m31ref=b.m31ref
where
a.m31amt<>b.m31amt or
a.m31ccy<>b.m31ccy or
a.m31std<>b.m31std or
a.m31lcd<>b.m31lcd or
a.m31ncd<>b.m31ncd or
a.m31mtd<>b.m31mtd or

a.m31blcg<>b.m31blcg or
a.m31code<>b.m31code or
a.m31codeI<>b.m31codeI or
a.m31codeX<>b.m31codeX or
a.m31limitamt<>b.m31limitamt or
a.m31limitccy<>b.m31limitccy or
a.m31limittype<>b.m31limittype or
a.m31abmflg<>b.m31abmflg or
a.m31exr<>b.m31exr or
a.m31time<>b.m31time or
a.m31mprice<>b.m31mprice or
a.m31arc<>b.m31arc or
a.m31dtbrn<>b.m31dtbrn or
a.m31stl<>b.m31stl or
a.m31psd<>b.m31psd or
a.m31ctd<>b.m31ctd or
a.m31amt2<>b.m31amt2 or
a.m31mtd2<>b.m31mtd2 or
a.m31dintp1<>b.m31dintp1 or
a.m31amti2<>b.m31amti2 or
a.m31ar<>b.m31ar or
a.m31ar2<>b.m31ar2 or
a.m31equpay<>b.m31equpay or
a.m31frqP<>b.m31frqP or
a.m31app<>b.m31app or
a.m31cstage<>b.m31cstage or
a.m31tobrn<>b.m31tobrn or
a.m31toacc<>b.m31toacc or
a.m31tosfx<>b.m31tosfx or
a.m31totyp<>b.m31totyp or
a.m31toref<>b.m31toref or
a.m31toamtDi1<>b.m31toamtDi1 or
a.m31toamtCi1<>b.m31toamtCi1 or
a.m31todate<>b.m31todate or

a.m31IbanNo<>b.m31IbanNo or
a.m31atyp<>b.m31atyp or
a.m31atbrn<>b.m31atbrn or
a.m31blc<>b.m31blc or
a.m31crd<>b.m31crd or
a.m31cld<>b.m31cld or
a.m31cls<>b.m31cls or
a.m31aana<>b.m31aana or
a.m31rec<>b.m31rec or
a.m31pac<>b.m31pac or
a.m31ctyp<>b.m31ctyp or
a.m31fnm<>b.m31fnm or
a.m31sub<>b.m31sub or
a.m31tacc<>b.m31tacc or
a.m31tno<>b.m31tno or
a.m31txno<>b.m31txno or
a.m31cana<>b.m31cana or
a.m31snm<>b.m31snm or
a.m31fnsc<>b.m31fnsc or
a.m31qua<>b.m31qua or
a.m31ot<>b.m31ot or
a.m31ap<>b.m31ap or
a.m31avyD<>b.m31avyD or
a.m31avyDoRM<>b.m31avyDoRM or
a.m31avyC<>b.m31avyC or
a.m31avyCoRM<>b.m31avyCoRM or
a.m31cbc<>b.m31cbc or
a.m31asnm<>b.m31asnm


                          




m30amtDy2d,m30amtDi1,m30amtDp4,m30plD,m30amtDtot,m30blcgDi,m30blcgDir,m30rtD,m30rateD,m30frqD,m30holdD,m30amtCy2d,m30amtCi1,m30amtCp4,m30plC,m30amtCtot,m30blcgCi,m30blcgCir,m30rtC,m30rateC,m30frqC,

m30blcg,m30code,m30codeI,m30codeX,m30stage,m30cstage,m30restructured,m30a1sumadj)  
0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 0, 0, 0, 0, 0, 0, ' ', ' ', ' ', 0, ' ', 
@d11blcgD, @m30code, @m30codel, @m30codex, @m30stage, @m30cstage, 0, 0)

		select 
			acct.a1brn as d1brn, 
			acct.a1acc as d1acc, 
			acct.a1sfx as d1sfx,
			acct.a1ccy as d1ccy, 
			letter_of_guarantee.product_type as d1typ, 
			account_contract.reference as d1ref,
			0 as d1code, 
			' ' as d1codel, 
			0 as d1codex,
			letter_of_guarantee.branch_code as d1tbrn,
			'' as d1stl,
			ISNULL(Convert(CHAR(8), letter_of_guarantee.create_date, 112), 0) as d1psd,
			ISNULL(Convert(CHAR(8), letter_of_guarantee.application_date, 112), 0) as d1ctd,
			'' as a2cat,
			letter_of_guarantee.current_amount as d11amt, 
			802000 as d11ccont, 
			letter_of_guarantee.debit_tdhp as d11blcgD, 
			letter_of_guarantee.credit_tdhp as d11blcgC,
			u1code, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.issue_date, 112), 0) as d11std, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.expiry_date, 112), 0) as d11mtd, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.claim_validity_date, 112), 0) as d11tmd, 
			ISNULL(Convert(CHAR(8), letter_of_guarantee.last_maintenance_date, 112), 0) as d11lmd, 
			case when letter_of_guarantee.status='ACTIVE' then '' else 'A' end as d1arc, 
			null as d4amt2,
			null as d4mtd2,
			null as d7intp1,
			null as d8amti2,
			null as d8ar,		
			null as d8ar2,
			null as d14equpay,
			null as d14frqP,
			'TF' as d2app,
			'1' as d11cstage
		from noncashloan.letter_of_guarantee
		join accountcore.account on account.number=letter_of_guarantee.number
		join accountcore.customer_account on customer_account.id=account.id
		join accountcore.account_contract on account_contract.id=customer_account.contract
		join accountcore.account_owner on account_owner.account=customer_account.id --and account_owner.is_primary=1
		join accountcore.product on product.product_type = letter_of_guarantee.product_type
		join accountcore.account_type on product.account_type=account_type.id
		join ydsm.acct on acct.a1brn=account.owning_unit_code and acct.a1acc=account_owner.owner_number 
					and acct.a1atyp=account_type.code and acct.a1ccy=account.currency and a1cls='N'
		join ydsm.ccys on ccys.u1ccy=account.currency
		where owning_unit_code=653 and 
		(
			(letter_of_guarantee.status='ACTIVE' and account.is_closed=0) or 
			(letter_of_guarantee.status<>'ACTIVE' and account.is_closed=1 and 
				(
					ISNULL(Convert(CHAR(8), letter_of_guarantee.expiry_date, 112), 0) >= 20190101 or
					ISNULL(Convert(CHAR(8), letter_of_guarantee.claim_validity_date, 112), 0) >= 20190101
				)
			) or
			(letter_of_guarantee.status<>'ACTIVE' and account.is_closed=1 and 
				(
					ISNULL(Convert(CHAR(8), letter_of_guarantee.expiry_date, 112), 0) = 0 and 
					ISNULL(Convert(CHAR(8), letter_of_guarantee.claim_validity_date, 112), 0) = 0 and 
					ISNULL(Convert(CHAR(8), letter_of_guarantee.last_maintenance_date, 112), 0) >= 20190101
				)
			)
		) and len(letter_of_guarantee.number)=22

