PRINT '*****************************************************************************************************'
PRINT '***                          AccountBlockage Migration Tests                                       ***'
PRINT '*****************************************************************************************************'

EXEC tSQLt.NewTestClass 'AccountBalance';
GO

/* Record Counts */
CREATE PROCEDURE AccountBlockage.[test that record count of blockage for source and target are equal]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;   
    DECLARE @expected_ACCT INT; 
    DECLARE @expected_ABLC INT;
    SELECT @actual=COUNT(*) FROM account.account_blockage
	PRINT '(Target) Record Count account_blockage Table ..... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SELECT @expected_ACCT=COUNT(*) FROM rallyIQ.ydsm.[ACCT] WHERE a1blc = 'Y'  
	PRINT 'Record Count of blocked accounts at ACCT Table ... ' + ISNULL(CAST(@expected_ACCT AS VARCHAR(100)),0)
	SELECT @expected_ABLC=COUNT(*) FROM rallyIQ.ydsm.[ABLC] WHERE k10blcamt>0   
	PRINT 'Record Count of blocked amounts at ABLC Table .... ' + ISNULL(CAST(@expected_ABLC AS VARCHAR(100)),0)
	SET @expected=@expected_ACCT+@expected_ABLC 
	PRINT '(Source) Record Count blockages ................... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/* Financials */
CREATE PROCEDURE AccountBlockage.[test that sum of blockage amount of source and target are equal]
AS
BEGIN
    DECLARE @actual DECIMAL(38,2);
    DECLARE @expected DECIMAL(38,2);   
    
    SELECT @actual=SUM(account_blockage.blockage_amount) FROM account.account_blockage  
    PRINT 'Sum of Blockage Amount of [account_blockage] Table ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SELECT @expected=SUM(k10blcamt) FROM ydsm.ABLC
	PRINT 'Sum of k10blcamt of [ABLC] Table ..................... ' + ISNULL(CAST(@expected AS VARCHAR(100)),0)
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountBlockage.[test that sum of blockage amount of source and target are equal]
AS
BEGIN
    DECLARE @actual INT,@expected INT, @checkTarget INT, @checkSource INT,@s INT,@duration INT, @st DATETIME, @et DATETIME
    
    ;IF OBJECT_ID('tempdb..#TempRally') IS NOT NULL DROP TABLE #TempRally 
	;IF OBJECT_ID('tempdb..#TempIsuba') IS NOT NULL DROP TABLE #TempIsuba 
	;SET @st=GETDATE()
	;PRINT '<CreateTempRallyStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</CreateTempRallyStartTime>'
	;SELECT * INTO #TempRally FROM ( 
		SELECT account_definition.number as Join_Field_Ra, SUM(account_blockage.blockage_amount) AS Check_Field_Ra FROM account.account_blockage INNER JOIN account.account_definition ON account_definition.id=account_blockage.account GROUP BY account_definition.number
	 ) TempRa
	;SET @et=GETDATE()
	;PRINT '<CreateTempRallyEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</CreateTempRallyEndTime>'
	;SET @duration=DATEDIFF(ms, @st, @et)
	;PRINT '<CreateTempRallyDuration>' +CAST(@duration As VARCHAR(100))+ '</CreateTempRallyDuration>'
	;SET @st=GETDATE()
	;PRINT '<CreateTempIsubaStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</CreateTempIsubaStartTime>'
	;SELECT * INTO #TempIsuba FROM ( 
		SELECT dbo.FormAccountNumber(k10brn,k10acc,k10sfx) as Join_Field_Is, SUM(k10blcamt) AS Check_Field_Is FROM rallyIQ.ydsm.ABLC WHERE k10blcamt > 0 GROUP BY dbo.FormAccountNumber(k10brn,k10acc,k10sfx)
   	 ) TempIs    	 
   	;SET @et=GETDATE()
	;PRINT '<CreateTempIsubaEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</CreateTempIsubaEndTime>'
	;SET @duration=DATEDIFF(ms, @st, @et)
	;PRINT '<CreateTempIsubaDuration>' +CAST(@duration As VARCHAR(100))+ '</CreateTempIsubaDuration>'
	;SET @st=GETDATE()
	;PRINT '<CountTempRallyStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</CountTempRallyStartTime>'
	;SELECT @checkTarget=COUNT(*) FROM #TempRally 
	;SET @et=GETDATE()
	;PRINT '<CountTempRallyEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</CountTempRallyEndTime>'
	;SET @duration=DATEDIFF(ms, @st, @et)
	;PRINT '<CountTempRallyDuration>' +CAST(@duration As VARCHAR(100))+ '</CountTempRallyDuration>'
	;SET @st=GETDATE()
	;PRINT '<CountTempIsubaStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</CountTempIsubaStartTime>'
	;SELECT @checkSource=COUNT(*) FROM #TempIsuba 
	;SET @et=GETDATE()
	;PRINT '<CountTempIsubaEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</CountTempIsubaEndTime>'
	;SET @duration=DATEDIFF(ms, @st, @et)
	;PRINT '<CountTempIsubaDuration>' +CAST(@duration As VARCHAR(100))+ '</CountTempIsubaDuration>'
	;SET @st=GETDATE()
	;PRINT '<IndexStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</IndexStartTime>'
	;CREATE NONCLUSTERED INDEX Is1 ON #TempIsuba (Join_Field_Is) INCLUDE (Check_Field_Is) 
	;CREATE NONCLUSTERED INDEX Ra1 ON #TempRally (Join_Field_Ra) INCLUDE (Check_Field_Ra) 
	;SET @et=GETDATE()
	;PRINT '<IndexEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</IndexEndTime>'
	;SET @duration=DATEDIFF(ms, @st, @et)
	;PRINT '<IndexDuration>' +CAST(@duration As VARCHAR(100))+ '</IndexDuration>'
	;PRINT '(Source) Count of records rallyIQ.ydsm.ABLC.k10blcamt join ... ' + ISNULL(CAST(@checkSource AS VARCHAR(100)),0) 
	;PRINT '(Target) Count of records account_blockage.blockage_amount join ... ' + ISNULL(CAST(@checkTarget AS VARCHAR(100)),0) 
	;SET @s = 1  
	;IF ((@checkTarget>0) AND (@checkSource=0) AND @s=1) OR ((@checkTarget=0) AND (@checkSource>0)) 
	   BEGIN 
	     ;SET @actual = 999999 
	     ;PRINT ' <Empty Set> '
	   END 
	   ELSE 
	   BEGIN 
	     ;SET @st=GETDATE()
	     ;PRINT '<ActualStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</ActualStartTime>'
	     ;SET @actual=(SELECT COUNT(*) FROM #TempIsuba INNER JOIN #TempRally ON Join_Field_Ra = Join_Field_Is WHERE Check_Field_Ra <> Check_Field_Is) 
	     ;SET @et=GETDATE()
	     ;PRINT '<ActualEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</ActualEndTime>'
	     ;SET @duration=DATEDIFF(ms, @st, @et)
	     ;PRINT '<ActualDuration>' +CAST(@duration As VARCHAR(100))+ '</ActualDuration>'
	     ;IF (@actual>0) 
			 BEGIN 
			   ;SET @st=GETDATE()
			   ;PRINT '<SampleListStartTime>' + CONVERT(VARCHAR(10),@st,101) + ' ' + CONVERT(VARCHAR(8),@st,108) + '</SampleListStartTime>'
			   ;PRINT '...Sample List...';
			   ;SELECT TOP 5 * FROM #TempIsuba INNER JOIN #TempRally ON Join_Field_Ra = Join_Field_Is WHERE Check_Field_Ra <> Check_Field_Is
			   ;SET @et=GETDATE()
			   ;PRINT '<SampleListEndTime>' + CONVERT(VARCHAR(10),@et,101) + ' ' + CONVERT(VARCHAR(8),@et,108) + '</SampleListEndTime>'
			   ;SET @duration=DATEDIFF(ms, @st, @et)
			   ;PRINT '<SampleListDuration>' +CAST(@duration As VARCHAR(100))+ '</SampleListDuration>'
			 END
	     ;PRINT '.................';
	     ;PRINT 'Count of records SUM(blockage_amount) <> SUM(k10blcamt) / GROUP BY number ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0);
	   END 
	;SET @expected=0
	;EXEC tSQLt.AssertEquals @expected, @actual
END;
GO