﻿DECLARE @existingAccountCount int;  
DECLARE @existingAccountBalanceSum bigint;  
SET  @existingAccountCount = 0;
SET  @existingAccountBalanceSum = 0;

-- START check if count of open CA accounts to be migrated is equal to created CA accounts 
PRINT '----------------------------'
DECLARE @expectedMigratedAccountCount int;   
SET @expectedMigratedAccountCount=(
	SELECT COUNT(*) FROM ydsm.ACCT where a1atyp in ('CA', 'CB') and a1cls='N'
)
PRINT 'Count of CA accounts to be migrated ' + ISNULL(CAST(@expectedMigratedAccountCount AS VARCHAR(100)),0)

DECLARE @actualMigratedAccountCount int;
SET @actualMigratedAccountCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('CA', 'CB')
)
SET @actualMigratedAccountCount = @actualMigratedAccountCount - @existingAccountCount
PRINT 'Count of created (CA,CB) type accounts ' + ISNULL(CAST(@actualMigratedAccountCount AS VARCHAR(100)),0)

IF @expectedMigratedAccountCount <> @actualMigratedAccountCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of created (CA,CB) type accounts is ' + ISNULL(CAST(@expectedMigratedAccountCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedAccountCount AS VARCHAR(100)),0)
END
-- END check if count of open CA accounts to be migrated is equal to created CA accounts 


-- START check if count of open CA accounts to be migrated is equal to created current_account records
PRINT '----------------------------'
DECLARE @expectedMigratedRecordCount int;   
SET @expectedMigratedRecordCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('CA', 'CB')
)
PRINT 'Count of CA accounts to be migrated ' + ISNULL(CAST(@expectedMigratedRecordCount AS VARCHAR(100)),0)

DECLARE @actualMigratedRecordCount int;
SET @actualMigratedRecordCount=(
	SELECT COUNT(*) from currentaccount.current_account
)
SET @actualMigratedRecordCount = @actualMigratedRecordCount - @existingAccountCount
PRINT 'Count of created current_account records ' + ISNULL(CAST(@actualMigratedRecordCount AS VARCHAR(100)),0)

IF @expectedMigratedRecordCount <> @actualMigratedRecordCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of current_account records is ' + ISNULL(CAST(@expectedMigratedRecordCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST((@actualMigratedRecordCount) AS VARCHAR(100)),0)
END
-- END check if count of open CA accounts to be migrated is equal to created current_account records


-- START check if sum of balances of open CA accounts to be migrated is equal to created CA accounts 
-- the sum value is on purpose independent of currency
PRINT '----------------------------'
DECLARE @expectedMigratedBalanceSum bigint;   
SET @expectedMigratedBalanceSum=(
	SELECT SUM(a1bal+a1sumC+a1sumD) FROM ydsm.ACCT where a1atyp in ('CA', 'CB') and a1cls='N'
)
PRINT 'Sum of balances of CA accounts to be migrated ' + ISNULL(CAST(@expectedMigratedBalanceSum AS VARCHAR(100)),0)

DECLARE @actualMigratedBalanceSum bigint;
SET @actualMigratedBalanceSum=(
	SELECT sum(balance_amount) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id 
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('CA', 'CB')
)
SET @actualMigratedBalanceSum = @actualMigratedBalanceSum - @existingAccountBalanceSum
PRINT 'Sum of balances of created CA accounts ' + ISNULL(CAST(@actualMigratedBalanceSum AS VARCHAR(100)),0)

IF @expectedMigratedBalanceSum <> @actualMigratedBalanceSum
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected sum of balances of created CA accounts is ' + ISNULL(CAST(@expectedMigratedBalanceSum AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedBalanceSum AS VARCHAR(100)),0)
END
-- END check if sum of balances of open CA accounts to be migrated is equal to created CA accounts 





-- START check if count of open Nostro Accounts to be migrated is equal to created Nostro Accounts
PRINT '----------------------------'
SET @expectedMigratedAccountCount=(
	SELECT COUNT(*) FROM ydsm.NSTR n1
	JOIN ydsm.ACCT a1 on n1.n1brn=a1.a1brn and n1.n1acc=a1.a1acc and n1.n1sfx=a1.a1sfx
	where a1cls='N'
)
PRINT 'Count of Nostro Accounts to be migrated ' + ISNULL(CAST(@expectedMigratedAccountCount AS VARCHAR(100)),0)

SET @actualMigratedAccountCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('CN', 'CV')
)
SET @actualMigratedAccountCount = @actualMigratedAccountCount - @existingAccountCount
PRINT 'Count of created (CN,CV) type accounts ' + ISNULL(CAST(@actualMigratedAccountCount AS VARCHAR(100)),0)

IF @expectedMigratedAccountCount <> @actualMigratedAccountCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of created (CN,CV) type accounts is ' + ISNULL(CAST(@expectedMigratedAccountCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedAccountCount AS VARCHAR(100)),0)
END
-- END check if count of open Nostro Accounts to be migrated is equal to created Nostro Accounts


-- START check if count of open Nostro Accounts to be migrated is equal to created nostro_account records
PRINT '----------------------------'
SET @expectedMigratedRecordCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('CN', 'CV')
)
PRINT 'Count of Nostro Accounts to be migrated ' + ISNULL(CAST(@expectedMigratedRecordCount AS VARCHAR(100)),0)

SET @actualMigratedRecordCount=(
	SELECT COUNT(*) from currentaccount.nostro_account
)
SET @actualMigratedRecordCount = @actualMigratedRecordCount - @existingAccountCount
PRINT 'Count of created nostro_account records ' + ISNULL(CAST(@actualMigratedRecordCount AS VARCHAR(100)),0)

IF @expectedMigratedRecordCount <> @actualMigratedRecordCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of nostro_account records is ' + ISNULL(CAST(@expectedMigratedRecordCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST((@actualMigratedRecordCount) AS VARCHAR(100)),0)
END
-- END check if count of open Nostro Accounts to be migrated is equal to created nostro_account records


-- START check if sum of balances of open Nostro Accounts to be migrated is equal to created Nostro Accounts
-- the sum value is on purpose independent of currency
PRINT '----------------------------'
SET @expectedMigratedBalanceSum=(
	SELECT SUM(a1bal+a1sumC+a1sumD) FROM ydsm.NSTR n1
	JOIN ydsm.ACCT a1 on n1.n1brn=a1.a1brn and n1.n1acc=a1.a1acc and n1.n1sfx=a1.a1sfx
	where a1cls='N'
)
PRINT 'Sum of balances of Nostro Accounts to be migrated ' + ISNULL(CAST(@expectedMigratedBalanceSum AS VARCHAR(100)),0)

SET @actualMigratedBalanceSum=(
	SELECT sum(balance_amount) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id 
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('CN', 'CV')
)
SET @actualMigratedBalanceSum = @actualMigratedBalanceSum - @existingAccountBalanceSum
PRINT 'Sum of balances of created Nostro Accounts ' + ISNULL(CAST(@actualMigratedBalanceSum AS VARCHAR(100)),0)

IF @expectedMigratedBalanceSum <> @actualMigratedBalanceSum
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected sum of balances of created Nostro Accounts is ' + ISNULL(CAST(@expectedMigratedBalanceSum AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedBalanceSum AS VARCHAR(100)),0)
END
-- END check if sum of balances of open Nostro Accounts to be migrated is equal to created CA accounts 





-- START check if count of open Cash Accounts to be migrated is equal to created Nostro Accounts
PRINT '----------------------------'
SET @expectedMigratedAccountCount=(
	SELECT COUNT(*) FROM ydsm.ACCT where a1atyp in ('AT', 'YA') and a1cls='N'
)
PRINT 'Count of Cash Accounts to be migrated ' + ISNULL(CAST(@expectedMigratedAccountCount AS VARCHAR(100)),0)

SET @actualMigratedAccountCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('AT', 'YA')
)
SET @actualMigratedAccountCount = @actualMigratedAccountCount - @existingAccountCount
PRINT 'Count of created (AT,YA) type accounts ' + ISNULL(CAST(@actualMigratedAccountCount AS VARCHAR(100)),0)

IF @expectedMigratedAccountCount <> @actualMigratedAccountCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of created (CN,CV) type accounts is ' + ISNULL(CAST(@expectedMigratedAccountCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedAccountCount AS VARCHAR(100)),0)
END
-- END check if count of open Cash Accounts to be migrated is equal to created Nostro Accounts


-- START check if count of open Cash Accounts to be migrated is equal to created internal_account records
PRINT '----------------------------'
SET @expectedMigratedRecordCount=(
	SELECT COUNT(*) FROM ydsm.ACCT where a1atyp in ('AT', 'YA') and a1cls='N'
)
PRINT 'Count of Cash Accounts to be migrated ' + ISNULL(CAST(@expectedMigratedRecordCount AS VARCHAR(100)),0)

SET @actualMigratedRecordCount=(
	SELECT COUNT(*) from accountcore.account a
	JOIN accountcore.account_type act ON a.account_type = act.id 
	JOIN accountcore.internal_account ia on a.id = ia.id 
	WHERE act.code in ('AT', 'YA')
)
SET @actualMigratedRecordCount = @actualMigratedRecordCount - @existingAccountCount
PRINT 'Count of created internal_account records ' + ISNULL(CAST(@actualMigratedRecordCount AS VARCHAR(100)),0)

IF @expectedMigratedRecordCount <> @actualMigratedRecordCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of internal_account records is ' + ISNULL(CAST(@expectedMigratedRecordCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST((@actualMigratedRecordCount) AS VARCHAR(100)),0)
END
-- END check if count of open Cash Accounts to be migrated is equal to created internal_account records


-- START check if sum of balances of open Cash Accounts to be migrated is equal to created Cash Accounts
-- the sum value is on purpose independent of currency
PRINT '----------------------------'
SET @expectedMigratedBalanceSum=(
	SELECT SUM(a1bal+a1sumC+a1sumD) FROM ydsm.ACCT where a1atyp in ('AT', 'YA') and a1cls='N'
)
PRINT 'Sum of balances of Cash Accounts to be migrated ' + ISNULL(CAST(@expectedMigratedBalanceSum AS VARCHAR(100)),0)

SET @actualMigratedBalanceSum=(
	SELECT sum(balance_amount) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id 
	join accountcore.account_type act on a.account_type=act.id 
	where code in ('AT', 'YA')
)
SET @actualMigratedBalanceSum = @actualMigratedBalanceSum - @existingAccountBalanceSum
PRINT 'Sum of balances of created Cash Accounts ' + ISNULL(CAST(@actualMigratedBalanceSum AS VARCHAR(100)),0)

IF @expectedMigratedBalanceSum <> @actualMigratedBalanceSum
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected sum of balances of created Cash Accounts is ' + ISNULL(CAST(@expectedMigratedBalanceSum AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedBalanceSum AS VARCHAR(100)),0)
END
-- END check if sum of balances of open Cash Accounts to be migrated is equal to created CA accounts 



/*

-- START check if count of TF counter accounts to be created is equal to actual value
PRINT '----------------------------'
DECLARE @expectedCreatedCounterAccountCount int;   
SET @expectedCreatedCounterAccountCount=(
	select count(*) from (
	SELECT a.owning_unit_code, a.currency, a.account_type, sum(balance_amount) as balance_amount
	FROM accountcore.account a
	JOIN accountcore.account_balance ab on a.balance=ab.id
	JOIN accountcore.account_type act on a.account_type=act.id
	WHERE act.code in (
	SELECT code from accountcore.product
	JOIN accountcore.account_type
	ON accountcore.product.account_type=accountcore.account_type.id
	WHERE accountcore.product.application_family_type in ('E','I'))
	GROUP BY a.owning_unit_code, a.currency, a.account_type) temp_table
)
PRINT 'Count of TF counter accounts to be created ' + ISNULL(CAST(@expectedCreatedCounterAccountCount AS VARCHAR(100)),0)

DECLARE @actualCreatedCounterAccountCount int;
SET @actualCreatedCounterAccountCount=(
	select count(*) from accountcore.account a
	join accountcore.internal_account b on a.id=b.id 
	join accountcore.account_type c on a.account_type=c.id
	where c.code in ('TA', 'TC')
)
PRINT 'Count of created TF counter accounts ' + ISNULL(CAST(@actualCreatedCounterAccountCount AS VARCHAR(100)),0)

IF @expectedCreatedCounterAccountCount <> @actualCreatedCounterAccountCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of created TF counter accounts is ' + ISNULL(CAST(@expectedCreatedCounterAccountCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualCreatedCounterAccountCount AS VARCHAR(100)),0)
END
-- END check if count of TF counter accounts to be created is equal to actual value

*/


-- START general invalid record is zero
PRINT '----------------------------'
DECLARE @countOfGeneralInvalidRecord bigint;
SET @countOfGeneralInvalidRecord=(
	select sum(result) from (
	--account without account_balance
	select count(*) as result from accountcore.account a
	left join accountcore.account_balance ab on a.balance=ab.id
	where ab.id is null
	union
	--account_balance without account
	select count(*) from accountcore.account a
	right join accountcore.account_balance ab on a.balance=ab.id
	where a.balance is null
	union
	--account_balance without account
	select count(*) from accountcore.account_balance
	where account_id is null or account_id=0
	union
	--account_balance invalid link with account
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	where a.id<>ab.account_id
	union
	--account without account_type
	select count(*) from accountcore.account a
	left join accountcore.account_type act on a.account_type=act.id
	where act.id is null
	union
	--account without customer_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.customer_account ca on a.id=ca.id
	where ca.id is null and act.is_internal=0
	union
	--customer_account without account
	select count(*) from accountcore.account a
	right join accountcore.customer_account ca on a.id=ca.id
	where a.id is null
	union
	--account without internal_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.internal_account ia on a.id=ia.id
	where ia.id is null and act.is_internal=1
	union
	--internal_account without account
	select count(*) from accountcore.account a
	right join accountcore.internal_account ia on a.id=ia.id
	where a.id is null
	union
	--customer account with null contract
	select count(*) from accountcore.customer_account ca where ca.contract is null
	union
	--account without current_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join currentaccount.current_account ca on ca.number=a.number
	where code in ('CA', 'CB') and ca.number is null
	union
	--current_account without account
	select count(*) from accountcore.account a
	right join currentaccount.current_account ca on ca.number=a.number
	where a.number is null
	union
	--customer_account without account_owner
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_owner ao on ao.account=ca.id
	where ao.account is null
	union
	--account without nostro_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join currentaccount.nostro_account ca on ca.number=a.number
	where code in ('CN', 'CV') and ca.number is null
	union
	--nostro_account without account
	select count(*) from accountcore.account a
	right join currentaccount.nostro_account ca on ca.number=a.number
	where a.number is null
	union
	--account_owner without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_owner ao on ao.account=ca.id
	where ca.id is null
	union
	--customer_account without account_contract
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_contract ac on ac.id=ca.contract
	where ac.id is null
	union
	--account_contract without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_contract ac on ac.id=ca.contract
	where ca.contract is null
	/*
	union
	--transaction that does not have zero sum
	select count(*) from (
		select transaction_id, sum(transaction_amount) as sum_all from accountcore.monetary_transaction_item 
		group by transaction_id having sum(transaction_amount) <> 0
	) temp_monetary_transaction_item
	union
	-- account balance that is not zero has monetary_transaction_item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	left join accountcore.monetary_transaction_item mti on mti.account=a.id
	where ab.balance_amount - ab.migrated_balance_amount <>0 and mti.account is null
	union
	-- account balance that does not match with monetary transaction item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	join (
		select account, sum(transaction_amount) as sum_of_account from accountcore.monetary_transaction_item group by account
	) temp_monetary_transaction_item on a.id=temp_monetary_transaction_item.account
	where ab.balance_amount<>temp_monetary_transaction_item.sum_of_account
	union
	--  monetary transaction item with invalid side info
	select count(*) from accountcore.monetary_transaction_item where side not in ('DEBIT', 'CREDIT')
	union
	-- DEBIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='DEBIT' and transaction_amount>=0
	union
	-- CREDIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='CREDIT' and transaction_amount<=0
	union
	-- account_value_dated_balance_history without monetary_transaction_item
	select count(*) from accountcore.account_value_dated_balance_history a
	left join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where  temp_monetary_transaction_item.account is null
	union
	-- monetary_transaction_item without account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	right join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where a.date is null
	union
	-- unequal monetary_transaction_item and account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	join (
		select account, value_date, sum(sum_of_transaction_amount) OVER (partition by account order by account, value_date) as daily_sum from(
			select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
		) temp
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where daily_sum<>value_dated_balance_amount
	*/
	) general_temp_table
)
PRINT 'Count of general invalid record is ' + ISNULL(CAST(@countOfGeneralInvalidRecord AS VARCHAR(100)),0)
IF @countOfGeneralInvalidRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of general invalid record should be zero but actual value is ' + ISNULL(CAST(@countOfGeneralInvalidRecord AS VARCHAR(100)),0)
END
-- END general invalid record is zero



/*
--eklenmesi gereken sorgular
select * from accountcore.customer_account ca where ca.contract is null

--account without current_account
select count(*) from accountcore.account a
join accountcore.account_type act on a.account_type=act.id
left join currentaccount.current_account ca on ca.number=a.number
where code in ('CA', 'CB') and ca.number is null


--current_account without account
select count(*) from accountcore.account a
right join currentaccount.current_account ca on ca.number=a.number
where a.number is null

	--account without nostro_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join currentaccount.nostro_account ca on ca.number=a.number
	where code in ('CN', 'CV') and ca.number is null
	union
	--nostrot_account without account
	select count(*) from accountcore.account a
	right join currentaccount.nostro_account ca on ca.number=a.number
	where a.number is null

--/services/accountcore/api/accountbalancecheck/checkaccountbalancenothavingaccount
--RIGHT JOIN yazılmış commonsta ama native query değil right join çalışmıyor olabilir
SELECT a.id, a.balance, a.currency, b.id, b.account_id, b.balance_currency, b.blocked_balance_currency, b.overdraft_limit_currency
FROM accountcore.account a JOIN accountcore.account_balance b ON a.balance = b.id WHERE a.id = null


SELECT ab.account_id, count(*) FROM accountcore.account_balance ab
where ab.account_id > 0
GROUP BY ab.account_id
HAVING count(*) > 1


SELECT ca.contract, count(*) FROM accountcore.customer_account ca 
GROUP BY ca.contract
HAVING count(*) > 1



*/
