EXEC tSQLt.NewTestClass 'AccountIntegrity';
GO

/* Record Counts */

/* Data Checks */
CREATE PROCEDURE AccountIntegrity.[test that balance of closed accounts are zero]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
    SELECT @actual=COUNT(*) FROM account.account_definition INNER JOIN account.account_balance On account_balance.id = account_definition.balance WHERE account_definition.is_closed=1 AND account_balance.balance_amount>0
	PRINT 'Count of balance of closed accounts not zero ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

CREATE PROCEDURE AccountIntegrity.[test that data in is_closed and closed_date are compliant]
AS
BEGIN
    DECLARE @actual INT;
    DECLARE @expected INT;    
    SELECT @actual=COUNT(*) FROM account.account_definition WHERE (account_definition.is_closed=1 AND account_definition.close_date IS NULL) OR (account_definition.is_closed=0 AND account_definition.close_date IS NOT NULL)
	PRINT 'Count of records that data in is_closed and closed_date are not compliant ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected=0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO