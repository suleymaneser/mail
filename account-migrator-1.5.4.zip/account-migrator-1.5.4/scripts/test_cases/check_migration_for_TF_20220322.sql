DECLARE @existingAccountCount int;  
DECLARE @existingAccountBalanceSum bigint;  
SET  @existingAccountCount = 0;
SET  @existingAccountBalanceSum = 0;

-- START check if count of open TF deals to be migrated is equal to created TF accounts 
PRINT '----------------------------'
DECLARE @expectedMigratedDealAccountCount int;   
SET @expectedMigratedDealAccountCount=(
	SELECT COUNT(*) FROM ydsm.deal join ydsm.dtyp on d1typ=d2typ where d2typ0 in ('E', 'I') and d1arc<>'A'
)
PRINT 'Count of TF deals to be migrated ' + ISNULL(CAST(@expectedMigratedDealAccountCount AS VARCHAR(100)),0)

DECLARE @actualMigratedDealAccountCount int;
SET @actualMigratedDealAccountCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('E','I')
)
SET @actualMigratedDealAccountCount = @actualMigratedDealAccountCount - @existingAccountCount
PRINT 'Count of created TF accounts ' + ISNULL(CAST(@actualMigratedDealAccountCount AS VARCHAR(100)),0)

IF @expectedMigratedDealAccountCount <> @actualMigratedDealAccountCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of created TF accounts is ' + ISNULL(CAST(@expectedMigratedDealAccountCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedDealAccountCount AS VARCHAR(100)),0)
END
-- END check if count of open TF deals to be migrated is equal to created TF accounts 


-- START check if count of open TF deals to be migrated is equal to created TF records 
PRINT '----------------------------'
DECLARE @expectedMigratedDealRecordCount int;   
SET @expectedMigratedDealRecordCount=(
	SELECT COUNT(*) FROM ydsm.deal join ydsm.dtyp on d1typ=d2typ where d2typ0 in ('E', 'I') and d1arc<>'A'
)
PRINT 'Count of TF deals to be migrated ' + ISNULL(CAST(@expectedMigratedDealRecordCount AS VARCHAR(100)),0)

DECLARE @actualMigratedDealRecordCount1 int;
SET @actualMigratedDealRecordCount1=(
	SELECT COUNT(*) from tradefinance.export_file
)
SET @actualMigratedDealRecordCount1 = @actualMigratedDealRecordCount1 - @existingAccountCount
PRINT 'Count of created TF (export) records ' + ISNULL(CAST(@actualMigratedDealRecordCount1 AS VARCHAR(100)),0)

DECLARE @actualMigratedDealRecordCount2 int;
SET @actualMigratedDealRecordCount1=(
	SELECT COUNT(*) from tradefinance.export_file
)
SET @actualMigratedDealRecordCount2 = @actualMigratedDealRecordCount2 - @existingAccountCount
PRINT 'Count of created TF (import) records ' + ISNULL(CAST(@actualMigratedDealRecordCount2 AS VARCHAR(100)),0)

IF @expectedMigratedDealRecordCount <> @actualMigratedDealRecordCount1 + @actualMigratedDealRecordCount2
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of created TF redords is ' + ISNULL(CAST(@expectedMigratedDealRecordCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST((@actualMigratedDealRecordCount1 + @actualMigratedDealRecordCount2) AS VARCHAR(100)),0)
END
-- END check if count of open TF deals to be migrated is equal to created TF records 


-- START check if sum of balances of open TF deals to be migrated is equal to created TF accounts 
-- the sum value is on purpose independent of currency
PRINT '----------------------------'
DECLARE @expectedMigratedDealBalanceSum bigint;   
SET @expectedMigratedDealBalanceSum=(
	SELECT sum(d11amt) FROM ydsm.deal 
	join ydsm.dtaf on d1brn=d11brn and d1typ=d11typ and d1ref=d11ref  
	join ydsm.dtyp on d1typ=d2typ 
	where d2typ0 in ('E', 'I') and d1arc<>'A'
)
PRINT 'Sum of balances of TF deals to be migrated ' + ISNULL(CAST(@expectedMigratedDealBalanceSum AS VARCHAR(100)),0)

DECLARE @actualMigratedDealBalanceSum bigint;
SET @actualMigratedDealBalanceSum=(
	SELECT sum(balance_amount) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id 
	join accountcore.account_type act on a.account_type=act.id 
	join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('E','I')
)
SET @actualMigratedDealBalanceSum = @actualMigratedDealBalanceSum - @existingAccountBalanceSum
PRINT 'Sum of balances of created TF accounts ' + ISNULL(CAST(@actualMigratedDealBalanceSum AS VARCHAR(100)),0)

IF @expectedMigratedDealBalanceSum <> @actualMigratedDealBalanceSum * (-1)
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected sum of balances of created TF accounts is ' + ISNULL(CAST(@expectedMigratedDealBalanceSum AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualMigratedDealBalanceSum AS VARCHAR(100)),0)
END
-- END check if sum of balances of open TF deals to be migrated is equal to created TF accounts 

-- START check if sum of balances based on branch and currency is zero
-- all records should have balance_amount=0
PRINT '----------------------------'
DECLARE @countOfInvalidBalanceSum bigint;
SET @countOfInvalidBalanceSum=(select count(*) from (
	select a.owning_unit_code, a.currency, sum(balance_amount) as balance_amount from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	join accountcore.account_type act on a.account_type=act.id 
	left join accountcore.product P on p.account_type=act.id 
	where p.application_family_type in ('E','I') or act.code in ('TA', 'TC')
	group by a.owning_unit_code, a.currency
	having sum(balance_amount) <> 0
	) temp
)
PRINT 'Count of invalid balance sum is ' + ISNULL(CAST(@countOfInvalidBalanceSum AS VARCHAR(100)),0)
IF @countOfInvalidBalanceSum <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Sum of balances based on branch and currency should be zero but actual value is ' + ISNULL(CAST(@countOfInvalidBalanceSum AS VARCHAR(100)),0)
END
-- END check if sum of balances based on branch and currency is zero

-- START check if sum of all balances is zero
PRINT '----------------------------'
DECLARE @sumOfBalance bigint;
SET @sumOfBalance=(
	select sum(balance_amount) as balance_amount from accountcore.account_balance
)
PRINT 'Sum of all balances is ' + ISNULL(CAST(@sumOfBalance AS VARCHAR(100)),0)
IF @sumOfBalance <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Sum of all balances should be zero but actual value is ' + ISNULL(CAST(@sumOfBalance AS VARCHAR(100)),0)
END
-- END check if sum of all balances is zero

-- START check if count of balance record that does not match any account record is zero
PRINT '----------------------------'
DECLARE @countOfOrphanAccountBalanceRecord bigint;
SET @countOfOrphanAccountBalanceRecord=(
	select count(*) from accountcore.account
	right join accountcore.account_balance
	on accountcore.account_balance.account_id = accountcore.account.id
	where accountcore.account.id is null
)
PRINT 'Count of orphan account_balance records is ' + ISNULL(CAST(@countOfOrphanAccountBalanceRecord AS VARCHAR(100)),0)
IF @countOfOrphanAccountBalanceRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of orphan account_balance records should be zero but actual value is ' + ISNULL(CAST(@countOfOrphanAccountBalanceRecord AS VARCHAR(100)),0)
END
-- END check if sum of all balances is zero

-- START check if count of balance record that is not linked with any account record is zero
PRINT '----------------------------'
DECLARE @countOfUnlinkedAccountBalanceRecord bigint;
SET @countOfUnlinkedAccountBalanceRecord=(
	select count(*) from accountcore.account_balance
	where accountcore.account_balance.account_id=0
)
PRINT 'Count of unlinked account_balance records is ' + ISNULL(CAST(@countOfUnlinkedAccountBalanceRecord AS VARCHAR(100)),0)
IF @countOfUnlinkedAccountBalanceRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of unlinked account_balance records should be zero but actual value is ' + ISNULL(CAST(@countOfUnlinkedAccountBalanceRecord AS VARCHAR(100)),0)
END
-- END check if sum of all balances is zero


-- START check if count of TF counter accounts to be created is equal to actual value
PRINT '----------------------------'
DECLARE @expectedCreatedCounterAccountCount int;   
SET @expectedCreatedCounterAccountCount=(
	select count(*) from (
	SELECT a.owning_unit_code, a.currency, a.account_type, sum(balance_amount) as balance_amount
	FROM accountcore.account a
	JOIN accountcore.account_balance ab on a.balance=ab.id
	JOIN accountcore.account_type act on a.account_type=act.id
	WHERE act.code in (
	SELECT code from accountcore.product
	JOIN accountcore.account_type
	ON accountcore.product.account_type=accountcore.account_type.id
	WHERE accountcore.product.application_family_type in ('E','I'))
	GROUP BY a.owning_unit_code, a.currency, a.account_type) temp_table
)
PRINT 'Count of TF counter accounts to be created ' + ISNULL(CAST(@expectedCreatedCounterAccountCount AS VARCHAR(100)),0)

DECLARE @actualCreatedCounterAccountCount int;
SET @actualCreatedCounterAccountCount=(
	select count(*) from accountcore.account a
	join accountcore.internal_account b on a.id=b.id 
	join accountcore.account_type c on a.account_type=c.id
	where c.code in ('TA', 'TC')
)
PRINT 'Count of created TF counter accounts ' + ISNULL(CAST(@actualCreatedCounterAccountCount AS VARCHAR(100)),0)

IF @expectedCreatedCounterAccountCount <> @actualCreatedCounterAccountCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of created TF counter accounts is ' + ISNULL(CAST(@expectedCreatedCounterAccountCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualCreatedCounterAccountCount AS VARCHAR(100)),0)
END
-- END check if count of TF counter accounts to be created is equal to actual value


-- START check if count of openned account record that has no customer account record is zero
PRINT '----------------------------'
DECLARE @expectedAccountWithNoCustomerAccountCount int;   
SET @expectedAccountWithNoCustomerAccountCount=0
PRINT 'Count of expected account with no customer account ' + ISNULL(CAST(@expectedAccountWithNoCustomerAccountCount AS VARCHAR(100)),0)

DECLARE @actualAccountWithNoCustomerAccountCount int;
SET @actualAccountWithNoCustomerAccountCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	left join accountcore.customer_account b on a.id=b.id 
	left join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('E','I') and b.id is null
)
PRINT 'Count of actual account with no customer account ' + ISNULL(CAST(@actualAccountWithNoCustomerAccountCount AS VARCHAR(100)),0)

IF @expectedAccountWithNoCustomerAccountCount <> @actualAccountWithNoCustomerAccountCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of account with no customer account is ' + ISNULL(CAST(@expectedAccountWithNoCustomerAccountCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualAccountWithNoCustomerAccountCount AS VARCHAR(100)),0)
END
-- END check if count of openned account record that has no customer account record is zero

-- START check if count of openned customer account record that has no account owner record is zero
PRINT '----------------------------'
DECLARE @expectedCustomerAccountWithNoAccountOwnerCount int;   
SET @expectedCustomerAccountWithNoAccountOwnerCount=0
PRINT 'Count of expected customer account with no account owner ' + ISNULL(CAST(@expectedCustomerAccountWithNoAccountOwnerCount AS VARCHAR(100)),0)

DECLARE @actualCustomerAccountWithNoAccountOwnerCount int;
SET @actualCustomerAccountWithNoAccountOwnerCount=(
	SELECT COUNT(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	join accountcore.customer_account b on a.id=b.id 
	left join accountcore.account_owner c on c.account=b.id 
	left join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('E','I') and c.id is null
)
PRINT 'Count of actual customer account with no account owner ' + ISNULL(CAST(@expectedCustomerAccountWithNoAccountOwnerCount AS VARCHAR(100)),0)

IF @expectedCustomerAccountWithNoAccountOwnerCount <> @actualCustomerAccountWithNoAccountOwnerCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of customer account with no account owner is ' + ISNULL(CAST(@expectedCustomerAccountWithNoAccountOwnerCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualCustomerAccountWithNoAccountOwnerCount AS VARCHAR(100)),0)
END
-- END check if count of openned customer account record that has no account owner record is zero

-- START check count of account owner record that does not match any customer account record is zero
PRINT '----------------------------'
DECLARE @countOfOrphanAccountOwnerRecord bigint;
SET @countOfOrphanAccountOwnerRecord=(
	select count(*) from (
		select ao.* from accountcore.account_owner ao where account is null
		union
		select ao.* from accountcore.account_owner ao
		left join accountcore.customer_account ca on ao.account=ca.id
		where ca.id is null
	) temp_table
)
PRINT 'Count of orphan account_Owner records is ' + ISNULL(CAST(@countOfOrphanAccountOwnerRecord AS VARCHAR(100)),0)
IF @countOfOrphanAccountOwnerRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of orphan account_Owner records should be zero but actual value is ' + ISNULL(CAST(@countOfOrphanAccountOwnerRecord AS VARCHAR(100)),0)
END
-- END check count of account owner record that does not match any customer account record is zero

-- START check if count of openned customer account record that has no account contract record is zero
PRINT '----------------------------'
DECLARE @expectedCustomerAccountWithNoAccountContractCount int;   
SET @expectedCustomerAccountWithNoAccountContractCount=0
PRINT 'Count of expected customer account with no account contract ' + ISNULL(CAST(@expectedCustomerAccountWithNoAccountContractCount AS VARCHAR(100)),0)

DECLARE @actualCustomerAccountWithNoAccountContractCount int;
SET @actualCustomerAccountWithNoAccountContractCount=(
	SELECT COUNT(*) from (
	select a.* from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	join accountcore.customer_account b on a.id=b.id 
	left join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('E','I') and b.contract is null
    union
	select a.* from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id 
	join accountcore.customer_account b on a.id=b.id 
	left join accountcore.account_contract ac on b.contract=ac.id
	left join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('E','I') and ac.id is null
	) temp_table
)
PRINT 'Count of actual customer account with no account contract ' + ISNULL(CAST(@expectedCustomerAccountWithNoAccountContractCount AS VARCHAR(100)),0)

IF @expectedCustomerAccountWithNoAccountContractCount <> @actualCustomerAccountWithNoAccountContractCount
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Expected count of customer account with no account contract is ' + ISNULL(CAST(@expectedCustomerAccountWithNoAccountContractCount AS VARCHAR(100)),0) +
		' but actual value is ' + ISNULL(CAST(@actualCustomerAccountWithNoAccountContractCount AS VARCHAR(100)),0)
END
-- END check if count of openned customer account record that has no account owner record is zero

-- START check count of account contract record that does not match any customer account record is zero
PRINT '----------------------------'
DECLARE @countOfOrphanAccountContractRecord bigint;
SET @countOfOrphanAccountContractRecord=(
	select count(*) from accountcore.account_Contract ac
	left join accountcore.customer_account ca on ca.contract=ac.id
	where ca.contract is null
)
PRINT 'Count of orphan account_Contract records is ' + ISNULL(CAST(@countOfOrphanAccountContractRecord AS VARCHAR(100)),0)
IF @countOfOrphanAccountContractRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of orphan account_Contract records should be zero but actual value is ' + ISNULL(CAST(@countOfOrphanAccountContractRecord AS VARCHAR(100)),0)
END
-- END check count of account Contract record that does not match any customer account record is zero

-- START general invalid record is zero
PRINT '----------------------------'
DECLARE @countOfGeneralInvalidRecord bigint;
SET @countOfGeneralInvalidRecord=(
	select sum(result) from (
	--account without account_balance
	select count(*) as result from accountcore.account a
	left join accountcore.account_balance ab on a.balance=ab.id
	where ab.id is null
	union
	--account_balance without account
	select count(*) from accountcore.account a
	right join accountcore.account_balance ab on a.balance=ab.id
	where a.balance is null
	union
	--account_balance without account
	select count(*) from accountcore.account_balance
	where account_id is null or account_id=0
	union
	--account_balance invalid link with account
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	where a.id<>ab.account_id
	union
	--account without account_type
	select count(*) from accountcore.account a
	left join accountcore.account_type act on a.account_type=act.id
	where act.id is null
	union
	--account without customer_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.customer_account ca on a.id=ca.id
	where ca.id is null and act.is_internal=0
	union
	--customer_account without account
	select count(*) from accountcore.account a
	right join accountcore.customer_account ca on a.id=ca.id
	where a.id is null
	union
	--account without internal_account
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join accountcore.internal_account ia on a.id=ia.id
	where ia.id is null and act.is_internal=1
	union
	--internal_account without account
	select count(*) from accountcore.account a
	right join accountcore.internal_account ia on a.id=ia.id
	where a.id is null
	union
	--account without export_file
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join tradefinance.export_file ef on a.number=ef.account_number
	left join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('E') and ef.account_number is null
	union
	--export_file without account
	select count(*) from accountcore.account a
	right join tradefinance.export_file ef on a.number=ef.account_number
	where a.number is null
	union
	--account without import_file
	select count(*) from accountcore.account a
	join accountcore.account_type act on a.account_type=act.id
	left join tradefinance.import_file imf on a.number=imf.account_number
	left join accountcore.product P on p.account_type=act.id 
	where application_family_type in ('I') and imf.account_number is null
	union
	--import_file without account
	select count(*) from accountcore.account a
	right join tradefinance.import_file imf on a.number=imf.account_number
	where a.number is null
	union
	--customer_account without account_owner
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_owner ao on ao.account=ca.id
	where ao.account is null
	union
	--account_owner without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_owner ao on ao.account=ca.id
	where ca.id is null
	union
	--customer_account without account_contract
	select count(*) from accountcore.customer_account ca
	left join accountcore.account_contract ac on ac.id=ca.contract
	where ac.id is null
	union
	--account_contract without customer_account
	select count(*) from accountcore.customer_account ca
	right join accountcore.account_contract ac on ac.id=ca.contract
	where ca.contract is null
	union
	--transaction that does not have zero sum
	select count(*) from (
		select transaction_id, sum(transaction_amount) as sum_all from accountcore.monetary_transaction_item 
		group by transaction_id having sum(transaction_amount) <> 0
	) temp_monetary_transaction_item
	union
	-- account balance that is not zero has monetary_transaction_item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	left join accountcore.monetary_transaction_item mti on mti.account=a.id
	where ab.balance_amount - ab.migrated_balance_amount <>0 and mti.account is null
	union
	-- account balance that does not match with monetary transaction item
	select count(*) from accountcore.account a
	join accountcore.account_balance ab on a.balance=ab.id
	join (
		select account, sum(transaction_amount) as sum_of_account from accountcore.monetary_transaction_item group by account
	) temp_monetary_transaction_item on a.id=temp_monetary_transaction_item.account
	where ab.balance_amount<>temp_monetary_transaction_item.sum_of_account
	union
	--  monetary transaction item with invalid side info
	select count(*) from accountcore.monetary_transaction_item where side not in ('DEBIT', 'CREDIT')
	union
	-- DEBIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='DEBIT' and transaction_amount>=0
	union
	-- CREDIT monetary transaction item that is greater than zero
	select count(*) from accountcore.monetary_transaction_item where side='CREDIT' and transaction_amount<=0
	union
	/*
	-- account_value_dated_balance_history without monetary_transaction_item
	select count(*) from accountcore.account_value_dated_balance_history a
	left join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where  temp_monetary_transaction_item.account is null
	union
	*/
	-- monetary_transaction_item without account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	right join (
		select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where a.date is null
	union
	-- unequal monetary_transaction_item and account_value_dated_balance_history  
	select count(*) from accountcore.account_value_dated_balance_history a
	join (
		select account, value_date, sum(sum_of_transaction_amount) OVER (partition by account order by account, value_date) as daily_sum from(
			select account, value_date, sum(transaction_amount) as sum_of_transaction_amount from accountcore.monetary_transaction_item group by account, value_date
		) temp
	) temp_monetary_transaction_item on a.account=temp_monetary_transaction_item.account and a.date=temp_monetary_transaction_item.value_date
	where daily_sum<>value_dated_balance_amount
	) general_temp_table
)
PRINT 'Count of general invalid record is ' + ISNULL(CAST(@countOfGeneralInvalidRecord AS VARCHAR(100)),0)
IF @countOfGeneralInvalidRecord <> 0
BEGIN
	PRINT '***********************ERROR******************'
	PRINT 'Count of general invalid record should be zero but actual value is ' + ISNULL(CAST(@countOfGeneralInvalidRecord AS VARCHAR(100)),0)
END
-- END general invalid record is zero



