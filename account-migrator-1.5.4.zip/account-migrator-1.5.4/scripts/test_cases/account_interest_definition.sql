EXEC tSQLt.NewTestClass 'AccountInterestDefinition';
GO

/* Record Counts */
CREATE PROCEDURE AccountInterestDefinition.[test that record counts of account_interest_definition and AINT/DINT are equal]
AS
BEGIN
	DECLARE @expected INT;
	DECLARE @AINT_C_count INT; 	
	DECLARE @AINT_D_count INT;
	DECLARE @DINTcount INT;    
	SET @actual=(SELECT COUNT(*) FROM account.[account_interest_definition])
	PRINT 'Record Count of [account_interest_definition] Table ... ' + STR(ISNULL(@actual,0))
	SET @AINT_C_count=(SELECT COUNT(*) FROM ydsm.[AINT] JOIN ydsm.ACCT ON a8brn = a1brn AND a8acc = a1acc AND a8sfx = a1sfx WHERE a8cifq NOT IN ('','000'))
	PRINT '  Record Count of [AINT].a8cifq not space  ...... ' + STR(ISNULL(@AINT_C_count,0))
	SET @AINT_D_count=(SELECT COUNT(*) FROM ydsm.[AINT] JOIN ydsm.ACCT ON a8brn = a1brn AND a8acc = a1acc AND a8sfx = a1sfx WHERE a8difq NOT IN ('','000'))
	PRINT '  Record Count of [AINT].a8difq not space ....... ' + STR(ISNULL(@AINT_D_count,0))
	SET @DINTcount=(SELECT COUNT(*) FROM ydsm.[DINT])
	PRINT '  Record Count of [DINT] Table .................. ' + STR(ISNULL(@DINTcount,0))
    SET @expected = @AINT_C_count + @AINT_D_count + @DINTcount
    PRINT 'Total Record Count of ISUBA Tables .................... ' + STR(ISNULL(@expected,0))
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/* Fields */
CREATE PROCEDURE AccountInterestDefinition.[test that version field is zero]
AS
BEGIN
    DECLARE @actual int;
    DECLARE @expected int;   
    SET @actual=(SELECT COUNT(*) FROM account.[account_interest_definition] WHERE version <> 0)
	PRINT 'Count of records where version is not zero ... ' + ISNULL(CAST(@actual AS VARCHAR(100)),0)
	SET @expected = 0
    EXEC tSQLt.AssertEquals @expected, @actual;
END;
GO

/* Function/Procedure */
/*
IF OBJECT_ID (N'dbo.ValidateInterestFields', N'P') IS NOT NULL
    DROP PROCEDURE dbo.ValidateInterestFields;
GO
CREATE PROCEDURE ValidateInterestFields
	@TargetField VARCHAR(100),
	@SourceField VARCHAR(100),
	@VerifyCondition VARCHAR(300),
	@actual INT OUTPUT
AS 
DECLARE @ExecQuery VARCHAR(MAX)
IF OBJECT_ID('tempdb..#TEMPTRESULT') IS NOT NULL DROP TABLE #TEMPTRESULT;
CREATE TABLE #TEMPTRESULT (QueryResult INT);
SET @ExecQuery ='DECLARE @actual int;IF OBJECT_ID(''tempdb..#TEMPT'') IS NOT NULL DROP TABLE #TEMPT;'
				+'SELECT * INTO #TEMPT FROM (SELECT dbo.FormAccountNumber(a1brn,a1acc,a1sfx) AS Temp_AccountNo, {ISUBA_FIELD_AS_SOURCE} FROM ydsm.[ACCT]) TempData;'
				+'SET @actual=(SELECT COUNT(*) FROM [{RALLY_TABLE}] INNER JOIN #TEMPT ON [number] = Temp_AccountNo ' 
				+'WHERE {VERIFY_CONDITION});'
				+'INSERT INTO #TEMPTRESULT VALUES (@actual);' 
				+'SELECT * FROM #TEMPTRESULT;' 
				+'PRINT ''Count of records {RALLY_FIELD_AS_TARGET} values are not matched to source values ... '' + ISNULL(CAST(@actual AS VARCHAR(100)),0);'
SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_TABLE}',@SourceTable)
SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_TABLE}',@TargetTable)
SET @ExecQuery = REPLACE(@ExecQuery,'{ISUBA_FIELD_AS_SOURCE}',@SourceField)
SET @ExecQuery = REPLACE(@ExecQuery,'{RALLY_FIELD_AS_TARGET}',@TargetField)
SET @ExecQuery = REPLACE(@ExecQuery,'{VERIFY_CONDITION}',@VerifyCondition)
EXEC (@ExecQuery)
SELECT @actual=MAX(QueryResult) FROM #TEMPTRESULT
GO
*/
/* Batch Test Insert */

