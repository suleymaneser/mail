﻿param(
$UtilityScriptsAbsPath = "d:\Gelisk_Repos\gelisk\scripts\migrations\_UtilityScripts\",
$DBDataSource,
$DBUserName="sa",
$DBPassword="Rdsm_123",
$RallyDBName="RallyGE",
$TableListFile="",
$OutFilePath="D:\",
$PropertiesFile="x"
)

. ".\PrepareAccountDTOFunctions.ps1"

Prepare-Batch $DBDataSource $DBUserName $DBPassword $RallyDBName $PropertiesFile $OutFilePath