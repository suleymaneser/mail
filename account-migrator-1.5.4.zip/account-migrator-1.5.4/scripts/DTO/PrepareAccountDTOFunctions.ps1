﻿#####################################################################################
#FUNC*
# Function that returns account project DTO class for given Rally Table
#
#####################################################################################
function Prepare-Batch ($DataSource, $UserName, $Password, $RallyDatabase, $PropertyFile, $OutFilePath) {
    Get-Content ($PropertyFile) | ? {$_.Trim()} `
                                | ? {$_.Substring(0,1) -ne '#'} `
                                | ForEach-Object {
                                        $parts = $_.Split(";")
 
                                        If(!$parts[0] -or !$parts[1] -or !$parts[2] -or !$parts[3] -or !$parts[4]) {throw "Invalid properties line entry <$parts>"}
 
                                        If($parts[2] -eq "NOUPSERT") {
                                            $IsUpsert = $false
                                            $BusinessKeys = $null
                                        } else {
                                            $IsUpsert = $true
                                            $BusinessKeys = $parts[2].Split(",")
                                            If ($BusinessKeys.Count -eq 0) {throw "Must provide NOUPSERT or a valid list of business key fields! <$parts>"}
                                        }
                                        
                                        If( ($parts[3] -ne "NONE") -and ($parts[3] -ne "INSERTONLY") -and ($parts[3] -ne "DEFAULT")) {
                                            throw "Must provide a valid setter control param! <$parts>"
                                        } else {
                                            $SetterCheckConfig = $parts[3]
                                        }
                                        
                                        If( ($parts[4] -ne "IDFORINSERT") -and ($parts[3] -ne "DEFAULT")) {
                                            throw "Must provide a valid setter control param! <$parts>"
                                        } else {
                                            $IdForInsertConfig = $parts[4]
                                        }
                                        
                                        $SchemaName = $parts[0].Trim()

                                        $TableName = $parts[1].Trim()
                                        
                                        $OutFileName = Join-Path -Path $OutFilePath -ChildPath ((ConvertDBObjectNameToCamelCase $TableName $true) + "DTO.java")
                                        
                                        $DTOFile = Prepare-DTO $DataSource $UserName $Password $RallyDatabase $SchemaName $TableName $IsUpsert $BusinessKeys $SetterCheckConfig $IdForInsertConfig

                                        $Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding($False)
                                        
                                        [System.IO.File]::WriteAllLines($OutFileName, $DTOFile, $Utf8NoBomEncoding)

                                    }
}

#####################################################################################
#FUNC*
# Function that returns account project DTO class for given Rally Table
#
#####################################################################################
function Prepare-DTO ($DataSource, $UserName, $Password, $RallyDatabase, $MicroServiceSchemaName, $RallyTableName, $IsUpsert, $BusinessKeys, $SetterCheckConfig, $IdForInsertConfig) {
    . (Join-Path $UtilityScriptsAbsPath -ChildPath "Invoke-Sqlcmd2.ps1")
    
    Write-Host " "
    Write-Host "*****************************************************************************************************"
    Write-Host "**  CREATING DTO FOR TABLE $TableName"
    Write-Host "*****************************************************************************************************"
    Write-Host " "

    $secpasswd = ConvertTo-SecureString $Password -AsPlainText -Force
    $mycreds = New-Object System.Management.Automation.PSCredential ($UserName, $secpasswd)

    $Query = "IF NOT EXISTS(SELECT * FROM $RallyDatabase.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '$RallyTableName' AND TABLE_SCHEMA = '$MicroServiceSchemaName') " +
             "  BEGIN " +
             "  SELECT * FROM $RallyDatabase.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '$RallyTableName' " +
             "  END " +
             " ELSE " +
             "  BEGIN " + 
             "  SELECT * FROM $RallyDatabase.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '$RallyTableName' AND TABLE_SCHEMA = '$MicroServiceSchemaName' " +
             "  END "
    

    Write-Host "Query=$Query"
    Write-Host "DATAs=$DataSource"
    $ColumnList = @(Invoke-Sqlcmd2 -Query $Query -ServerInstance $DataSource -Credential $mycreds | Select TABLE_NAME, COLUMN_NAME, DATA_TYPE)

    If($ColumnList.Count -eq 0){
        throw "No columns found for table $RallyTableName"
    }

    Write-Host "$($ColumnList.Count) columns found for table: $RallyTableName"
    
    Write-Host "--------------------------- "
    Write-Host "**  CREATING CLASS HEADER..."
    Write-Host "--------------------------- "

    $EmptyLine = ""
    $Tab = "    "

    Write-Output "package rally.accountmigrator.domain;"
    Write-Output $EmptyLine

    $BigDecimalExists=$false
    $DateExists=$false
    $OffsetDateTimeExists=$false
    $LocalDateTimeExists=$false
    $LocalDateExists=$false
    $LocalTimeExists=$false
    ForEach($Column in $ColumnList) {
        switch ($Column.DATA_TYPE) { 
          datetime      {$DateExists=$true;break}
          numeric       {$BigDecimalExists=$true;break}
          decimal       {$BigDecimalExists=$true;break}
          datetimeoffset{$OffsetDateTimeExists=$true;break}
          datetime2     {$LocalDateTimeExists=$true;break}
          date          {$LocalDateExists=$true;break}
          time          {$LocalTimeExists=$true;break}
        }
    }

    If($BigDecimalExists) {
        Write-Output "import java.math.BigDecimal;"
    }
    Write-Output "import java.sql.Connection;"
    Write-Output "import java.sql.PreparedStatement;"
    Write-Output "import java.sql.ResultSet;"
    Write-Output "import java.sql.SQLException;"
    Write-Output "import java.sql.Statement;"
    If($LocalDateExists) {
        Write-Output "import java.time.LocalDate;"
    }
    If($LocalDateTimeExists) {
        Write-Output "import java.time.LocalDateTime;"
    }
    If($LocalTimeExists) {
        Write-Output "import java.time.LocalTime;"
    }
    If($OffsetDateTimeExists) {
        Write-Output "import java.time.OffsetDateTime;"
        Write-Output "import java.time.format.DateTimeFormatter;"
    }
    If($DateExists) {
        Write-Output "import java.util.Date;"
    }
    Write-Output "import java.util.HashMap;"
    Write-Output "import java.util.Map;"
    Write-Output "import java.util.Map.Entry;"
    Write-Output $EmptyLine   

    If($DateExists) {
        Write-Output "import rally.accountmigrator.service.MigratorUtil;"
        Write-Output $EmptyLine      
    }
    
    Write-Output "/**"
    Write-Output "*"
    Write-Output "* @author RallyDevTeam"
    Write-Output "* THIS CLASS IS AUTOMAGICALLY GENERATED, DO NOT MANUALLY CHANGE IT!!!"
    Write-Output "*"
    Write-Output "*/"
    Write-Output $EmptyLine
    $ConvertedTableName = ConvertDBObjectNameToCamelCase $RallyTableName $true
    Write-Output "public class $($ConvertedTableName)DTO {"
    Write-Output $EmptyLine
    If($OffsetDateTimeExists) {
        Write-Output "$($Tab)DateTimeFormatter FORMATTER_TO_DB = DateTimeFormatter.ofPattern(`"yyyy-MM-dd HH:mm:ss.nnnnnnnnn xxx`");"
        Write-Output $EmptyLine
    }

    Write-Host "--------------------------- "
    Write-Host "**  CREATING PARAMETERS..."
    Write-Host "--------------------------- "

    $FieldCounter = 0
    ForEach($Column in $ColumnList) {
        
        $FieldCounter = $FieldCounter + 1
        $JavaDataType = ConvertDBTypeToJavaType($Column)
        $ConvertedColumnName =ConvertDBObjectNameToCamelCase $Column.COLUMN_NAME $false
        Write-Output "$($Tab)// $FieldCounter  $($Column.COLUMN_NAME) $($Column.DATA_TYPE)"
        Write-Output "$($Tab)private $($JavaDataType) $($ConvertedColumnName);"
        Write-Output $EmptyLine
    }

    Write-Host "------------------------------------- "
    Write-Host "**  CREATING CONSTRUCTOR AND UTILS..."
    Write-Host "------------------------------------- "

    Write-Output "$($Tab)private Map<String, Boolean> calledList = new HashMap<String, Boolean>();"
    Write-Output $EmptyLine

    Write-Output "$($Tab)public $($ConvertedTableName)DTO() {"
	Write-Output "$($Tab)$($Tab)this.fillCallableList();"
	Write-Output "$($Tab)}"
    Write-Output $EmptyLine

    Write-Output "$($Tab)private void checkCalledList() {"
	Write-Output "$($Tab)$($Tab)if(this.calledList.values().contains(false)) {"
	Write-Output "$($Tab)$($Tab)$($Tab)for(Entry<String, Boolean> entry : this.calledList.entrySet()) {"
	Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)if (!entry.getValue()) {"
	Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab)System.out.println(entry.getKey() + "" is not called in $($ConvertedTableName)DTO!"");"
	Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)}"
	Write-Output "$($Tab)$($Tab)$($Tab)}"
	Write-Output "$($Tab)$($Tab)$($Tab)throw new RuntimeException(""A method is not called in $($ConvertedTableName)DTO!"");"
	Write-Output "$($Tab)$($Tab)}"
	Write-Output "$($Tab)}"
    Write-Output $EmptyLine

    Write-Output "$($Tab)private void addCallableElement (String called) {"
	Write-Output "$($Tab)$($Tab)this.calledList.put(called, false);"
	Write-Output "$($Tab)}"
    Write-Output $EmptyLine

	Write-Output "$($Tab)private void modifyCallableElement (String called, Boolean bool) {"
	Write-Output "$($Tab)$($Tab)this.calledList.put(called, bool);"
	Write-Output "$($Tab)}"
    Write-Output $EmptyLine

	Write-Output "$($Tab)private void fillCallableList() {"
	
	$FilteredColumnList = $null
	If($IdForInsertConfig -eq "IDFORINSERT") {
		$FilteredColumnList = @($ColumnList)
	} else {
		$FilteredColumnList = @($ColumnList | ? {$_.COLUMN_NAME -ne 'id'})
	}
	
    $FilteredColumnList | ForEach {
            $UpperConvertedColumnName = ConvertDBObjectNameToCamelCase $_.COLUMN_NAME $true
            Write-Output "$($Tab)$($Tab)this.addCallableElement(""set$($UpperConvertedColumnName)"");"
        }
	Write-Output "$($Tab)}"
    Write-Output $EmptyLine

    Write-Host "--------------------------- "
    Write-Host "**  CREATING GETTER/SETTERS..."
    Write-Host "--------------------------- "

    ForEach($Column in $ColumnList) {
        
        $JavaDataType = ConvertDBTypeToJavaType($Column)
        $ConvertedColumnName =ConvertDBObjectNameToCamelCase $Column.COLUMN_NAME $false
        $UpperConvertedColumnName =ConvertDBObjectNameToCamelCase $Column.COLUMN_NAME $true
        
        Write-Output "$($Tab)public void set$($UpperConvertedColumnName)($($JavaDataType) $($ConvertedColumnName)) {"
        Write-Output "$($Tab)$($Tab)this.$($ConvertedColumnName) = $($ConvertedColumnName);"
        If(($IdForInsertConfig -eq "IDFORINSERT") -or ($Column.COLUMN_NAME -ne 'id')) {
           Write-Output "$($Tab)$($Tab)this.modifyCallableElement(""set$($UpperConvertedColumnName)"",true);"
        }
        Write-Output "$($Tab)}"
        Write-Output $EmptyLine

        Write-Output "$($Tab)public $($JavaDataType) get$($UpperConvertedColumnName)() {"
        Write-Output "$($Tab)$($Tab)return $($ConvertedColumnName);"
        Write-Output "$($Tab)}"
        Write-Output $EmptyLine
    }

    If($IsUpsert) {
    
        Write-Host "--------------------------- "
        Write-Host "**  CREATING UPSERT METHOD.."
        Write-Host "--------------------------- "

        Write-Output "$($Tab)public Long upsert$($ConvertedTableName)(Connection conn) {"
        Write-Output $EmptyLine
        Write-Output "$($Tab)$($Tab)Long id = null;"
        Write-Output "$($Tab)$($Tab)PreparedStatement stmt = null;"
        Write-Output $EmptyLine
        Write-Output "$($Tab)$($Tab)try {"
        Write-Output "$($Tab)$($Tab)$($Tab)stmt = conn"
        
        $WhereCondition = ""
        $BusinessKeys | ForEach-Object {
                            If($WhereCondition -ne "") {$WhereCondition = $WhereCondition + " and "}
                            $WhereCondition = $WhereCondition + "[$_] = ?"
                        }
        
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab).prepareStatement(""SELECT * FROM [$MicroServiceSchemaName].[$RallyTableName] WHERE $WhereCondition"");"
        Write-Output $EmptyLine

        $FieldCounter = 0
        $BusinessKeys | ForEach-Object {
                            $FieldCounter = $FieldCounter + 1
                            $InfoSchemaProperty = GetInformationSchemaProperties $DataSource $UserName $Password $RallyDatabase $RallyTableName $_
                            $SqlType = ConvertDBTypeToSqlType($InfoSchemaProperty)
                            $JdbcType = ConvertDBTypeToJdbcType($InfoSchemaProperty)
                            $UpperConvertedColumnName =ConvertDBObjectNameToCamelCase $_ $true

                            $JdbcGetter = "this.get$UpperConvertedColumnName()"
                            $JdbcSetterStatement = FormPreparedStatementSetter $InfoSchemaProperty $JdbcGetter

                            Write-Output "$($Tab)$($Tab)$($Tab)if (this.get$($UpperConvertedColumnName)() == null) {"
                            Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)stmt.setNull($FieldCounter, $SqlType);"
                            Write-Output "$($Tab)$($Tab)$($Tab)} else {"
                            Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)stmt.set$JdbcType($FieldCounter, $JdbcSetterStatement);"
                            Write-Output "$($Tab)$($Tab)$($Tab)}"
                            Write-Output $EmptyLine
                        }

        Write-Output "$($Tab)$($Tab)$($Tab)ResultSet rs = stmt.executeQuery();"
        Write-Output $EmptyLine
        Write-Output "$($Tab)$($Tab)$($Tab)if (rs.next()) {"

        $DisplayCondition = ""
        $BusinessKeys | ForEach-Object {
                            $UpperConvertedColumnName =ConvertDBObjectNameToCamelCase $_ $true
                            $DisplayCondition = $DisplayCondition + " + "" [$_]:"" + this.get$UpperConvertedColumnName()"
                        }

        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)System.out.println(""upsert$($ConvertedTableName) UPDATE:"" $DisplayCondition);"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)this.setId(rs.getLong(""id""));"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)id = update$($ConvertedTableName)(conn);"
        Write-Output "$($Tab)$($Tab)$($Tab)} else {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)System.out.println(""upsert$($ConvertedTableName) INSERT:"" $DisplayCondition);"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)id = insert$($ConvertedTableName)(conn);"
        Write-Output "$($Tab)$($Tab)$($Tab)}"        
        Write-Output $EmptyLine
     
        Write-Output "$($Tab)$($Tab)} catch (SQLException e) {" 
        Write-Output "$($Tab)$($Tab)$($Tab)e.printStackTrace();"
        Write-Output "$($Tab)$($Tab)$($Tab)throw new RuntimeException(""upsert$($ConvertedTableName) failed, exiting..."");"
        Write-Output "$($Tab)$($Tab)} finally {"
        Write-Output "$($Tab)$($Tab)$($Tab)if (stmt != null) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)try {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab)stmt.close();"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)} catch (SQLException e) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab)e.printStackTrace();"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)}"
        Write-Output "$($Tab)$($Tab)$($Tab)}"
        Write-Output "$($Tab)$($Tab)}"
        
        Write-Output $EmptyLine

        Write-Output "$($Tab)$($Tab)return id;"
        Write-Output $EmptyLine
        Write-Output "$($Tab)}"
        Write-Output $EmptyLine
                
    }

    If($true) {
    
        Write-Host "--------------------------- "
        Write-Host "**  CREATING INSERT METHOD.."
        Write-Host "--------------------------- "

        Write-Output "$($Tab)public Long insert$($ConvertedTableName)(Connection conn) {"
        Write-Output $EmptyLine
        
        If(($SetterCheckConfig -eq "DEFAULT") -or ($SetterCheckConfig -eq "INSERTONLY")) {
            Write-Output "$($Tab)$($Tab)this.checkCalledList();"
            Write-Output $EmptyLine
        }
        
        Write-Output "$($Tab)$($Tab)Long savedId = null;"
        Write-Output "$($Tab)$($Tab)PreparedStatement stmt = null;"
        Write-Output $EmptyLine
        Write-Output "$($Tab)$($Tab)try {"
        Write-Output "$($Tab)$($Tab)$($Tab)stmt = conn.prepareStatement(""INSERT INTO [$MicroServiceSchemaName].[$RallyTableName] """
        Write-Output $EmptyLine       
        
        If($IdForInsertConfig -eq "IDFORINSERT") {
        	$FilteredColumnList = @($ColumnList)
        } else { 
        	$FilteredColumnList = @($ColumnList | ? {$_.COLUMN_NAME -ne 'id'})
        }
        
        $Counter = 0
        $IsFirst = $true

        $FilteredColumnList | ForEach-Object {
                        $Counter = $Counter + 1
                        If ($Counter -eq $FilteredColumnList.Count) {
                            Write-Output "$($Tab)$($Tab)$($Tab)+ ""[$($_.COLUMN_NAME)])"""
                        } elseIf($IsFirst) {
                            Write-Output "$($Tab)$($Tab)$($Tab)+ ""([$($_.COLUMN_NAME)], """     
                        } else {
                            Write-Output "$($Tab)$($Tab)$($Tab)+ ""[$($_.COLUMN_NAME)], """
                        }
        				Write-Output $EmptyLine
                        $IsFirst = $false
                      }
        
        $Placeholders = ""
        $IsFirst = $true

        $FilteredColumnList | ForEach-Object {
                        If($IsFirst) {
                            $Placeholders = $Placeholders + " ?"
                        } else {
                            $Placeholders = $Placeholders + ", ?"
                        }
                        $IsFirst = $false
                        }

        Write-Output "$($Tab)$($Tab)$($Tab)+ "" VALUES ("""
		Write-Output $EmptyLine
        Write-Output "$($Tab)$($Tab)$($Tab)+ ""$Placeholders"""
		Write-Output $EmptyLine
        Write-Output "$($Tab)$($Tab)$($Tab)+ "")"", Statement.RETURN_GENERATED_KEYS);"
        Write-Output $EmptyLine

        $FieldCounter = 0
        $FilteredColumnList | ForEach-Object {
                    $FieldCounter = $FieldCounter + 1
                    $InfoSchemaProperty = GetInformationSchemaProperties $DataSource $UserName $Password $RallyDatabase $RallyTableName $_.COLUMN_NAME
                    $SqlType = ConvertDBTypeToSqlType($InfoSchemaProperty)
                    $JdbcType = ConvertDBTypeToJdbcType($InfoSchemaProperty)
                    $UpperConvertedColumnName =ConvertDBObjectNameToCamelCase $_.COLUMN_NAME $true

                    $JdbcGetter = "this.get$UpperConvertedColumnName()"
                    $JdbcSetterStatement = FormPreparedStatementSetter $InfoSchemaProperty $JdbcGetter

                    Write-Output "$($Tab)$($Tab)$($Tab)if (this.get$($UpperConvertedColumnName)() == null) {"
                    Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)stmt.setNull($FieldCounter, $SqlType);"
                    Write-Output "$($Tab)$($Tab)$($Tab)} else {"
                    Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)stmt.set$JdbcType($FieldCounter, $JdbcSetterStatement);"
                    Write-Output "$($Tab)$($Tab)$($Tab)}"
                    Write-Output $EmptyLine
                }

        Write-Output "$($Tab)$($Tab)$($Tab)int affectedRows = stmt.executeUpdate();"
        Write-Output "$($Tab)$($Tab)$($Tab)if (affectedRows == 0) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)throw new SQLException(""insert$($ConvertedTableName) failed, no rows affected."");"
        Write-Output "$($Tab)$($Tab)$($Tab)}"
        Write-Output $EmptyLine

        Write-Output "$($Tab)$($Tab)$($Tab)ResultSet generatedKeys = stmt.getGeneratedKeys();"
        Write-Output "$($Tab)$($Tab)$($Tab)if (generatedKeys.next()) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)savedId = generatedKeys.getLong(1);"
        Write-Output "$($Tab)$($Tab)$($Tab)} else {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)throw new SQLException(""insert$($ConvertedTableName) failed, no ID obtained."");"
        Write-Output "$($Tab)$($Tab)$($Tab)}"
        Write-Output $EmptyLine

        Write-Output "$($Tab)$($Tab)} catch (SQLException e) {"
        Write-Output "$($Tab)$($Tab)$($Tab)e.printStackTrace();"
        Write-Output "$($Tab)$($Tab)$($Tab)throw new RuntimeException(""insert$($ConvertedTableName) failed, exiting..."");"
        Write-Output "$($Tab)$($Tab)} finally {"
        Write-Output "$($Tab)$($Tab)$($Tab)if (stmt != null) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)try {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab)stmt.close();"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)} catch (SQLException e) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab)e.printStackTrace();"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)}"
        Write-Output "$($Tab)$($Tab)$($Tab)}"
        Write-Output "$($Tab)$($Tab)}"
        Write-Output $EmptyLine

        Write-Output "$($Tab)$($Tab)return savedId;"
        Write-Output $EmptyLine

        Write-Output "$($Tab)}"
        Write-Output $EmptyLine
        
    }

    If($true) {
    
        Write-Host "--------------------------- "
        Write-Host "**  CREATING UPDATE METHOD.."
        Write-Host "--------------------------- "

        Write-Output "$($Tab)public Long update$($ConvertedTableName)(Connection conn) {"
        Write-Output $EmptyLine

        If($SetterCheckConfig -eq "DEFAULT") {
            Write-Output "$($Tab)$($Tab)this.checkCalledList();"
            Write-Output $EmptyLine
        }

        Write-Output "$($Tab)$($Tab)Long savedId = null;"
        Write-Output "$($Tab)$($Tab)PreparedStatement stmt = null;"
        Write-Output $EmptyLine
        Write-Output "$($Tab)$($Tab)try {"
        Write-Output "$($Tab)$($Tab)$($Tab)stmt = conn.prepareStatement(""UPDATE [$MicroServiceSchemaName].[$RallyTableName] SET """
        Write-Output $EmptyLine       
        
        $FilteredColumnList = @($ColumnList | ? {$_.COLUMN_NAME -ne 'id'})
        $Counter = 0
        $IsFirst = $true

        $FilteredColumnList | ForEach-Object {
                        $Counter = $Counter + 1

                        If ($Counter -eq $FilteredColumnList.Length) {
                            Write-Output "$($Tab)$($Tab)$($Tab)+ ""[$($_.COLUMN_NAME)] = ? """
                        } elseIf($IsFirst) {
                            Write-Output "$($Tab)$($Tab)$($Tab)+ ""[$($_.COLUMN_NAME)] = ?, """
                        } else {
                            Write-Output "$($Tab)$($Tab)$($Tab)+ ""[$($_.COLUMN_NAME)] = ?, """
                        }
						Write-Output $EmptyLine
                        $IsFirst = $false
                      }

        Write-Output "$($Tab)$($Tab)$($Tab)+ "" WHERE [id] = ? "");"
        Write-Output $EmptyLine

        $FieldCounter = 0
        $FilteredColumnList | ForEach-Object {
                    $FieldCounter = $FieldCounter + 1
                    $InfoSchemaProperty = GetInformationSchemaProperties $DataSource $UserName $Password $RallyDatabase $RallyTableName $_.COLUMN_NAME
                    $SqlType = ConvertDBTypeToSqlType($InfoSchemaProperty)
                    $JdbcType = ConvertDBTypeToJdbcType($InfoSchemaProperty)
                    $UpperConvertedColumnName =ConvertDBObjectNameToCamelCase $_.COLUMN_NAME $true

                    $JdbcGetter = "this.get$UpperConvertedColumnName()"
                    $JdbcSetterStatement = FormPreparedStatementSetter $InfoSchemaProperty $JdbcGetter

                    Write-Output "$($Tab)$($Tab)$($Tab)if (this.get$($UpperConvertedColumnName)() == null) {"
                    Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)stmt.setNull($FieldCounter, $SqlType);"
                    Write-Output "$($Tab)$($Tab)$($Tab)} else {"
                    Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)stmt.set$JdbcType($FieldCounter, $JdbcSetterStatement);"
                    Write-Output "$($Tab)$($Tab)$($Tab)}"
                    Write-Output $EmptyLine
                }
		
		$FieldCounter = $FieldCounter + 1
		Write-Output "$($Tab)$($Tab)$($Tab)stmt.setLong($FieldCounter, this.getId());"
        Write-Output $EmptyLine
                    
        Write-Output "$($Tab)$($Tab)$($Tab)int affectedRows = stmt.executeUpdate();"
        Write-Output "$($Tab)$($Tab)$($Tab)if (affectedRows == 0) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)throw new SQLException(""update$($ConvertedTableName) failed, no rows affected."");"
        Write-Output "$($Tab)$($Tab)$($Tab)}"
        Write-Output $EmptyLine

        Write-Output "$($Tab)$($Tab)$($Tab)savedId =  this.getId();"
        Write-Output $EmptyLine

        Write-Output "$($Tab)$($Tab)} catch (SQLException e) {"
        Write-Output "$($Tab)$($Tab)$($Tab)e.printStackTrace();"
        Write-Output "$($Tab)$($Tab)$($Tab)throw new RuntimeException(""update$($ConvertedTableName) failed, exiting..."");"
        Write-Output "$($Tab)$($Tab)} finally {"
        Write-Output "$($Tab)$($Tab)$($Tab)if (stmt != null) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)try {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab)stmt.close();"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)} catch (SQLException e) {"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)$($Tab)e.printStackTrace();"
        Write-Output "$($Tab)$($Tab)$($Tab)$($Tab)}"
        Write-Output "$($Tab)$($Tab)$($Tab)}"
        Write-Output "$($Tab)$($Tab)}"
        Write-Output $EmptyLine

        Write-Output "$($Tab)$($Tab)return savedId;"
        Write-Output $EmptyLine

        Write-Output "$($Tab)}"
        Write-Output $EmptyLine
        
    }

    Write-Host "--------------------------- "
    Write-Host "**  CLOSE FILE..."
    Write-Host "--------------------------- "

    Write-Output "}"
}

#####################################################################################
#FUNC*
# Function that returns camel case converted db column/table name
#
#####################################################################################
function ConvertDBObjectNameToCamelCase($DashedName, $FirstLetterUpperCase) {
    If($DashedName.length -lt 2) {
        throw "String with length smaller than 2 can not be processed in ConvertDBObjectNameToCamelCase function!"
    }
    
    $EnTextInfo = (New-Object system.globalization.cultureinfo 'en-US').TextInfo

    $CamelCase = $EnTextInfo.ToTitleCase($DashedName) -replace "_",""
    If($FirstLetterUpperCase) {
        $FirstLetter = $EnTextInfo.ToUpper($DashedName.Substring(0,1))
    } Else {
        $FirstLetter = $EnTextInfo.ToLower($DashedName.Substring(0,1))
    }
    $CompleteCamelCase = $FirstLetter + $CamelCase.Substring(1)

    $CompleteCamelCase
}

#####################################################################################
#FUNC*
# Function that returns Java SQL type based on db type
#
#####################################################################################

#TODO: Import sqlcmd2 and get rid of utility script path

function GetInformationSchemaProperties($DataSource, $UserName, $Password, $Database, $TableName, $ColumnName) {
    . (Join-Path $UtilityScriptsAbsPath -ChildPath "Invoke-Sqlcmd2.ps1")
    
    Write-Host " "
    Write-Host "*****************************************************************************************************"
    Write-Host "**  QUERYING INFO SCHEMA FOR $TableName & $ColumnName"
    Write-Host "*****************************************************************************************************"
    Write-Host " "

    $secpasswd = ConvertTo-SecureString $Password -AsPlainText -Force
    $mycreds = New-Object System.Management.Automation.PSCredential ($UserName, $secpasswd)

    $Query = "IF NOT EXISTS(SELECT * FROM $Database.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$MicroServiceSchemaName' and TABLE_NAME = '$RallyTableName'  AND COLUMN_NAME = '$ColumnName') " +
         "  BEGIN " +
         "  SELECT * FROM $Database.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '$RallyTableName'  AND COLUMN_NAME = '$ColumnName' " +
         "  END " +
         " ELSE " +
         "  BEGIN " + 
         "  SELECT * FROM $Database.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$MicroServiceSchemaName' and TABLE_NAME = '$RallyTableName'  AND COLUMN_NAME = '$ColumnName' " +
         "  END "
    

    Write-Host "Query=$Query"
    Write-Host "DataSx=$DataSource"
    $ColumnList = Invoke-Sqlcmd2 -Query $Query -ServerInstance $DataSource -Credential $mycreds | Select TABLE_NAME, COLUMN_NAME, DATA_TYPE

    $ColumnList

}

#####################################################################################
#FUNC*
# Function that returns Java SQL type based on db type
#
#####################################################################################
function ConvertDBTypeToSqlType($ColumnProperties) {
    If(!$ColumnProperties) {
        throw "Must provide column properties to ConvertDBTypeToSqlType function!"
    }
    
    switch ($ColumnProperties.DATA_TYPE) 
    { 
      bigint        {"java.sql.Types.BIGINT";break}
      int           {"java.sql.Types.INTEGER";break}
      datetime      {"java.sql.Types.DATE";break}
      varchar       {"java.sql.Types.VARCHAR";break}
      nvarchar      {"java.sql.Types.VARCHAR";break}
      numeric       {"java.sql.Types.NUMERIC";break}
      decimal       {"java.sql.Types.DECIMAL";break}
      bit           {"java.sql.Types.BOOLEAN";break}
      smallint      {"java.sql.Types.BOOLEAN";break}
      tinyint       {"java.sql.Types.BOOLEAN";break}
      time          {"java.sql.Types.TIME";break}
      date          {"java.sql.Types.DATE";break}
      datetimeoffset{"java.sql.Types.VARCHAR";break}
      datetime2     {"java.sql.Types.TIMESTAMP";break}
      default       {"NEWDATATYPE"}
    }
}

#####################################################################################
#FUNC*
# Function that returns Java type based on db type
#
#####################################################################################
function ConvertDBTypeToJavaType($ColumnProperties) {
    If(!$ColumnProperties) {
        throw "Must provide column properties to ConvertDBTypeToJavaType function!"
    }
    
    switch ($ColumnProperties.DATA_TYPE) 
    { 
      bigint        {"Long";break}
      int           {"Integer";break}
      datetime      {"Date";break}
      varchar       {"String";break}
      nvarchar      {"String";break}
      numeric       {"BigDecimal";break}
      decimal       {"BigDecimal";break}
      bit           {"Boolean";break}
      smallint      {"Boolean";break}
      tinyint       {"Boolean";break}
      time          {"LocalTime";break}
      date          {"LocalDate";break}
      tinyint       {"Boolean";break}
      datetimeoffset{"OffsetDateTime";break}
      datetime2     {"LocalDateTime";break}
      default       {"NEWDATATYPE"}
    }
}

#####################################################################################
#FUNC*
# Function that returns Sql Statement type based on db type
#
#####################################################################################
function ConvertDBTypeToJdbcType($ColumnProperties) {
    If(!$ColumnProperties) {
        throw "Must provide column properties to ConvertDBTypeToJdbcType function!"
    }
    
    switch ($ColumnProperties.DATA_TYPE) 
    { 
      bigint        {"Long";break}
      int           {"Int";break}
      datetime      {"Date";break}
      varchar       {"String";break}
      nvarchar      {"String";break}
      numeric       {"BigDecimal";break}
      decimal       {"BigDecimal";break}
      bit           {"Boolean";break}
      smallint      {"Boolean";break}
      tinyint       {"Boolean";break}      
      time          {"Object";break} 
      date          {"Object";break} 
      datetimeoffset{"Object";break}
      datetime2     {"Object";break}
      default       {"NEWDATATYPE"}
    }
}

#####################################################################################
#FUNC*
# Function that returns Sql Statement type based on db type
#
#####################################################################################
function FormPreparedStatementSetter($ColumnProperties, $JdbcGetter) {
    If(!$ColumnProperties) {
        throw "Must provide column properties to FormPreparedStatementSetter function!"
    }
    If(!$JdbcGetter) {
        throw "Must provide Jdbc getter to FormPreparedStatementSetter function!"
    }

    $JdbcType = ConvertDBTypeToSqlType($ColumnProperties)

    switch ($ColumnProperties.DATA_TYPE) 
    { 
      time          {"$JdbcGetter, $JdbcType";break} 
      date          {"$JdbcGetter, $JdbcType";break} 
      datetimeoffset{"$JdbcGetter.format(FORMATTER_TO_DB), $JdbcType";break}
      datetime2     {"$JdbcGetter, $JdbcType";break}
      datetime      {"MigratorUtil.convertJavaDateToSqlDate($JdbcGetter)";break}
      default       {"$JdbcGetter"}
    }
}