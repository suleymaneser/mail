param(
[string]$WorkspaceAbsPath="x",         # Workspace - "C:\Jenkins\workspace\JenkinsWorkspace"
[string]$ScriptBaseRelPath="x",        # Script base directory - "scripts\CI_Scripts"
[string]$OutputRelPath="x",            # Script output absolute directory - "scripts\CI_Scripts"
[string]$DBDriverClassName="x",        # JDBC driver class name - "net.sourceforge.jtds.jdbc.Driver"
[string]$SourceDBConnectionString="x", # DB connection string - "jdbc\:jtds\:sqlserver\://localhost\:1433;databaseName\=rallyGE"
[string]$SourceDBName="x",             # DB connection string - "ydsm0647"
[string]$DestDBConnectionString="x",   # DB connection string - "jdbc\:jtds\:sqlserver\://localhost\:1433;databaseName\=rallyGE"
[string]$DestDBName="x",               # DB connection string - "rallyGE"
[string]$DBUsername="x",               # DB user name - "sa"
[string]$DBPassword="x",               # DB password - "Latestgama01"
[string]$BPMNSourceDir="x",            # Bpmn Source Dir - "..\\process\\src\\main\\resources\\diagrams\\"
[string]$DefaultZoneId="x"         	   # Default Zone ID - "Asia/Istanbul"
)

echo "ConfigureAccountMigrator Parameters:"
($MyInvocation.MyCommand.Parameters ).Keys | %{
    $val = (Get-Variable -Name $_ -EA SilentlyContinue).Value
    if( $val.length -gt 0 ) {
        echo "($($_)) = ($($val))"
    }
}

echo "Updating account-migrator configuration for current build"

Get-Content (Join-Path $WorkspaceAbsPath -ChildPath $ScriptBaseRelPath | Join-Path -ChildPath "application.properties") | 
Foreach-Object {$_ -replace "DATABASEDRIVERCLASSNAME", $DBDriverClassName} |
Foreach-Object {$_ -replace "SOURCEDATABASEURL", $SourceDBConnectionString} | 
Foreach-Object {$_ -replace "DESTINATIONDATABASEURL", $DestDBConnectionString} | 
Foreach-Object {$_ -replace "SOURCEDATABASENAME", $SourceDBName} |
Foreach-Object {$_ -replace "DESTINATIONDATABASENAME", $DestDBName} |
Foreach-Object {$_ -replace "DATABASEUSERNAME", $DBUsername} |
Foreach-Object {$_ -replace "DATABASEPASSWORD", $DBPassword} |
Foreach-Object {$_ -replace "REPLACEDEFAULTZONEID", $DefaultZoneId} |
Set-Content (Join-Path $WorkspaceAbsPath -ChildPath $OutputRelPath | Join-Path -ChildPath "application.properties") -Force

echo "account-migrator configuration updated..."